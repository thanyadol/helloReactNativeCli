mvn -Pldb clean package
