docker images | grep sync | cut -c47-58
