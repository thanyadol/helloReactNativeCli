mvn spring-boot:run -Ppre -Dspring.profiles.active=pre
