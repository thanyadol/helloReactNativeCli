docker ps -la | grep sync | cut -c1-12 | xargs docker logs
