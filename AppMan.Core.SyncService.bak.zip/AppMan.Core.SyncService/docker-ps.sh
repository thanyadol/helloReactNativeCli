docker ps -a
