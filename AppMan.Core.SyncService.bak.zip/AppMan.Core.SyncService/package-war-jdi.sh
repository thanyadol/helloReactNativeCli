mvn -f pom-war.xml -Pjdi clean package
