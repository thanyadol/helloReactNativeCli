mvn -f pom-war.xml -Ppdb clean package
