mvn spring-boot:run -Pddb -Dspring.profiles.active=ddb
