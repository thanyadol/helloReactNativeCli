docker ps -la | grep sync | cut -c1-12 | xargs docker inspect -f '{{range.NetworkSettings.Networks}}{{.IPAddress}}{{end}}' 
