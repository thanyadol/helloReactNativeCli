echo "docker login"
echo "username :xxxxx"
echo "password :xxxxx"

