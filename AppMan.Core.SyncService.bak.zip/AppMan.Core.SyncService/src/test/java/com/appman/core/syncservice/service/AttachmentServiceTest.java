package com.appman.core.syncservice.service;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
//import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
//import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.PropertySource;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.appman.core.syncservice.config.ApplicationConfig;
//import com.appman.core.syncservice.config.ApplicationConfigTst;
import com.appman.core.syncservice.dto.Base64File;
import com.appman.core.syncservice.dto.ReadParams;
import com.appman.core.syncservice.enumeration.EnumFileStatus;
import com.appman.core.syncservice.model.Attachment;
import com.appman.core.syncservice.repository.AttachmentCrudRepository;
import com.appman.core.syncservice.repository.AttachmentRepository;
import com.appman.core.syncservice.repository.DraftDataCrudRepository;
import com.appman.core.syncservice.repository.DraftDataRepository;
import com.appman.core.syncservice.util.AppUtil;
import com.appman.core.syncservice.util.CipherUtil;

@ActiveProfiles("it")
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { ApplicationConfig.class })
@PropertySource("classpath:application.properties")
@EnableTransactionManagement
public class AttachmentServiceTest {
	private static final Logger log = LoggerFactory.getLogger(AttachmentServiceTest.class);

	// @TestConfiguration
	// static class AttachmentServiceTestContextConfiguration {
	// @Bean
	// public AttachmentService attachmentService() {
	// return new AttachmentService();
	// }
	// }

	// @TestConfiguration
	// static class SyncDraftServiceTestContextConfiguration {
	// @Bean
	// public SyncDraftService syncDraftService() {
	// return new SyncDraftService();
	// }
	// }

	@MockBean
	private DraftDataRepository draftDataRepository;

	@MockBean
	private DraftDataCrudRepository draftDataCrudRepository;

	@Autowired
	private AttachmentService attachmentService;

	@Autowired
	private SyncDraftService syncDraftService;

	@MockBean
	private AttachmentRepository attachmentRepository;

	@MockBean
	private AttachmentCrudRepository attachmentCrudRepository;

	// Needed prevent exception due to no actual PlatformTransactionManager in unit test.
	@MockBean
	private PlatformTransactionManager platformTransactionManager;

	// Not work properly, no valid been assigned.
	@MockBean(classes = DiskAttachmentStorage.class)
	@Qualifier("attachmentStorage")
	private IAttachmentStorage storage;

	@Before
	public void setup() {
		log.info("Storage :{}", storage.getStorageType());
		storage = new DiskAttachmentStorage("./target/");
		attachmentService.setStorage(storage);

		/* Mock save attachment */
		Attachment attachment = new Attachment();
		attachment.setContentType("image/png");
		attachment.setCreatedAt(1l);
		attachment.setCreatedBy("AGENT_AAA");
		attachment.setEncryptionParams("");
		attachment.setFileUID(AppUtil.getUUID());
		attachment.setReadParams("");
		attachment.setStatus(EnumFileStatus.AVAILABLE);
		attachment.setStorageType("LOCAL_FILE");
		attachment.setUpdatedAt(1l);
		attachment.setUpdatedBy("AGENT_AAA");
		Mockito.when(attachmentCrudRepository.save(attachment)).thenReturn(attachment);
	}

	@Test
	public void testStorage_SpecifyLocalStorage_ReturnLocalStorage() throws Exception {
		assertEquals("LOCAL_FILE", storage.getStorageType());
		ReadParams readParams = storage.getReadParams(AppUtil.getUUID());
		log.info("ReadParams Json :{}", readParams.asJsonValue());
	}

	@Test
	public void testSaveAttachment_SaveValidBase64Attachment_SaveCorrectly() throws Exception {
		Base64File file = new Base64File();
		file.setChecksum("cuxav01fxpbx");
		file.setContentBody(
				"TU0AKgAAAAgADAEAAAMAAAABAEIAAAEBAAMAAAABAEIAAAECAAMAAAABAAgAAAEDAAMAAAABAAUAAAEGAAMAAAABAAEAAAERAAQAAAABAAAAsAEVAAMAAAABAAEAAAEWAAMAAAABAEIAAAEXAAQAAAABAAAB2gEaAAUAAAABAAAAoAEbAAUAAAABAAAAqAEoAAMAAAABAAIAAAAAAAAAAAAAAMgAAAABAAAAyAAAAAGAP6BQOCQWDQeEQmFQt/w2HQ+IRGJROKRWLQuMRmNRt/RaPR+QSF/xySSWNyKUSmQyaWS2DSqYTGIy6aS2ZTeYzWdSScT2UTugRmfUOP0GjQmiUmKUemQWlU+IU2pR2oVWjuJPVmsuqjUo8ACwWBH0mjPoOWGwCiu0RZ2iws+iUYuWEgWE6UGiPMGWAQN+whh90OgqKwn9/ESwq6gUQmWFhv9L2EqYKduYCWl9P53ZcAAx5Tuho+woOHY2wJefUAUWFrQNPXTQT1n3SHvcEWFrz2dnywp6CmSwoadT4MWAEOeILuwiDAzedMKwkyDhSwsaaz00WFRxKv2AyTiavIIWAGO6Dr6/vaaThP2EwRQQWFT86aEiwqJvfn9fo2WEoPWmRztut0CLcAh3pkmhLQLBi0EklybhhBsJhhBKWmcsIWF9DcOQ7DZbM4ABpJsmLugAQ6PigwqcpYfQSLCbyMlMsIOMykyYl+2iPnu8awF+mCWjAsJLI2uawC4liYHu4oAARBCQFOsIKHmlSWMIsAsI4e0egATUbpVFSwFelDgLAJEqpKewyDAMAyM+jhlTZNj1J4qqoKmps7TvPCjz0p8+T7PyyUAvFBLjQjF0MylEOHRTU0ZRtHJwgIA=");
		file.setContentType("image/png");
		file.setLocalFileID("001");
		file.setOwner("AGENT_AAA");
		file.setRaw(CipherUtil.base64ToByteArray(file.getContentBody()));
		attachmentService.saveAttachment(file);
	}
}
