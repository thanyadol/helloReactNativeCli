package com.appman.core.syncservice.controller;

import static org.hamcrest.CoreMatchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.nio.file.Files;
import java.nio.file.Paths;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import com.appman.core.syncservice.model.PushResponse;
import com.appman.core.syncservice.util.JsonUtil;

/* Test with "it" profile */
@ActiveProfiles("it")
@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
public class SyncControllerIT {
	private static final Logger log = LoggerFactory.getLogger(SyncControllerIT.class);

	@Autowired
	private MockMvc mockMvc;

	@Test
	public void testPushData_PerformPushFetchData_ReturnResultCorrectly() throws Exception {
		// Test SyncController.pushData
		MvcResult result = this.mockMvc
				.perform(post("/push").contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
						.content(new String(Files.readAllBytes(Paths.get("./asset/json/sync.json")))))
				.andExpect(status().isOk()).andExpect(jsonPath("$.key", is("key0001")))
				.andExpect(jsonPath("$.draftType", is("draft")))
				.andExpect(jsonPath("$.data.insured.firstName.value", is("Appman")))
				.andExpect(jsonPath("$.data.insured.firstName.dirty", is(true))).andReturn();

		PushResponse pushResponse = JsonUtil.mapper.readValue(result.getResponse().getContentAsString(),
				PushResponse.class);

		// Test SyncController.fetchOne
		result = this.mockMvc.perform(get("/fetch?Owner=AGENT_AAA&LatestUpdatedAt=1&Limit=10"))
				.andExpect(status().isOk()).andExpect(jsonPath("$.owner", is("AGENT_AAA")))
				.andExpect(jsonPath("$.count", is(1))).andExpect(jsonPath("$.total", is(1)))
				.andExpect(jsonPath("$.list[0].key", is("key0001")))
				.andExpect(jsonPath("$.list[0].rev", is(pushResponse.getBody().getRev())))
				.andExpect(jsonPath("$.list[0].draftType", is("draft")))
				.andExpect(jsonPath("$.list[0].data.insured.firstName.value", is("Appman")))
				.andExpect(jsonPath("$.list[0].data.insured.firstName.dirty", is(true)))
				.andExpect(jsonPath("$.list[0].data.insured.lastName.value", is("Manapp")))
				.andExpect(jsonPath("$.list[0].data.insured.lastName.dirty", is(true)))
				.andExpect(jsonPath("$.list[0].data.insured.nickName.value", is("am")))
				.andExpect(jsonPath("$.list[0].data.insured.nickName.dirty", is(true))).andReturn();

		// Test SyncController.fetch
		result = this.mockMvc.perform(get("/fetch/key0001")).andExpect(status().isOk())
				.andExpect(jsonPath("$.key", is("key0001")))
				.andExpect(jsonPath("$.rev", is(pushResponse.getBody().getRev())))
				.andExpect(jsonPath("$.draftType", is("draft")))
				.andExpect(jsonPath("$.data.insured.firstName.value", is("Appman")))
				.andExpect(jsonPath("$.data.insured.firstName.dirty", is(true)))
				.andExpect(jsonPath("$.data.insured.lastName.value", is("Manapp")))
				.andExpect(jsonPath("$.data.insured.lastName.dirty", is(true)))
				.andExpect(jsonPath("$.data.insured.nickName.value", is("am")))
				.andExpect(jsonPath("$.data.insured.nickName.dirty", is(true))).andReturn();
		
		// Test push with invalid rev, error
		result = this.mockMvc
				.perform(post("/push").contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
						.content(new String(Files.readAllBytes(Paths.get("./asset/json/sync.json")))))
				.andExpect(status().isConflict()).andExpect(jsonPath("$.prev.key", is("key0001")))
				.andExpect(jsonPath("$.error", is("Rev not matched")))
				.andExpect(jsonPath("$.prev.data.insured.firstName.value", is("Appman")))
				.andExpect(jsonPath("$.prev.data.insured.firstName.dirty", is(true))).andReturn();
	}
}
