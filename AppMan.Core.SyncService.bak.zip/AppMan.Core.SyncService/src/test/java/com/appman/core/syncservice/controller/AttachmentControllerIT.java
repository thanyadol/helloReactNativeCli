package com.appman.core.syncservice.controller;

import static org.hamcrest.CoreMatchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.UUID;

import org.hamcrest.Matchers;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import com.appman.core.syncservice.dto.Base64File;
import com.appman.core.syncservice.dto.SaveBatchAttachmentRequest;
import com.appman.core.syncservice.dto.SaveBatchAttachmentResponse;
import com.appman.core.syncservice.util.JsonUtil;
import com.fasterxml.jackson.databind.ObjectMapper;

/* Test with "it" profile */
@ActiveProfiles("it")
@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
public class AttachmentControllerIT {
	private static final Logger log = LoggerFactory.getLogger(AttachmentControllerIT.class);

	@Autowired
	private MockMvc mockMvc;

	@Test
	public void testAddAttachment_AddAttachments_ReturnValidData() throws Exception {
		SaveBatchAttachmentRequest input = new SaveBatchAttachmentRequest();
		Base64File base64File = new Base64File();
		base64File.setContentBody("abc");
		base64File.setContentType("image/png");
		base64File.setLocalFileID("localF01");
		base64File.setOwner("AGENT_AAA");
		input.getAttachments().add(base64File);

		base64File = new Base64File();
		base64File.setContentBody("def");
		base64File.setContentType("image/png");
		base64File.setLocalFileID("localF02");
		base64File.setOwner("AGENT_AAA");
		input.getAttachments().add(base64File);

		MvcResult result = this.mockMvc
				.perform(post("/attachment/add").contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
						.content(new ObjectMapper().writeValueAsString(input)))
				.andExpect(status().isOk()).andExpect(jsonPath("$.attachments", Matchers.hasKey("localF01")))
				.andExpect(jsonPath("$.attachments", Matchers.hasKey("localF02"))).andReturn();
		log.info("AddAttachment result :{}", result.getResponse().getContentAsString());
	}

	@Test
	public void testGetAttachment_AddAttachmentAndGetOne_GetCorrectly() throws Exception {
		SaveBatchAttachmentResponse saveResult = null;

		SaveBatchAttachmentRequest input = new SaveBatchAttachmentRequest();
		Base64File base64File = new Base64File();
		base64File.setContentBody("abc");
		base64File.setContentType("image/png");
		base64File.setLocalFileID("localF01");
		base64File.setOwner("AGENT_AAA");
		input.getAttachments().add(base64File);

		base64File = new Base64File();
		base64File.setContentBody("def");
		base64File.setContentType("image/png");
		base64File.setLocalFileID("localF02");
		base64File.setOwner("AGENT_AAA");
		input.getAttachments().add(base64File);

		MvcResult result = this.mockMvc
				.perform(post("/attachment/add").contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
						.content(new ObjectMapper().writeValueAsString(input)))
				.andExpect(status().isOk()).andExpect(jsonPath("$.attachments", Matchers.hasKey("localF01")))
				.andExpect(jsonPath("$.attachments", Matchers.hasKey("localF02"))).andReturn();
		saveResult = JsonUtil.mapper.readValue(result.getResponse().getContentAsString(),
				SaveBatchAttachmentResponse.class);
		UUID fileUID = saveResult.getAttachments().get("localF01");

		this.mockMvc.perform(get("/attachment/get/" + fileUID)).andExpect(status().isOk())
				.andExpect(jsonPath("$.fileUID", is(fileUID.toString())))
				.andExpect(jsonPath("$.contentType", is("image/png")));
	}

	@Test
	public void testAttachment_AddGetRemove_ResultCorrectly() throws Exception {
		SaveBatchAttachmentResponse saveResult = null;
		MvcResult result = this.mockMvc
				.perform(post("/attachment/add").contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
						.content(new String(Files.readAllBytes(Paths.get("./asset/json/attachment.json")))))
				.andExpect(status().isOk()).andExpect(jsonPath("$.attachments", Matchers.hasKey("fe0000000001")))
				.andExpect(jsonPath("$.attachments", Matchers.hasKey("fe0000000002"))).andReturn();
		saveResult = JsonUtil.mapper.readValue(result.getResponse().getContentAsString(),
				SaveBatchAttachmentResponse.class);

		UUID fileUID = saveResult.getAttachments().get("fe0000000001");
		this.mockMvc.perform(get("/attachment/get/" + fileUID)).andExpect(status().isOk())
				.andExpect(jsonPath("$.fileUID", is(fileUID.toString())))
				.andExpect(jsonPath("$.contentType", is("image/png")));
		this.mockMvc.perform(delete("/attachment/remove/" + fileUID.toString())).andExpect(status().isOk())
				.andExpect(jsonPath("$.fileUID", is(fileUID.toString())));

		fileUID = saveResult.getAttachments().get("fe0000000002");
		this.mockMvc.perform(get("/attachment/get/" + fileUID)).andExpect(status().isOk())
				.andExpect(jsonPath("$.fileUID", is(fileUID.toString())))
				.andExpect(jsonPath("$.contentType", is("image/png")));
		this.mockMvc.perform(delete("/attachment/remove/" + fileUID.toString())).andExpect(status().isOk())
				.andExpect(jsonPath("$.fileUID", is(fileUID.toString())));
	}
}
