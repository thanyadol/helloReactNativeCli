package com.appman.core.syncservice.service;

import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
//import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
//import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.appman.core.syncservice.config.ApplicationConfig;
import com.appman.core.syncservice.exception.KeyNotDefinedException;
import com.appman.core.syncservice.exception.RevNotDefinedException;
import com.appman.core.syncservice.exception.RevNotMatchedException;
import com.appman.core.syncservice.model.PushRequest;
import com.appman.core.syncservice.model.DraftDatas;
import com.appman.core.syncservice.repository.AttachmentCrudRepository;
import com.appman.core.syncservice.repository.AttachmentRepository;
import com.appman.core.syncservice.repository.DraftDataCrudRepository;
import com.appman.core.syncservice.repository.DraftDataRepository;

@ActiveProfiles("it")
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { ApplicationConfig.class })
@PropertySource("classpath:application.properties")
@EnableTransactionManagement
public class SyncDraftServiceTest {
	private static final Logger log = LoggerFactory.getLogger(SyncDraftServiceTest.class);

	// @TestConfiguration
	// static class SyncDraftServiceTestContextConfiguration {
	// @Bean
	// public SyncDraftService syncDraftService() {
	// return new SyncDraftService();
	// }
	// }

	@Autowired
	private SyncDraftService syncDraftService;

	@MockBean
	private DraftDataRepository draftDataRepository;

	@MockBean
	private DraftDataCrudRepository draftDataCrudRepository;

	@MockBean
	private AttachmentRepository attachmentRepository;

	@MockBean
	private AttachmentCrudRepository attachmentCrudRepository;

	// Needed prevent exception due to no actual PlatformTransactionManager in unit test.
	@MockBean
	private PlatformTransactionManager platformTransactionManager;

	@MockBean(classes = DiskAttachmentStorage.class)
	@Qualifier("attachmentStorage")
	private IAttachmentStorage storage;

	@Before
	public void setup() {
		DraftDatas r = new DraftDatas();
		r.setKey("A00001");
		r.setData("");
		r.setOwner("abc");
		r.setRev("R00001");
		r.setData("");

		Pageable pageable = PageRequest.of(0, 10, Sort.by("updatedAt").ascending());
		List<DraftDatas> data = new ArrayList<>();
		data.add(new DraftDatas());
		Mockito.when(draftDataRepository.findByOwnerAndUpdatedAtGreaterThanOrderByUpdatedAtAsc("", 1, pageable))
				.thenReturn(data);
		Mockito.when(draftDataRepository.findTop1ByKeyOrderByUpdatedAtDesc("key_already_exists")).thenReturn(r);
	}

	@Test
	public void testWiring_WireSyncDraftService_WireCorrectly() {
		assertNotNull(syncDraftService);
	}

	@Test
	public void testPush_ThereIsExistingKey_DataUpdated()
			throws KeyNotDefinedException, RevNotMatchedException, RevNotDefinedException {
		DraftDatas mockSaveResult = new DraftDatas("key_already_exists", "R00001", "", "");
		mockSaveResult.setData("");
		mockSaveResult.setOwner("abc");
		mockSaveResult.setRev("R00001");
		mockSaveResult.setData("");
		Mockito.when(draftDataCrudRepository.save(mockSaveResult)).thenReturn(mockSaveResult);

		DraftDatas pushReqResourceData = new DraftDatas();
		pushReqResourceData.setRev("R00001");
		pushReqResourceData.setKey("key_00001");
		PushRequest pushRequest = new PushRequest("TEST_PUSH", pushReqResourceData);
		pushRequest.setBody(mockSaveResult);
		syncDraftService.push(pushRequest);
	}
}
