package com.appman.core.syncservice.repository;

import java.util.Collection;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.repository.Repository;

import com.appman.core.syncservice.enumeration.EnumFileStatus;
import com.appman.core.syncservice.model.Attachment;

/**
 * Support pagination
 **/
@Qualifier(value = "attachmentRepository")
public interface AttachmentRepository extends Repository<Attachment, String> {
	List<Attachment> findByFileUIDNotInOrStatusNot(Collection<UUID> fileUID, EnumFileStatus status);
	List<Attachment> findByFileUIDInAndStatus(Collection<UUID> fileUID, EnumFileStatus status);
	Attachment findTop1ByFileUIDOrderByUpdatedAtDesc(UUID fileUID);
}
