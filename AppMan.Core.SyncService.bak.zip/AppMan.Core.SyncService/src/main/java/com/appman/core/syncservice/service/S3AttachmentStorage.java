package com.appman.core.syncservice.service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.Bucket;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.appman.core.syncservice.dto.EncryptionParams;
import com.appman.core.syncservice.dto.ReadParams;
import com.appman.core.syncservice.dto.S3ReadParams;
import com.appman.core.syncservice.exception.AttachmentStorageException;
import com.appman.core.syncservice.util.JsonUtil;

public class S3AttachmentStorage implements IAttachmentStorage {
	private static final Logger log = LoggerFactory.getLogger(S3AttachmentStorage.class);

	public static final int BUFFER_SIZE = 1024;
	private String bucket;
	private AmazonS3 s3;

	public S3AttachmentStorage() {
	}

	public S3AttachmentStorage(AmazonS3 s3, String bucket) {
		this.s3 = s3;
		this.bucket = bucket;
	}

	@Override
	public S3ReadParams as(ReadParams readParams) {
		return (S3ReadParams) readParams;
	}

	@Override
	public String getStorageType() {
		return null;
	}

	@Override
	public byte[] readData(ReadParams params) throws AttachmentStorageException {
		byte[] buffer = new byte[BUFFER_SIZE];
		int length = -1;
		S3ReadParams readParams = as(params);
		try (ByteArrayOutputStream stream = new ByteArrayOutputStream()) {
			S3Object object = s3.getObject(new GetObjectRequest(readParams.getBucket(), readParams.getKey()));
			S3ObjectInputStream inputStream = object.getObjectContent();
			while ((length = inputStream.read(buffer)) != -1) {
				stream.write(buffer, 0, length);
			}
			stream.flush();
			return stream.toByteArray();
		} catch (IOException e) {
			throw new AttachmentStorageException(e);
		}
	}

	@Override
	public ReadParams deleteData(ReadParams params) throws AttachmentStorageException {
		S3ReadParams readParams = as(params);
		s3.deleteObject(readParams.getBucket(), readParams.getKey());
		return readParams;
	}

	@Override
	public ReadParams writeData(ReadParams params, byte[] data) throws AttachmentStorageException {
		S3ReadParams readParams = as(params);
		s3.putObject(new PutObjectRequest(readParams.getBucket(), readParams.getKey(), new ByteArrayInputStream(data),
				null));
		return readParams;
	}

	@Override
	public ReadParams getReadParams(UUID uuid) {
		return new S3ReadParams(uuid.toString(), bucket);
	}

	@Override
	public ReadParams fromReadParamsText(String param) throws IOException {
		return JsonUtil.mapper.readValue(param, S3ReadParams.class);
	}

	@Override
	public EncryptionParams fromEncryptionParamsText(String param) throws IOException {
		return JsonUtil.mapper.readValue(param, EncryptionParams.class);
	}

	public List<Bucket> listAllBuckets() {
		return s3.listBuckets();
	}

	public String getBucket() {
		return bucket;
	}

	public void setBucket(String bucket) {
		this.bucket = bucket;
	}
}
