package com.appman.core.syncservice.exception;

import java.util.UUID;

public class InvalidFileException extends Exception {
	private static final long serialVersionUID = -188266595309548350L;

	private UUID fileUID;

	public InvalidFileException() {
		super();
	}

	public InvalidFileException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public InvalidFileException(String message, Throwable cause) {
		super(message, cause);
	}

	public InvalidFileException(String message) {
		super(message);
	}

	public InvalidFileException(String message, UUID fileUID) {
		super(message);
		this.fileUID = fileUID;
	}

	public InvalidFileException(Throwable cause) {
		super(cause);
	}

	public String getFileUIDString() {
		return fileUID != null ? fileUID.toString() : "NULL FileUID";
	}

	public UUID getFileUID() {
		return fileUID;
	}

	public void setFileUID(UUID fileUID) {
		this.fileUID = fileUID;
	}
}
