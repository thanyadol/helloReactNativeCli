package com.appman.core.syncservice.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class InvalidFileErrorDetail implements Serializable {
	private static final long serialVersionUID = -765028782611145528L;

	private String error;
	private String fileUID;
	private String stacktrace;
}
