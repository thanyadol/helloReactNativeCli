package com.appman.core.syncservice.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.Repository;

import com.appman.core.syncservice.model.DraftDatas;

@Qualifier(value = "draftDataRepository")
public interface DraftDataRepository extends Repository<DraftDatas, Long> {
	int countByOwnerAndUpdatedAtGreaterThan(String owner, long updatedAt);

	List<DraftDatas> findByOwnerAndUpdatedAtGreaterThanOrderByUpdatedAtAsc(String owner, long updatedAt, Pageable page);

	DraftDatas findTop1ByKeyOrderByUpdatedAtDesc(String key);
}
