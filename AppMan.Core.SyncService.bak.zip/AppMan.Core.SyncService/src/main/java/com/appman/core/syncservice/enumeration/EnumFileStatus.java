package com.appman.core.syncservice.enumeration;

public enum EnumFileStatus {
	DELETED(0), AVAILABLE(1);
	
	private final int value;
	
	EnumFileStatus(final int value) {
		this.value = value;
	}

	public int getValue() {
		return value;
	}
	
	@Override
	public String toString() {
		return Long.toString(value);
	}
}
