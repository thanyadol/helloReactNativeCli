package com.appman.core.syncservice.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EncryptionParams implements Serializable {
	private static final long serialVersionUID = -4872883956612681609L;

	@JsonProperty("Base64IV")
	private String base64IV;
	
	@JsonProperty("Base64Salt")
	private String base64Salt;
	
	@JsonProperty("Password")
	private String password;

	@JsonIgnore
	private byte[] encrypted;
}
