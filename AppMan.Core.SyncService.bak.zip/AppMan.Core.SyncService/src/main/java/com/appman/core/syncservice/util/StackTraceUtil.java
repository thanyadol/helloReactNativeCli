package com.appman.core.syncservice.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;

public class StackTraceUtil {
	private static final int BUFFER_SIZE = 512;

	private StackTraceUtil() {
	}

	public static String respondStackTrace(Exception exception) {
		Writer writer = new StringWriter();
		exception.printStackTrace(new PrintWriter(writer));
		return writer.toString();
	}

	public static String respondStackTrace(Error error) {
		Writer writer = new StringWriter();
		error.printStackTrace(new PrintWriter(writer));
		return writer.toString();
	}

	public static String responseJsonStackTrace(Exception exception) {
		return "{\"errors\" : \"" + respondStackTrace(exception) + "\"}";
	}

	/**
	 * Print out command line result
	 * 
	 * @param inputStream
	 *            :Process.getInputStream()
	 * @return command line result
	 **/
	public static String responseCommandLineResult(InputStream inputStream) throws IOException {
		if (inputStream == null) {
			return "";
		}

		int length = -1;
		byte[] buffer = new byte[BUFFER_SIZE];
		ByteArrayOutputStream bo = new ByteArrayOutputStream();

		while ((length = inputStream.read(buffer)) > 0) {
			bo.write(buffer, 0, length);
		}

		if (bo.size() > 0) {
			return new String(bo.toByteArray());
		}

		return "";
	}
}
