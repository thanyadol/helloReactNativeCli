package com.appman.core.syncservice.dto;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@JsonPropertyOrder({ "key", "rev", "draftType", "data", "attachments" })
public class PushDraftRequestModel implements Serializable {
	private static final long serialVersionUID = -5269511901161242936L;

	@ApiModelProperty(notes = "front-end key", example = "A10001", position = 10)
	@JsonProperty("key")
	private String key;

	@ApiModelProperty(notes = "rev", example = "cbaf48dc2a3b3a971c9ff596f6b09e0511633a71", position = 20)
	@JsonProperty("rev")
	private String rev;

	@ApiModelProperty(notes = "Draft type", example = "app", position = 30)
	@JsonProperty("draftType")
	private String draftType;

	@ApiModelProperty(notes = "Json data", example = "{'draftType': 'application', 'data': {'insured': {'firstName': {'text': 'ทดสอบ'}}}}", position = 40)
	@JsonProperty("data")
	private Object data;

	/*
	 * @ApiModelProperty(notes = "Attachment reference key :front-end-key, value :Database UUID", example =
	 * "{'001': '0f8fad5b-d9cb-469f-a165-70867728950a', '002': '0f8fad5b-d9cb-469f-a165-70867728950b'}", position = 50)
	 */
	@ApiModelProperty(notes = "Attachment reference key :front-end-key, value :Database UUID", example = "{}", position = 50)
	@JsonProperty("attachments")
	private Map<String, UUID> attachments = new LinkedHashMap<>();
}
