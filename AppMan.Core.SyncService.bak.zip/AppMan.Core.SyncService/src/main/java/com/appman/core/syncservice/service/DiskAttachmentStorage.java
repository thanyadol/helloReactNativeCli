package com.appman.core.syncservice.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.appman.core.syncservice.dto.DiskReadParams;
import com.appman.core.syncservice.dto.EncryptionParams;
import com.appman.core.syncservice.dto.ReadParams;
import com.appman.core.syncservice.exception.AttachmentStorageException;
import com.appman.core.syncservice.util.JsonUtil;

public class DiskAttachmentStorage implements IAttachmentStorage {
	private static final Logger log = LoggerFactory.getLogger(DiskAttachmentStorage.class);

	private String path;

	public DiskAttachmentStorage() {
	}

	public DiskAttachmentStorage(String path) {
		this.path = path;
	}

	@Override
	public String getStorageType() {
		return "LOCAL_FILE";
	}

	public DiskReadParams as(ReadParams readParams) {
		return (DiskReadParams) readParams;
	}

	@Override
	public byte[] readData(ReadParams params) throws AttachmentStorageException {
		try {
			return Files.readAllBytes(Paths.get(as(params).getPath()));
		} catch (IOException e) {
			throw new AttachmentStorageException("IO reading file error", e);
		}
	}

	@Override
	public ReadParams deleteData(ReadParams params) throws AttachmentStorageException {
		try {
			Files.deleteIfExists(Paths.get(as(params).getPath()));
			return params;
		} catch (IOException e) {
			throw new AttachmentStorageException("IO deleting file error", e);
		}
	}

	@Override
	public ReadParams writeData(ReadParams params, byte[] data) throws AttachmentStorageException {
		try {
			Files.write(Paths.get(as(params).getPath()), data, StandardOpenOption.CREATE_NEW);
		} catch (IOException e) {
			throw new AttachmentStorageException("IO writing file error", e);
		}
		return params;
	}

	@Override
	public ReadParams getReadParams(UUID uuid) {
		return new DiskReadParams(uuid.toString(), path + uuid.toString());
	}

	@Override
	public ReadParams fromReadParamsText(String param) throws IOException {
		return JsonUtil.mapper.readValue(param, DiskReadParams.class);
	}

	@Override
	public EncryptionParams fromEncryptionParamsText(String param) throws IOException {
		return JsonUtil.mapper.readValue(param, EncryptionParams.class);
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}
}
