package com.appman.core.syncservice.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.security.AlgorithmParameters;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.InvalidParameterSpecException;
import java.security.spec.KeySpec;
import java.util.Arrays;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;

import org.apache.commons.text.RandomStringGenerator;
import org.springframework.util.Base64Utils;

import com.appman.core.syncservice.dto.EncryptionParams;
import com.appman.core.syncservice.exception.CipherException;

public class CipherUtil {
	public static final String SECRET_KEY_FACTORY_ALGORITHM = "PBKDF2WithHmacSHA1";
	public static final String SECRET_KEY_SPEC_ALGORITHM = "AES";
	public static final int ITERATION_COUNT = 65536;
	public static final int KEY_LENGTH = 256;
	public static final String PADDING = "AES/CBC/PKCS5Padding";
	public static final int DEFAULT_BUFFER_SIZE = 1024;

	private CipherUtil() {
	}

	public static byte[] base64ToByteArray(String base64String) {
		return Base64Utils.decodeFromString(base64String);
	}

	public static String byteToBase64String(byte[] data) {
		return Base64Utils.encodeToString(data);
	}

	public static String generatePassword(int length) {
		return new RandomStringGenerator.Builder().withinRange(33, 45).build().generate(length);
	}

	public static EncryptionParams aesEncrypt(byte[] data) throws CipherException {
		String password = generatePassword(20);
		try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
			SecureRandom random = new SecureRandom();
			byte[] salt = new byte[16];
			random.nextBytes(salt);

			SecretKeyFactory factory = SecretKeyFactory.getInstance(SECRET_KEY_FACTORY_ALGORITHM);
			KeySpec spec = new PBEKeySpec(password.toCharArray(), salt, ITERATION_COUNT, KEY_LENGTH);
			SecretKey tmp = factory.generateSecret(spec);
			SecretKey secret = new SecretKeySpec(tmp.getEncoded(), SECRET_KEY_SPEC_ALGORITHM);

			Cipher cipher = Cipher.getInstance(PADDING);
			cipher.init(Cipher.ENCRYPT_MODE, secret);
			AlgorithmParameters params = cipher.getParameters();
			byte[] iv = params.getParameterSpec(IvParameterSpec.class).getIV();
			byte[] encryptedText = cipher.doFinal(data);
			outputStream.write(encryptedText);

			return new EncryptionParams(byteToBase64String(iv), byteToBase64String(salt), password,
					outputStream.toByteArray());
		} catch (NoSuchAlgorithmException | InvalidKeySpecException | NoSuchPaddingException
				| InvalidParameterSpecException | IllegalBlockSizeException | BadPaddingException | InvalidKeyException
				| IOException e) {
			throw new CipherException("AES Encrypt failed", e);
		}
	}

	public static byte[] aesDecrypt(byte[] encryptedData, EncryptionParams encryptionParams) throws CipherException {
		return aesDecrypt(encryptedData, encryptionParams.getBase64IV(), encryptionParams.getBase64Salt(),
				encryptionParams.getPassword());
	}

	private static byte[] aesDecrypt(byte[] encryptedData, String base64IV, String base64Salt, String password)
			throws CipherException {
		try {
			SecretKeyFactory factory = SecretKeyFactory.getInstance(SECRET_KEY_FACTORY_ALGORITHM);
			KeySpec spec = new PBEKeySpec(password.toCharArray(), base64ToByteArray(base64Salt), ITERATION_COUNT,
					KEY_LENGTH);
			SecretKey tmp = factory.generateSecret(spec);
			SecretKey secret = new SecretKeySpec(tmp.getEncoded(), SECRET_KEY_SPEC_ALGORITHM);
			Cipher cipher = Cipher.getInstance(PADDING);
			cipher.init(Cipher.DECRYPT_MODE, secret, new IvParameterSpec(base64ToByteArray(base64IV)));

			return cipher.doFinal(encryptedData);
		} catch (NoSuchAlgorithmException | InvalidKeySpecException | NoSuchPaddingException | InvalidKeyException
				| InvalidAlgorithmParameterException | IllegalBlockSizeException | BadPaddingException e) {
			throw new CipherException("AES Decrypt failed", e);
		}
	}

	public static EncryptionParams encrypt(String data) throws CipherException {
		String password = generatePassword(20);
		try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
			SecureRandom random = new SecureRandom();
			byte[] salt = new byte[16];
			random.nextBytes(salt);

			SecretKeyFactory factory = SecretKeyFactory.getInstance(SECRET_KEY_FACTORY_ALGORITHM);
			KeySpec spec = new PBEKeySpec(password.toCharArray(), salt, ITERATION_COUNT, KEY_LENGTH);
			SecretKey tmp = factory.generateSecret(spec);
			SecretKey secret = new SecretKeySpec(tmp.getEncoded(), SECRET_KEY_SPEC_ALGORITHM);

			Cipher cipher = Cipher.getInstance(PADDING);
			cipher.init(Cipher.ENCRYPT_MODE, secret);
			AlgorithmParameters params = cipher.getParameters();
			byte[] iv = params.getParameterSpec(IvParameterSpec.class).getIV();
			byte[] encryptedText = cipher.doFinal(data.getBytes("UTF-8"));

			// concatenate salt + iv + ciphertext
			outputStream.write(salt);
			outputStream.write(iv);
			outputStream.write(encryptedText);

			return new EncryptionParams(byteToBase64String(iv), byteToBase64String(salt), password,
					outputStream.toByteArray());
		} catch (NoSuchAlgorithmException | InvalidKeySpecException | NoSuchPaddingException
				| InvalidParameterSpecException | IllegalBlockSizeException | BadPaddingException | InvalidKeyException
				| IOException e) {
			throw new CipherException("Encrypt failed", e);
		}
	}

	public static EncryptionParams encrypt(byte[] data) throws CipherException {
		String password = generatePassword(20);
		try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
			SecureRandom random = new SecureRandom();
			byte[] salt = new byte[16];
			random.nextBytes(salt);

			SecretKeyFactory factory = SecretKeyFactory.getInstance(SECRET_KEY_FACTORY_ALGORITHM);
			KeySpec spec = new PBEKeySpec(password.toCharArray(), salt, ITERATION_COUNT, KEY_LENGTH);
			SecretKey tmp = factory.generateSecret(spec);
			SecretKey secret = new SecretKeySpec(tmp.getEncoded(), SECRET_KEY_SPEC_ALGORITHM);

			Cipher cipher = Cipher.getInstance(PADDING);
			cipher.init(Cipher.ENCRYPT_MODE, secret);
			AlgorithmParameters params = cipher.getParameters();
			byte[] iv = params.getParameterSpec(IvParameterSpec.class).getIV();
			byte[] encryptedText = cipher.doFinal(data);

			// Concatenate salt + iv + ciphertext
			outputStream.write(salt);
			outputStream.write(iv);
			outputStream.write(encryptedText);

			return new EncryptionParams(byteToBase64String(iv), byteToBase64String(salt), password,
					outputStream.toByteArray());
		} catch (NoSuchAlgorithmException | InvalidKeySpecException | NoSuchPaddingException
				| InvalidParameterSpecException | IllegalBlockSizeException | BadPaddingException | InvalidKeyException
				| IOException e) {
			throw new CipherException("Encrypt failed", e);
		}
	}

	public static String decrypt(String encryptedText, String password) throws CipherException {
		try {
			byte[] ciphertext = DatatypeConverter.parseBase64Binary(encryptedText);
			if (ciphertext.length < 48) {
				return null;
			}
			byte[] salt = Arrays.copyOfRange(ciphertext, 0, 16);
			byte[] iv = Arrays.copyOfRange(ciphertext, 16, 32);
			byte[] ct = Arrays.copyOfRange(ciphertext, 32, ciphertext.length);

			SecretKeyFactory factory = SecretKeyFactory.getInstance(SECRET_KEY_FACTORY_ALGORITHM);
			KeySpec spec = new PBEKeySpec(password.toCharArray(), salt, ITERATION_COUNT, KEY_LENGTH);
			SecretKey tmp = factory.generateSecret(spec);
			SecretKey secret = new SecretKeySpec(tmp.getEncoded(), SECRET_KEY_SPEC_ALGORITHM);
			Cipher cipher = Cipher.getInstance(PADDING);

			cipher.init(Cipher.DECRYPT_MODE, secret, new IvParameterSpec(iv));
			byte[] plaintext = cipher.doFinal(ct);

			return new String(plaintext, "UTF-8");
		} catch (NoSuchAlgorithmException | InvalidKeySpecException | NoSuchPaddingException | InvalidKeyException
				| InvalidAlgorithmParameterException | IllegalBlockSizeException | BadPaddingException
				| UnsupportedEncodingException e) {
			throw new CipherException("Decrypt failed", e);
		}
	}

	public static byte[] decrypt(byte[] encryptedData, String password) throws CipherException {
		try {
			byte[] ciphertext = encryptedData;
			if (ciphertext.length < 48) {
				throw new CipherException("Data size should greater than 48");
			}
			byte[] salt = Arrays.copyOfRange(ciphertext, 0, 16);
			byte[] iv = Arrays.copyOfRange(ciphertext, 16, 32);
			byte[] ct = Arrays.copyOfRange(ciphertext, 32, ciphertext.length);

			SecretKeyFactory factory = SecretKeyFactory.getInstance(SECRET_KEY_FACTORY_ALGORITHM);
			KeySpec spec = new PBEKeySpec(password.toCharArray(), salt, ITERATION_COUNT, KEY_LENGTH);
			SecretKey tmp = factory.generateSecret(spec);
			SecretKey secret = new SecretKeySpec(tmp.getEncoded(), SECRET_KEY_SPEC_ALGORITHM);
			Cipher cipher = Cipher.getInstance(PADDING);

			cipher.init(Cipher.DECRYPT_MODE, secret, new IvParameterSpec(iv));

			return cipher.doFinal(ct);
		} catch (NoSuchAlgorithmException | InvalidKeySpecException | NoSuchPaddingException | InvalidKeyException
				| InvalidAlgorithmParameterException | IllegalBlockSizeException | BadPaddingException e) {
			throw new CipherException("Decrypt failed", e);
		}
	}

	public static byte[] decrypt(byte[] encryptedData, String password, String salt, String iv) throws CipherException {
		try {
			SecretKeyFactory factory = SecretKeyFactory.getInstance(SECRET_KEY_FACTORY_ALGORITHM);
			KeySpec spec = new PBEKeySpec(password.toCharArray(), salt.getBytes(), ITERATION_COUNT, KEY_LENGTH);
			SecretKey tmp = factory.generateSecret(spec);
			SecretKey secret = new SecretKeySpec(tmp.getEncoded(), SECRET_KEY_SPEC_ALGORITHM);
			Cipher cipher = Cipher.getInstance(PADDING);

			cipher.init(Cipher.DECRYPT_MODE, secret, new IvParameterSpec(iv.getBytes()));

			return cipher.doFinal(encryptedData);
		} catch (NoSuchAlgorithmException | InvalidKeySpecException | NoSuchPaddingException | InvalidKeyException
				| InvalidAlgorithmParameterException | IllegalBlockSizeException | BadPaddingException e) {
			throw new CipherException("Decrypt failed", e);
		}
	}

	public static String createCheckSum(byte[] data) throws NoSuchAlgorithmException, IOException {
		StringBuilder fileChecksum = new StringBuilder("");
		MessageDigest md = MessageDigest.getInstance("MD5");
		InputStream is = new ByteArrayInputStream(data);
		byte[] dataBytes = new byte[DEFAULT_BUFFER_SIZE];
		int length = -1;

		while ((length = is.read(dataBytes)) != -1) {
			md.update(dataBytes, 0, length);
		}
		byte[] digestedData = md.digest();

		// Convert the byte to hex format.
		for (int i = 0; i < digestedData.length; i++) {
			fileChecksum.append(Integer.toString((digestedData[i] & 0xff) + 0x100, 16).substring(1));
		}

		return fileChecksum.toString();
	}

	public static boolean validateCheckSum(byte[] data, String checkSumText)
			throws NoSuchAlgorithmException, IOException {
		MessageDigest md = MessageDigest.getInstance("MD5");
		InputStream is = new ByteArrayInputStream(data);
		byte[] dataBytes = new byte[DEFAULT_BUFFER_SIZE];
		int length = 0;

		while ((length = is.read(dataBytes)) != -1) {
			md.update(dataBytes, 0, length);
		}
		byte[] digestedData = md.digest();

		// Convert the byte to hex format.
		StringBuilder checkSumMessage = new StringBuilder("");
		for (int i = 0; i < digestedData.length; i++) {
			checkSumMessage.append(Integer.toString((digestedData[i] & 0xff) + 0x100, 16).substring(1));
		}

		return checkSumMessage.toString().equals(checkSumText);
	}
}
