package com.appman.core.syncservice.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RevNotDefinedErrorDetail implements Serializable {
	private static final long serialVersionUID = 4681021486551289440L;

	private String error;
}
