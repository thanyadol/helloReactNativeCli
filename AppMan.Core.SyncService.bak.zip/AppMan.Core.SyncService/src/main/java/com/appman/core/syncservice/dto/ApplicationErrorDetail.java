package com.appman.core.syncservice.dto;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ApplicationErrorDetail implements Serializable {
	private static final long serialVersionUID = 8490469024841178624L;
	private static final String TIME_FORMAT_PATTERN = "dd/MM/yyyy HH:mm:ss:SSSS";

	private Date timestamp;
	private String time;
	private String country;
	private String message;
	private String detail;
	private String stacktrace;

	public ApplicationErrorDetail(String message, String detail, String stacktrace) {
		this.timestamp = new Date();
		this.time = new SimpleDateFormat(TIME_FORMAT_PATTERN).format(timestamp);
		this.country = System.getProperty("user.country");
		this.message = message;
		this.detail = detail;
		this.stacktrace = stacktrace;
	}
}
