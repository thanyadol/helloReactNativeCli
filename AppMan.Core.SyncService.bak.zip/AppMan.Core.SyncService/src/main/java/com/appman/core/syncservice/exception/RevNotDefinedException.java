package com.appman.core.syncservice.exception;

public class RevNotDefinedException extends Exception {
	private static final long serialVersionUID = 9160773338766328026L;
	public static final String REV_NOT_DEFINED = "Rev not defined";

	public RevNotDefinedException() {
		super(REV_NOT_DEFINED);
	}

	public RevNotDefinedException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public RevNotDefinedException(String message, Throwable cause) {
		super(message, cause);
	}

	public RevNotDefinedException(String message) {
		super(message);
	}

	public RevNotDefinedException(Throwable cause) {
		super(REV_NOT_DEFINED, cause);
	}
}
