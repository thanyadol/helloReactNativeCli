package com.appman.core.syncservice.repository;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.repository.CrudRepository;

import com.appman.core.syncservice.model.DraftDatas;

@Qualifier(value = "draftDataCrudRepository")
public interface DraftDataCrudRepository extends CrudRepository<DraftDatas, Long> {

}
