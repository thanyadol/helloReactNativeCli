package com.appman.core.syncservice.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.appman.core.syncservice.dto.HealthStatus;
import com.appman.core.syncservice.property.EnvironmentPropertyLoader;

import io.swagger.annotations.ApiOperation;

@RestController
public class HomeController {
	private static final Logger log = LoggerFactory.getLogger(HomeController.class);

	@Autowired
	private EnvironmentPropertyLoader property;

	@CrossOrigin(origins = "*")
	@ApiOperation(value = "Health check.")
	@GetMapping(value = "/health", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public HealthStatus health() {
		return new HealthStatus("ok", property.getBuildDate());
	}

	@PostConstruct
	public void initialize() throws IOException {
		log.info(">>>>> Initialize <<<<<");
		boolean localStorageExists = Files.exists(Paths.get(property.getStoragePath()));
		log.info(">>>>> Storage :{} exists :{}", property.getStoragePath(), localStorageExists);
		if (!localStorageExists) {
			Files.createDirectory(Paths.get(property.getStoragePath()));
		}
		log.info(">>>>> Local Storage :{}", Paths.get(property.getStoragePath()).toAbsolutePath());
	}
}
