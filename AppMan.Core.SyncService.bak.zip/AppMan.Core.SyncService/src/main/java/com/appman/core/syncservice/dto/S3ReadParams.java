package com.appman.core.syncservice.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class S3ReadParams extends ReadParams implements Serializable {
	private static final long serialVersionUID = -1088996749668008664L;

	@JsonProperty("Bucket")
	private String bucket;

	public S3ReadParams(String key, String bucket) {
		super(key);
		this.bucket = bucket;
	}
}
