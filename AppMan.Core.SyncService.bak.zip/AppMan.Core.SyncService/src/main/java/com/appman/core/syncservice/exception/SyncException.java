package com.appman.core.syncservice.exception;

public class SyncException extends Exception {

	private static final long serialVersionUID = 9171902145049457496L;

	public SyncException() {
		super();
	}

	public SyncException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public SyncException(String message, Throwable cause) {
		super(message, cause);
	}

	public SyncException(String message) {
		super(message);
	}

	public SyncException(Throwable cause) {
		super(cause);
	}
}
