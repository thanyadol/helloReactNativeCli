package com.appman.core.syncservice.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class RetrieveResponse implements Serializable {
	private static final long serialVersionUID = -1083445245258577503L;

	@ApiModelProperty(notes = "File's UUID from database", example = "e9d2e333-876f-4f6c-898d-10e5b2406a6c", position = 10)
	@JsonProperty("fileUID")
	private String fileUID;
	
	@ApiModelProperty(notes = "File content type", example = "image/png", position = 20)
	@JsonProperty("contentType")
	private String contentType;
	
	@ApiModelProperty(notes = "Base64 file data", example = "TU0AKgAAAAgADAEAAAMAAAAB==", position = 30)
	@JsonProperty("contentBody")
	private String contentBody;
	
	@ApiModelProperty(notes = "Check sum of binary data before converted to base64 for verification", example = "Axbg0x89dx", position = 40)
	@JsonProperty("checksum")
	private String checksum;
}
