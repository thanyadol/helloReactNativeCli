package com.appman.core.syncservice.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.appman.core.syncservice.dto.AttachmentNotValidErrorDetail;
import com.appman.core.syncservice.dto.DataNotFoundErrorDetail;
import com.appman.core.syncservice.dto.InvalidFileErrorDetail;
import com.appman.core.syncservice.dto.KeyNotDefinedErrorDetail;
import com.appman.core.syncservice.dto.RevNotDefinedErrorDetail;
import com.appman.core.syncservice.dto.RevNotMatchedErrorDetail;
import com.appman.core.syncservice.dto.ApplicationErrorDetail;
import com.appman.core.syncservice.dto.AttachmentErrorDetail;
import com.appman.core.syncservice.exception.ApplicationException;
import com.appman.core.syncservice.exception.AttachmentException;
import com.appman.core.syncservice.exception.AttachmentNotValidException;
import com.appman.core.syncservice.exception.DataNotFoundException;
import com.appman.core.syncservice.exception.InvalidFileException;
import com.appman.core.syncservice.exception.KeyNotDefinedException;
import com.appman.core.syncservice.exception.RevNotDefinedException;
import com.appman.core.syncservice.exception.RevNotMatchedException;
import com.appman.core.syncservice.util.StackTraceUtil;

@ControllerAdvice(annotations = RestController.class)
@RestController
public class ApplicationExceptionHandler extends ResponseEntityExceptionHandler {
	private static final Logger log = LoggerFactory.getLogger(ApplicationExceptionHandler.class);

	@ExceptionHandler(ApplicationException.class)
	public final ResponseEntity<ApplicationErrorDetail> handleException(ApplicationException e, WebRequest request) {
		log.error("ApplicationException sessionId :{}", request.getSessionId(), e);
		return new ResponseEntity<>(new ApplicationErrorDetail(e.getMessage(), request.getDescription(false),
				StackTraceUtil.respondStackTrace(e)), HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(AttachmentNotValidException.class)
	public final ResponseEntity<AttachmentNotValidErrorDetail> handleAttachmentNotValidException(
			AttachmentNotValidException e, WebRequest request) {
		log.error("AttachmentNotValidException sessionId :{}", request.getSessionId(), e);
		return new ResponseEntity<>(new AttachmentNotValidErrorDetail(e.getMessage(), e.getAttachments()),
				HttpStatus.PRECONDITION_FAILED);
	}

	@ExceptionHandler(DataNotFoundException.class)
	public final ResponseEntity<DataNotFoundErrorDetail> handleDataNotFoundException(DataNotFoundException e,
			WebRequest request) {
		log.error("DataNotFoundException sessionId :{}", request.getSessionId(), e);
		return new ResponseEntity<>(new DataNotFoundErrorDetail(e.getKey(), e.getMessage()), HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(RevNotMatchedException.class)
	public final ResponseEntity<RevNotMatchedErrorDetail> handleRevNotMatchedException(RevNotMatchedException e,
			WebRequest request) {
		log.error("RevNotMatchedException sessionId :{}", request.getSessionId(), e);
		return new ResponseEntity<>(new RevNotMatchedErrorDetail(e.getMessage(), e.getData()), HttpStatus.CONFLICT);
	}

	@ExceptionHandler(RevNotDefinedException.class)
	public final ResponseEntity<RevNotDefinedErrorDetail> handleRevNotDefinedException(RevNotDefinedException e,
			WebRequest request) {
		log.error("RevNotDefinedException sessionId :{}", request.getSessionId(), e);
		return new ResponseEntity<>(new RevNotDefinedErrorDetail(e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(KeyNotDefinedException.class)
	public final ResponseEntity<KeyNotDefinedErrorDetail> handleRevNotDefinedException(KeyNotDefinedException e,
			WebRequest request) {
		log.error("KeyNotDefinedException sessionId :{}", request.getSessionId(), e);
		return new ResponseEntity<>(new KeyNotDefinedErrorDetail(e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(InvalidFileException.class)
	public final ResponseEntity<InvalidFileErrorDetail> handleInvalidFileException(InvalidFileException e,
			WebRequest request) {
		log.error("InvalidFileException sessionId :{}", request.getSessionId(), e);
		return new ResponseEntity<>(
				new InvalidFileErrorDetail(e.getMessage(), e.getFileUIDString(), StackTraceUtil.respondStackTrace(e)),
				HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(AttachmentException.class)
	public final ResponseEntity<AttachmentErrorDetail> handleAttachmentException(AttachmentException e,
			WebRequest request) {
		log.error("AttachmentException sessionId :{}", request.getSessionId(), e);
		return new ResponseEntity<>(new AttachmentErrorDetail(e.getMessage(), StackTraceUtil.respondStackTrace(e)),
				HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
