package com.appman.core.syncservice.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.io.input.ReversedLinesFileReader;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.appman.core.syncservice.dto.LogData;
import com.appman.core.syncservice.dto.LogRequest;

import io.swagger.annotations.ApiOperation;

@Controller
public class LogController {
	private static final Logger log = LoggerFactory.getLogger(LogController.class);
	private static final String PDF_SERVICE_LOG = "sync-service.log";
	private static final int MAX_LOG_LINE = 1000;
	private static final Charset DEFAULT_CHARSET = Charset.forName("UTF-8");

	@CrossOrigin(origins = "*")
	@ApiOperation(value = "List server file.")
	@PostMapping(path = "/log/list", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ResponseBody
	public List<LogData> listLogFile(@RequestBody LogRequest requestLogData) {
		List<LogData> logDatas = new ArrayList<>();
		File file = null;

		if (requestLogData == null || StringUtils.isEmpty(requestLogData.getPath())) {
			file = new File(".");
		} else {
			file = new File(requestLogData.getPath());
		}

		final File[] files = file.listFiles();
		if (files != null) {
			Arrays.stream(files).forEach(f -> logDatas.add(new LogData(f.getAbsolutePath(), f.length())));
		}

		return logDatas;
	}

	@CrossOrigin(origins = "*")
	@ApiOperation(value = "Download a file.")
	@PostMapping(path = "/log/load", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ResponseBody
	public byte[] getLogFile(@RequestBody LogRequest requestLogData) {
		byte[] result = null;
		String path = requestLogData.getPath();

		if (StringUtils.isEmpty(path)) {
			path = PDF_SERVICE_LOG;
		}

		try (FileInputStream fi = new FileInputStream(new File(path))) {
			result = new byte[fi.available()];
			log.info("Log :{} size :{}", path, fi.read(result));
		} catch (IOException e) {
			log.error("IO Error :", e);
		}

		return result;
	}

	@CrossOrigin(origins = "*")
	@ApiOperation(value = "List file's contents.")
	@PostMapping(path = "/log/line", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ResponseBody
	public byte[] getLogLine(@RequestBody LogRequest requestLogData) {
		byte[] result = null;
		File file = null;

		if (StringUtils.isEmpty(requestLogData.getPath())) {
			file = new File(PDF_SERVICE_LOG);
		}
		else {
			file = new File(requestLogData.getPath());
		}

		if (requestLogData.getLine() > MAX_LOG_LINE) {
			requestLogData.setLine(MAX_LOG_LINE);
		}

		if (file.exists() && file.canRead() && file.isFile()) {
			try (ReversedLinesFileReader reader = new ReversedLinesFileReader(file, DEFAULT_CHARSET)) {
				int line = 0;
				StringBuilder content = new StringBuilder("");
				String message = null;
				while (line++ < requestLogData.getLine()) {
					message = reader.readLine();
					if (message == null) {
						break;
					}
					content.append(message);
				} // end while
				result = content.toString().getBytes();
			} catch (IOException e) {
				log.warn("Error while loading file exist :{}, path :{}", file.exists(), requestLogData.getPath());
			}
		} else {
			log.info("Unable to read file :{}", requestLogData.getPath());
		}

		return result;
	}
}
