package com.appman.core.syncservice.exception;

public class CipherException extends Exception {
	private static final long serialVersionUID = -3244933686707009607L;

	public CipherException() {
		super();
	}

	public CipherException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public CipherException(String message, Throwable cause) {
		super(message, cause);
	}

	public CipherException(String message) {
		super(message);
	}

	public CipherException(Throwable cause) {
		super(cause);
	}
}
