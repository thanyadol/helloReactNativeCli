package com.appman.core.syncservice.controller;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.appman.core.syncservice.dto.FetchRequest;
import com.appman.core.syncservice.dto.FetchResponse;
import com.appman.core.syncservice.dto.PushDraftRequestModel;
import com.appman.core.syncservice.exception.ApplicationException;
import com.appman.core.syncservice.exception.AttachmentNotValidException;
import com.appman.core.syncservice.exception.DataNotFoundException;
import com.appman.core.syncservice.exception.KeyNotDefinedException;
import com.appman.core.syncservice.exception.RevNotDefinedException;
import com.appman.core.syncservice.exception.RevNotMatchedException;
import com.appman.core.syncservice.model.PushRequest;
import com.appman.core.syncservice.model.PushResponse;
import com.appman.core.syncservice.model.DraftDatas;
import com.appman.core.syncservice.property.EnvironmentPropertyLoader;
import com.appman.core.syncservice.service.SyncDraftService;
import com.appman.core.syncservice.util.JsonUtil;

import io.swagger.annotations.ApiOperation;

@RestController
public class SyncController {
	private static final Logger log = LoggerFactory.getLogger(SyncController.class);

	@Autowired
	private SyncDraftService syncDraftService;

	@Autowired
	private EnvironmentPropertyLoader property;

	@CrossOrigin(origins = "*")
	@ApiOperation(value = "Load data by (String) Owner(exactly match), (Long) LatestUpdatedAt (greater than) and (Integer) Limit (result amount) parameters")
	@GetMapping(value = "/fetch", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public FetchResponse fetch(@RequestParam(name = "owner", required = false) String owner,
			@RequestParam(name = "latestUpdatedAt", required = false) Long latestUpdatedAt,
			@RequestParam(name = "limit", required = false) Integer limit) throws ApplicationException {
		log.info("Fetch request owner :{}, latestUpdatedAt :{}, limit :{}", owner, latestUpdatedAt, limit);
		String ownerQuery = owner;
		if (StringUtils.isEmpty(ownerQuery)) {
			ownerQuery = property.getOwner();
		}
		FetchRequest fetchRequest = new FetchRequest(ownerQuery, latestUpdatedAt, limit);
		try {
			return syncDraftService.fetch(fetchRequest);
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
	}

	@CrossOrigin(origins = "*")
	@ApiOperation(value = "Load data by front-end Key")
	@GetMapping(value = "/fetch/{key}", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public PushResponse fetchOne(@PathVariable String key) throws DataNotFoundException, ApplicationException {
		log.info("FetchOne request key :{}", key);
		try {
			return new PushResponse(property.getOwner(), syncDraftService.fetchOne(key));
		} catch (DataNotFoundException e) {
			throw e;
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
	}

	@CrossOrigin(origins = "*")
	@ApiOperation(value = "Create/Update a single data with it's rev")
	@PostMapping(value = "/push", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public PushResponse pushData(@RequestBody PushDraftRequestModel req) throws AttachmentNotValidException,
			RevNotMatchedException, RevNotDefinedException, KeyNotDefinedException, ApplicationException {
		try {
			log.info("Push request :{}", req);
			syncDraftService.validateAttachment(req.getAttachments());
		} catch (AttachmentNotValidException e) {
			throw e;
		} catch (Exception e) {
			throw new ApplicationException(e);
		}

		try {
			PushResponse response = syncDraftService
					.push(new PushRequest(property.getOwner(), new DraftDatas(req.getKey(), req.getRev(),
							req.getDraftType(), JsonUtil.mapper.writeValueAsString(req.getData()))));
			response.getBody().setAttachments(req.getAttachments());
			return response;
		} catch (RevNotMatchedException | KeyNotDefinedException | RevNotDefinedException e) {
			throw e;
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
	}
}
