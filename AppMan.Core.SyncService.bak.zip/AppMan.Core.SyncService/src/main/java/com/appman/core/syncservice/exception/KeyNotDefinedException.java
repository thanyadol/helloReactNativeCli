package com.appman.core.syncservice.exception;

public class KeyNotDefinedException extends Exception {
	private static final long serialVersionUID = 8901646416908781132L;

	public KeyNotDefinedException() {
		super("Key not defined");
	}

	public KeyNotDefinedException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public KeyNotDefinedException(String message, Throwable cause) {
		super(message, cause);
	}

	public KeyNotDefinedException(String message) {
		super(message);
	}

	public KeyNotDefinedException(Throwable cause) {
		super("Key not defined", cause);
	}
}
