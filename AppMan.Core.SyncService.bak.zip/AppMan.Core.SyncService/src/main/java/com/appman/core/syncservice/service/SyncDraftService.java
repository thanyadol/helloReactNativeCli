package com.appman.core.syncservice.service;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.appman.core.syncservice.dto.FetchRequest;
import com.appman.core.syncservice.dto.FetchResponse;
import com.appman.core.syncservice.dto.PushDraftRequestModel;
import com.appman.core.syncservice.enumeration.EnumFileStatus;
import com.appman.core.syncservice.exception.AttachmentNotValidException;
import com.appman.core.syncservice.exception.DataNotFoundException;
import com.appman.core.syncservice.exception.KeyNotDefinedException;
import com.appman.core.syncservice.exception.RevNotDefinedException;
import com.appman.core.syncservice.exception.RevNotMatchedException;
import com.appman.core.syncservice.exception.SyncException;
import com.appman.core.syncservice.model.Attachment;
import com.appman.core.syncservice.model.PushRequest;
import com.appman.core.syncservice.model.PushResponse;
import com.appman.core.syncservice.model.DraftDatas;
import com.appman.core.syncservice.property.EnvironmentPropertyLoader;
import com.appman.core.syncservice.repository.AttachmentRepository;
import com.appman.core.syncservice.repository.DraftDataCrudRepository;
import com.appman.core.syncservice.repository.DraftDataRepository;
import com.appman.core.syncservice.util.AppUtil;
import com.appman.core.syncservice.util.JsonUtil;
import com.fasterxml.jackson.core.JsonProcessingException;

@Service
@Transactional(readOnly = true)
public class SyncDraftService {
	private static final Logger log = LoggerFactory.getLogger(SyncDraftService.class);

	@Autowired
	@Qualifier("draftDataRepository")
	private DraftDataRepository draftDataRepository;

	@Autowired
	@Qualifier("draftDataCrudRepository")
	private DraftDataCrudRepository draftDataCrudRepository;

	@Autowired
	@Qualifier("attachmentRepository")
	private AttachmentRepository attachmentRepository;

	@Autowired
	private EnvironmentPropertyLoader property;

	public FetchResponse fetch(FetchRequest fetchRequest) {
		Pageable pageable = PageRequest.of(0, fetchRequest.getLimit(), Sort.by("updatedAt").ascending());
		int total = draftDataRepository.countByOwnerAndUpdatedAtGreaterThan(fetchRequest.getOwner(),
				fetchRequest.getLatestUpdatedAt());
		List<DraftDatas> data = draftDataRepository.findByOwnerAndUpdatedAtGreaterThanOrderByUpdatedAtAsc(
				fetchRequest.getOwner(), fetchRequest.getLatestUpdatedAt(), pageable);
		FetchResponse fetchResponse = new FetchResponse();
		fetchResponse.setOwner(fetchRequest.getOwner());
		fetchResponse.setCount(data.size());
		fetchResponse.setTotal(total);
		fetchResponse.setResourceDatas(data);
		if (!data.isEmpty()) {
			fetchResponse.setLatestUpdatedAt(data.get(data.size() - 1).getUpdatedAt());
		} else {
			if (fetchRequest.getLatestUpdatedAt() != null) {
				fetchResponse.setLatestUpdatedAt(fetchRequest.getLatestUpdatedAt());
			} else {
				fetchResponse.setLatestUpdatedAt(AppUtil.getUnixTime());
			}
		}

		return fetchResponse;
	}

	public DraftDatas fetchOne(String key) throws DataNotFoundException {
		DraftDatas data = draftDataRepository.findTop1ByKeyOrderByUpdatedAtDesc(key);
		if (data == null) {
			throw new DataNotFoundException(DataNotFoundException.DATA_NOT_FOUND_MESSAGE, key);
		}
		return data;
	}

	private String getRevision(DraftDatas data) {
		// Revision always changed every persisting time.
		return AppUtil.getRevision(data.getData() + data.getUpdatedAt() + AppUtil.getGUID());
	}

	public PushResponse pushData(PushDraftRequestModel req) throws SyncException {
		try {
			validateAttachment(req.getAttachments());

			PushResponse response = push(new PushRequest(property.getOwner(), new DraftDatas(req.getKey(), req.getRev(),
					req.getDraftType(), JsonUtil.mapper.writeValueAsString(req.getData()))));
			response.getBody().setAttachments(req.getAttachments());
			return response;
		} catch (AttachmentNotValidException | JsonProcessingException | KeyNotDefinedException | RevNotDefinedException
				| RevNotMatchedException e) {
			throw new SyncException(e);
		}
	}

	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public PushResponse push(PushRequest pushRequest)
			throws KeyNotDefinedException, RevNotDefinedException, RevNotMatchedException {
		long nowUnixTime = AppUtil.getUnixTime();

		if (pushRequest.getBody() == null || StringUtils.isEmpty(pushRequest.getBody().getKey())) {
			throw new KeyNotDefinedException();
		}

		DraftDatas data = draftDataRepository.findTop1ByKeyOrderByUpdatedAtDesc(pushRequest.getBody().getKey());
		if (data == null) {
			// Create new data
			data = new DraftDatas();
			data.setCreatedAt(nowUnixTime);
			data.setCreatedBy(pushRequest.getPushedBy());
			data.setKey(pushRequest.getBody().getKey());
		} else {
			// Update existing data
			if (StringUtils.isEmpty(pushRequest.getBody().getRev())) {
				throw new RevNotDefinedException();
			}

			if (!data.getRev().equals(pushRequest.getBody().getRev())) {
				throw new RevNotMatchedException(pushRequest.getBody().getRev(), data);
			}
		}

		data.setData(pushRequest.getBody().getData());
		data.setDraftType(pushRequest.getBody().getDraftType());
		data.setOwner(pushRequest.getPushedBy());
		data.setRev(getRevision(pushRequest.getBody()));
		data.setUpdatedAt(nowUnixTime);
		data.setUpdatedBy(pushRequest.getPushedBy());
		data = draftDataCrudRepository.save(data);

		return new PushResponse(pushRequest.getPushedBy(), data);
	}

	/**
	 * Validate related attachments(s), All specific attachments must exists in database and their status are available.
	 **/
	public void validateAttachment(Map<String, UUID> attachments) throws AttachmentNotValidException {
		if (!attachments.isEmpty()) {
			// Query looking for matching fileUID where status is AVAILABLE.
			List<Attachment> attachmentList = attachmentRepository.findByFileUIDInAndStatus(attachments.values(),
					EnumFileStatus.AVAILABLE);

			Map<UUID, UUID> attachmentMap = attachmentListToMap(attachmentList);
			Map<String, UUID> errorResult = new LinkedHashMap<>();

			// If not found parameter attachments in the query result, then add every not found item(s) to the list
			// and throw error AttachmentNotValid with that list.
			attachments.keySet().forEach(parameterKey -> {
				UUID parameterValue = attachments.get(parameterKey);
				if (attachmentMap.get(parameterValue) == null) {
					errorResult.put(parameterKey, parameterValue);
				}
			});

			if (!errorResult.isEmpty()) {
				String additionalMessage = "";
				try {
					additionalMessage = JsonUtil.mapper.writeValueAsString(errorResult);
				} catch (JsonProcessingException e) {
					log.error("JsonProcessing error :", e);
				}
				throw new AttachmentNotValidException(errorResult, additionalMessage);
			}
		}
	}

	private Map<UUID, UUID> attachmentListToMap(List<Attachment> attachments) {
		Map<UUID, UUID> result = new LinkedHashMap<>();

		// Convert all results to Map
		for (Attachment attachment : attachments) {
			result.put(attachment.getFileUID(), attachment.getFileUID());
		}

		return result;
	}
}
