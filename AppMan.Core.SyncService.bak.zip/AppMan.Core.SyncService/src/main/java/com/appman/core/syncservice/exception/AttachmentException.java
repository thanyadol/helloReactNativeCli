package com.appman.core.syncservice.exception;

public class AttachmentException extends Exception {

	private static final long serialVersionUID = 298967590665950244L;

	public AttachmentException() {
		super();
	}

	public AttachmentException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public AttachmentException(String message, Throwable cause) {
		super(message, cause);
	}

	public AttachmentException(String message) {
		super(message);
	}

	public AttachmentException(Throwable cause) {
		super(cause);
	}
}
