package com.appman.core.syncservice.service;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.appman.core.syncservice.dto.EncryptionParams;
import com.appman.core.syncservice.exception.CipherException;
import com.appman.core.syncservice.util.CipherUtil;

@Service
@Qualifier("aesCipherService")
public class AESCipherService implements ICipherService {

	@Override
	public EncryptionParams encrypt(byte[] data) throws CipherException {
		return CipherUtil.aesEncrypt(data);
	}

	@Override
	public byte[] decrypt(byte[] encryptedData, EncryptionParams encryptionParams) throws CipherException {
		return CipherUtil.aesDecrypt(encryptedData, encryptionParams);
	}
}
