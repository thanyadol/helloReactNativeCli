package com.appman.core.syncservice.dto;

import java.io.Serializable;

import lombok.Data;

@Data
public class EncryptResult implements Serializable {
	private static final long serialVersionUID = 1552524680060335778L;

	private byte[] cipher;
	private byte[] byteIV;
	private byte[] byteSalt;
	private String password;
	private long encryptionTime;
	private long keyGenerationTime;
}
