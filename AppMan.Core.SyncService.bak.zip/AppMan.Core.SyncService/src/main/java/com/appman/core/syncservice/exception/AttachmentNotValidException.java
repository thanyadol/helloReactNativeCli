package com.appman.core.syncservice.exception;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AttachmentNotValidException extends Exception {
	private static final long serialVersionUID = -5661901334343942194L;
	private static final String MESSAGE = "Attachments not valid";

	@JsonProperty("attachments")
	private Map<String, UUID> attachments = new LinkedHashMap<>();

	public AttachmentNotValidException() {
		super();
	}

	public AttachmentNotValidException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public AttachmentNotValidException(String message, Throwable cause) {
		super(message, cause);
	}

	public AttachmentNotValidException(String message) {
		super(message);
	}

	public AttachmentNotValidException(Throwable cause) {
		super(MESSAGE, cause);
	}

	public AttachmentNotValidException(Map<String, UUID> attachments, Throwable cause) {
		super(MESSAGE, cause);
		this.attachments = attachments;
	}

	public AttachmentNotValidException(Map<String, UUID> attachments) {
		super(MESSAGE);
		this.attachments = attachments;
	}

	public AttachmentNotValidException(Map<String, UUID> attachments, String additionalMessage) {
		super(MESSAGE);
		this.attachments = attachments;
	}

	public Map<String, UUID> getAttachments() {
		return attachments;
	}

	public void setAttachments(Map<String, UUID> attachments) {
		this.attachments = attachments;
	}
}
