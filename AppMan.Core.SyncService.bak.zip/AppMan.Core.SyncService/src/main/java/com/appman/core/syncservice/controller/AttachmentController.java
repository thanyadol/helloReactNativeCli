package com.appman.core.syncservice.controller;

import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.appman.core.syncservice.dto.Base64File;
import com.appman.core.syncservice.dto.DeleteRequest;
import com.appman.core.syncservice.dto.DeleteResponse;
import com.appman.core.syncservice.dto.RetrieveRequest;
import com.appman.core.syncservice.dto.RetrieveResponse;
import com.appman.core.syncservice.dto.SaveBatchAttachmentRequest;
import com.appman.core.syncservice.dto.SaveBatchAttachmentResponse;
import com.appman.core.syncservice.exception.ApplicationException;
import com.appman.core.syncservice.exception.AttachmentException;
import com.appman.core.syncservice.exception.InvalidFileException;
import com.appman.core.syncservice.model.Attachment;
import com.appman.core.syncservice.property.EnvironmentPropertyLoader;
import com.appman.core.syncservice.service.AttachmentService;
import com.appman.core.syncservice.util.CipherUtil;

import io.swagger.annotations.ApiOperation;

@RestController
public class AttachmentController {
	private static final Logger log = LoggerFactory.getLogger(AttachmentController.class);

	@Autowired
	private AttachmentService attachmentService;

	@Autowired
	private EnvironmentPropertyLoader property;

	@CrossOrigin(origins = "*")
	@ApiOperation(value = "Upload file(s)")
	@PostMapping(path = "/attachment/add", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public SaveBatchAttachmentResponse addAttachment(@RequestBody SaveBatchAttachmentRequest request)
			throws ApplicationException {
		SaveBatchAttachmentResponse response = new SaveBatchAttachmentResponse();
		if (request.getAttachments() == null) {
			return response;
		}

		try {
			Attachment attachment = null;
			for (Base64File file : request.getAttachments()) {
				file.setRaw(CipherUtil.base64ToByteArray(file.getContentBody()));
				file.setOwner(property.getOwner());
				attachment = attachmentService.saveAttachment(file);
				response.putAttachment(file.getLocalFileID(), attachment.getFileUID());
			}
			return response;
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
	}

	@CrossOrigin(origins = "*")
	@ApiOperation(value = "Delete an uploaded file")
	@DeleteMapping(path = "/attachment/remove/{fileUID}", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public DeleteResponse removeAttachment(@PathVariable String fileUID)
			throws InvalidFileException, AttachmentException, ApplicationException {
		log.info("Delete fileUID :{}", fileUID);
		try {
			Attachment attachment = attachmentService
					.removeAttachment(new DeleteRequest(property.getOwner(), UUID.fromString(fileUID)));
			return new DeleteResponse(attachment.getFileUID().toString());
		} catch (InvalidFileException | AttachmentException e) {
			throw e;
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
	}

	@CrossOrigin(origins = "*")
	@ApiOperation(value = "Retrieve uploaded file")
	@GetMapping(path = "/attachment/get/{fileUID}", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public RetrieveResponse getAttachment(@PathVariable String fileUID)
			throws InvalidFileException, AttachmentException, ApplicationException {
		try {
			return attachmentService.getAttachment(new RetrieveRequest(property.getOwner(), UUID.fromString(fileUID)));
		} catch (InvalidFileException | AttachmentException e) {
			throw e;
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
	}
}
