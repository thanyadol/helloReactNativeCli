package com.appman.core.syncservice.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DeleteResponse implements Serializable {
	private static final long serialVersionUID = -7533620576198120789L;

	@ApiModelProperty(notes = "File's UUID from database", example = "e9d2e333-876f-4f6c-898d-10e5b2406a6c", position = 10)
	@JsonProperty("fileUID")
	private String fileUID;
}
