package com.appman.core.syncservice.service;

import com.appman.core.syncservice.dto.EncryptionParams;
import com.appman.core.syncservice.exception.CipherException;

public interface ICipherService {
	EncryptionParams encrypt(byte[] data) throws CipherException;
	byte[] decrypt(byte[] encryptedData, EncryptionParams encryptionParams) throws CipherException;
}
