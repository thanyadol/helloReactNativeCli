package com.appman.core.syncservice.exception;

import com.appman.core.syncservice.model.DraftDatas;

public class RevNotMatchedException extends Exception {
	private static final long serialVersionUID = 6795544394476796151L;
	public static final String REV_NOT_MATCHED = "Rev not matched";
	private String rev;
	private DraftDatas data;

	public RevNotMatchedException() {
		super(REV_NOT_MATCHED);
	}

	public RevNotMatchedException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public RevNotMatchedException(String message, Throwable cause) {
		super(message, cause);
	}

	public RevNotMatchedException(String message) {
		super(message);
	}

	public RevNotMatchedException(Throwable cause) {
		super(REV_NOT_MATCHED, cause);
	}
	
	public RevNotMatchedException(String rev, DraftDatas data) {
		super(REV_NOT_MATCHED);
		this.rev = rev;
		this.data = data;
	}

	public String getRev() {
		return rev;
	}

	public void setRev(String rev) {
		this.rev = rev;
	}

	public DraftDatas getData() {
		return data;
	}

	public void setData(DraftDatas data) {
		this.data = data;
	}
}
