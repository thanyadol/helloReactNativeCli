package com.appman.core.syncservice.service;

import java.io.IOException;
import java.util.UUID;

import com.appman.core.syncservice.dto.EncryptionParams;
import com.appman.core.syncservice.dto.ReadParams;
import com.appman.core.syncservice.exception.AttachmentStorageException;

public interface IAttachmentStorage {
	String getStorageType();

	/* Casting readParams to ReadParams object depends on implementations */
	ReadParams as(ReadParams readParams);

	/* Read raw data using specific ReadParams */
	byte[] readData(ReadParams params) throws AttachmentStorageException;

	/* Delete data from storage */
	ReadParams deleteData(ReadParams params) throws AttachmentStorageException;

	/* Write data to storage. Returns stringified params used for read data. */
	// <param name="data">Byte array of data</param>
	ReadParams writeData(ReadParams params, byte[] data) throws AttachmentStorageException;

	/* Create ReadParams object with assigned UUID. */
	ReadParams getReadParams(UUID uuid);

	/* Convert json string parameter to ReadParams object. */
	ReadParams fromReadParamsText(String param) throws IOException;

	/* Convert json string parameter from Attachments database to EncryptionParams object. */
	EncryptionParams fromEncryptionParamsText(String param) throws IOException;
}
