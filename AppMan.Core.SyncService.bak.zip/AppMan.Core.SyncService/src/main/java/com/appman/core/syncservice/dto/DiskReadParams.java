package com.appman.core.syncservice.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
public class DiskReadParams extends ReadParams implements Serializable {
	private static final long serialVersionUID = 7838645978360219758L;

	@JsonProperty("Path")
	private String path;

	public DiskReadParams(String key, String path) {
		super(key);
		this.path = path;
	}
}
