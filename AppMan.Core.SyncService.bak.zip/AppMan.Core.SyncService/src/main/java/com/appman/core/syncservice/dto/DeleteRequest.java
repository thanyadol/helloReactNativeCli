package com.appman.core.syncservice.dto;

import java.io.Serializable;
import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DeleteRequest implements Serializable {
	private static final long serialVersionUID = -5962293244185408902L;

	private String owner;
	private UUID fileUID;
}
