package com.appman.core.syncservice.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SaveResponse implements Serializable{
	private static final long serialVersionUID = -2210130548023126067L;
	
	private String fileUID;
}
