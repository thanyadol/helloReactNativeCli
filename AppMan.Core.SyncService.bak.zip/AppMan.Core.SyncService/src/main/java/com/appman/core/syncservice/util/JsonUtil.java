package com.appman.core.syncservice.util;

import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonUtil {

	public static final ObjectMapper mapper = new ObjectMapper();
	private JsonUtil() {}
}
