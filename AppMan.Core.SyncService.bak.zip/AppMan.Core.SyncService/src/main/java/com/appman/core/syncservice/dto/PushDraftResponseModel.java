package com.appman.core.syncservice.dto;

import java.io.Serializable;
import java.util.Map;

import lombok.Data;

@Data
public class PushDraftResponseModel implements Serializable {
	private static final long serialVersionUID = 2756133524139052775L;

	private String key;
	private String rev;
	private transient Object data;
	private String draftType;
	private long createdAt;
	private long updatedAt;

	private Map<String, String> attachments;
}
