package com.appman.core.syncservice.dto;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class LogData implements Serializable{
	private static final long serialVersionUID = -7088052167429623314L;

	@ApiModelProperty(notes = "Result file path. examples :'.', './sync-service.log', '../'", example = "./sync-service.log")
	@JsonProperty("path")
	private String path;

	@ApiModelProperty(notes = "Result file created date.")
	@JsonProperty("created")
	private Date created;

	@ApiModelProperty(notes = "Result file updated date.")
	@JsonProperty("updated")
	private Date updated;

	@ApiModelProperty(notes = "Result file size.")
	@JsonProperty("size")
	private long size;
	
	public LogData(String path) {
		this.path = path;
	}
	
	public LogData(String path, long size) {
		this.path = path;
		this.size = size;
	}
	
	public LogData(String path, Date created, Date updated) {
		this.path = path;
		this.created = created;
		this.updated = updated;
	}
}
