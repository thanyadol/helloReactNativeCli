package com.appman.core.syncservice.config;

import java.io.IOException;

import javax.naming.NamingException;
import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jndi.JndiTemplate;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.appman.core.syncservice.property.EnvironmentPropertyLoader;
import com.appman.core.syncservice.service.DiskAttachmentStorage;
import com.appman.core.syncservice.service.IAttachmentStorage;
import com.appman.core.syncservice.service.S3AttachmentStorage;
import com.zaxxer.hikari.HikariDataSource;

import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;
import utility.database.ConnectionBean;
import utility.database.DBConnectionFile;

@ComponentScan(basePackages = { "com.appman.core.syncservice.controller", "com.appman.core.syncservice.service",
		"com.appman.core.syncservice.model", "com.appman.core.syncservice.dto",
		"com.appman.core.syncservice.repository", "com.appman.core.syncservice.component",
		"com.appman.core.syncservice.property" })
@PropertySource("classpath:application.properties")
@EnableTransactionManagement
@EnableJpaRepositories(basePackages = { "com.appman.core.syncservice.model", "com.appman.core.syncservice.repository" })
@Configuration
@EnableSwagger2
public class ApplicationConfig extends WebMvcConfigurationSupport {
	private static final Logger log = LoggerFactory.getLogger(ApplicationConfig.class);

	public static final String CONFIGURATION_FILE = "dbconfig.cfg";
	public static final String CONFIGURATION_KEY = "dbkey.cfg";

	@Autowired
	private EnvironmentPropertyLoader property;

	@Bean
	public Docket productApi() {
		return new Docket(DocumentationType.SWAGGER_2).select()
				.apis(RequestHandlerSelectors.basePackage("com.appman.core.syncservice.controller"))
				.paths(PathSelectors.any()).build();
	}

	@Override
	protected void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler("swagger-ui.html").addResourceLocations("classpath:/META-INF/resources/");
		registry.addResourceHandler("/webjars/**").addResourceLocations("classpath:/META-INF/resources/webjars/");
	}

	/**
	 * Storage configuration @Bean, @Profile Always placed under @Configuration.
	 **/
	@Profile(value = { "it", "loc", "pre", "dev", "ldb", "ddb", "jdi", "pdb", "sit", "uat", "prd" })
	@Bean("attachmentStorage")
	public IAttachmentStorage getDiskStorage() {
		log.info(">>>>> Attachment Disk Storage built :{} <<<<<", property.getBuildDate());
		DiskAttachmentStorage storage = new DiskAttachmentStorage();
		storage.setPath(property.getStoragePath());
		return storage;
	}

	@Profile(value = { "ls3" })
	@Bean("attachmentStorage")
	public IAttachmentStorage getS3Storage() {
		log.info(">>>>> Attachment S3 Storage built :{} <<<<<", property.getBuildDate());
		BasicAWSCredentials credentials = new BasicAWSCredentials(property.getAwsS3AccessKey(),
				property.getAwsS3SecretKey());
		AmazonS3 s3 = AmazonS3ClientBuilder.standard().withCredentials(new AWSStaticCredentialsProvider(credentials))
				.withRegion(property.getAwsS3Region()).build();

		return new S3AttachmentStorage(s3, property.getAwsS3BucketName());
	}

	/**
	 * Due to using @Bean and @Profile. The following database configuration must be placed under @Configuration.
	 **/
	@Profile(value = { "jdi" })
	@Bean
	public DataSource jndiDataSource() throws NamingException {
		log.info(">>>>> JNDI DataSource Creating built :{} <<<<<", property.getBuildDate());
		return (DataSource) new JndiTemplate().lookup("java:comp/env/jdbc/syncdb");
	}

	@Profile(value = { "it", "loc", "ls3", "pre", "ddb" })
	@Bean
	@ConfigurationProperties(prefix = "spring.datasource.hikari")
	public DataSource hikariDataSource() {
		log.info(">>>>> Hikari DataSource Creating <<<<<");
		return DataSourceBuilder.create().type(HikariDataSource.class).build();
	}

	@Profile(value = { "ldb", "pdb", "dev", "sit", "uat", "prd" })
	@Bean
	public DataSource dbUtilityDataSource() {
		log.info(">>>>> DBUtility DataSource Creating built :{} <<<<<", property.getBuildDate());
		String hostName = "";
		String port = "";
		try {
			DBConnectionFile fileDB = new DBConnectionFile(new ClassPathResource(CONFIGURATION_FILE).getFile(),
					new ClassPathResource(CONFIGURATION_KEY).getFile(), property.getTargetDatabaseName());
			ConnectionBean con = fileDB.getConnectionBean();
			hostName = con.getHostName();
			port = con.getPortNo();
			return DataSourceBuilder.create().username(con.getUserName()).password(con.getPassword())
					.url("jdbc:postgresql://" + hostName + ":" + port + "/" + con.getDatabaseName()).build();
		} catch (IOException e) {
			log.error("DBUtility DataSource creation to host :{} port :{} :", hostName, port, e);
		}

		return null;
	}

	@Bean
	public PlatformTransactionManager transactionManager(EntityManagerFactory emf) {
		JpaTransactionManager transactionManager = new JpaTransactionManager();
		transactionManager.setEntityManagerFactory(emf);
		return transactionManager;
	}
}