package com.appman.core.syncservice.dto;

import java.io.Serializable;
import java.util.List;

import com.appman.core.syncservice.model.DraftDatas;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class FetchResponse implements Serializable {
	private static final long serialVersionUID = -7542214388525505942L;

	@ApiModelProperty(notes = "Owner", example = "AGENT_AAA", position = 10)
	@JsonProperty("owner")
	private String owner;

	@ApiModelProperty(notes = "Return limited amount of data by specific condition", example = "10", position = 20)
	@JsonProperty("count")
	private int count;

	@ApiModelProperty(notes = "Return entire amount of data by specific condition without limitation", example = "100", position = 30)
	@JsonProperty("total")
	private int total;

	@ApiModelProperty(notes = "Result data", example = "[{\"key\": \"A00001\", \"rev\": \"cbaf48dc2a3b3a971c9ff596f6b09e0511633a71\", \"draftType\": \"app\", \"data\": { \"draftType\": \"application\", \"data\": { \"insured\": { \"firstName\": { \"text\": \"ทดสอบ\" }}}},\"attachments\": {\"001\": \"0f8fad5b-d9cb-469f-a165-70867728950a\", \"002\": \"0f8fad5b-d9cb-469f-a165-70867728950b\"}}]", position = 40)
	@JsonProperty("list")
	private transient List<DraftDatas> resourceDatas;

	@ApiModelProperty(notes = "Latest updated in unix time", example = "1545377975", position = 50)
	private long latestUpdatedAt;
}
