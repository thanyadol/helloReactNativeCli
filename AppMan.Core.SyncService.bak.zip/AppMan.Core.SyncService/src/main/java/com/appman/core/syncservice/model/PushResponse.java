package com.appman.core.syncservice.model;

import java.io.Serializable;
import java.util.Map;
import java.util.UUID;

import com.appman.core.syncservice.util.JsonUtil;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.core.JsonProcessingException;

public class PushResponse extends SyncResponse implements Serializable {
	private static final long serialVersionUID = 2685297708376090659L;

	/* Following properties just for unit test only */
	@JsonIgnore
	private String tempKey;

	@JsonIgnore
	private String tempRev;

	@JsonIgnore
	private Object tempData;

	@JsonIgnore
	private String tempDraftType;

	@JsonIgnore
	private Long tempCreatedAt;

	@JsonIgnore
	private Long tempUpdatedAt;

	@JsonIgnore
	private Map<String, UUID> tempAttachments;

	public PushResponse() {
		super();
	}

	public PushResponse(String pushedBy, DraftDatas body) {
		super(pushedBy, body);
	}

	/* Following setter method just for unit test only */
	public void setKey(String tempKey) {
		this.tempKey = tempKey;
		super.getBody().setKey(tempKey);
	}

	public void setRev(String tempRev) {
		this.tempRev = tempRev;
		super.getBody().setRev(tempRev);
	}

	public void setData(Object tempData) throws JsonProcessingException {
		this.tempData = tempData;
		super.getBody().setData(JsonUtil.mapper.writeValueAsString(tempData));
	}

	public void setDraftType(String tempDraftType) {
		this.tempDraftType = tempDraftType;
		super.getBody().setDraftType(tempDraftType);
	}

	public void setCreatedAt(Long tempCreatedAt) {
		this.tempCreatedAt = tempCreatedAt;
		super.getBody().setCreatedAt(tempCreatedAt);
	}

	public void setUpdatedAt(Long tempUpdatedAt) {
		this.tempUpdatedAt = tempUpdatedAt;
		super.getBody().setUpdatedAt(tempUpdatedAt);
	}

	public void setAttachments(Map<String, UUID> tempAttachments) {
		this.tempAttachments = tempAttachments;
		super.getBody().setAttachments(tempAttachments);
	}
}
