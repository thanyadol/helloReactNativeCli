package com.appman.core.syncservice.model;

import java.io.IOException;
import java.io.Serializable;
import java.util.Map;
import java.util.UUID;

import com.appman.core.syncservice.util.JsonUtil;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SyncResponse implements Serializable {
	private static final long serialVersionUID = -5906255617693317976L;

	@JsonIgnore
	private String pushedBy;

	@JsonIgnore
	private DraftDatas body = new DraftDatas();

	@ApiModelProperty(notes = "front-end key", example = "A10001", position = 10)
	@JsonProperty("key")
	public String getKey() {
		return body.getKey();
	}

	@ApiModelProperty(notes = "rev", example = "cbaf48dc2a3b3a971c9ff596f6b09e0511633a71", position = 20)
	@JsonProperty("rev")
	public String getRev() {
		return body.getRev();
	}

	@ApiModelProperty(notes = "Json data", example = "{\"draftType\": \"application\", \"data\": {\"insured\": {\"firstName\": {\"text\": \"ทดสอบ\"}}}}", position = 30)
	@JsonProperty("data")
	public Object getData() throws IOException {
		return JsonUtil.mapper.readValue(body.getData(), Object.class);
	}

	@ApiModelProperty(notes = "Draft type", example = "app", position = 40)
	@JsonProperty("draftType")
	public String getDraftType() {
		return body.getDraftType();
	}

	@ApiModelProperty(notes = "Data created in unix time", example = "1545376061", position = 50)
	@JsonProperty("createdAt")
	public long getCreatedAt() {
		return body.getCreatedAt();
	}

	@ApiModelProperty(notes = "Data updated in unix time", example = "1545376062", position = 60)
	@JsonProperty("updatedAt")
	public long getUpdatedAt() {
		return body.getUpdatedAt();
	}

	/*
	 * @ApiModelProperty(notes = "Attachment reference key :front-end-key, value :Database UUID", example =
	 * "{'001': '0f8fad5b-d9cb-469f-a165-70867728950a', '002': '0f8fad5b-d9cb-469f-a165-70867728950b'}", position = 70)
	 */
	@ApiModelProperty(notes = "Attachment reference key :front-end-key, value :Database UUID", example = "{}", position = 70)
	@JsonProperty("attachments")
	public Map<String, UUID> getAttachments() {
		return body.getAttachments();
	}
}
