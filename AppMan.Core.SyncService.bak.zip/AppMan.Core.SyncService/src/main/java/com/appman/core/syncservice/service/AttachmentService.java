package com.appman.core.syncservice.service;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.Optional;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.appman.core.syncservice.dto.Base64File;
import com.appman.core.syncservice.dto.DeleteRequest;
import com.appman.core.syncservice.dto.EncryptionParams;
import com.appman.core.syncservice.dto.ReadParams;
import com.appman.core.syncservice.dto.RetrieveRequest;
import com.appman.core.syncservice.dto.RetrieveResponse;
import com.appman.core.syncservice.enumeration.EnumFileStatus;
import com.appman.core.syncservice.exception.AttachmentException;
import com.appman.core.syncservice.exception.AttachmentStorageException;
import com.appman.core.syncservice.exception.CipherException;
import com.appman.core.syncservice.exception.InvalidFileException;
import com.appman.core.syncservice.model.Attachment;
import com.appman.core.syncservice.repository.AttachmentCrudRepository;
import com.appman.core.syncservice.repository.AttachmentRepository;
import com.appman.core.syncservice.util.AppUtil;
import com.appman.core.syncservice.util.CipherUtil;
import com.appman.core.syncservice.util.JsonUtil;
import com.fasterxml.jackson.core.JsonProcessingException;

@Service
@Transactional(readOnly = true)
public class AttachmentService {
	private static final Logger log = LoggerFactory.getLogger(AttachmentService.class);

	@Autowired
	@Qualifier(value = "attachmentStorage")
	private IAttachmentStorage storage;

	@Autowired
	@Qualifier(value = "attachmentCrudRepository")
	private AttachmentCrudRepository attachmentCrudRepository;

	@Autowired
	@Qualifier(value = "attachmentRepository")
	private AttachmentRepository attachmentRepository;

	@Autowired
	@Qualifier(value = "aesCipherService")
	private ICipherService cipherService;

	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public Attachment saveAttachment(Base64File file) throws AttachmentException {
		try {
			long currentUnixTime = AppUtil.getUnixTime();
			UUID uuid = AppUtil.getUUID();

			// Encrypt file.
			EncryptionParams encryptionParams = cipherService.encrypt(file.getRaw());

			// Save encrypted file to physical storage.
			ReadParams readParams = storage.writeData(storage.getReadParams(uuid), encryptionParams.getEncrypted());
			Attachment attachment = new Attachment();
			attachment.setContentType(file.getContentType());
			attachment.setCreatedAt(currentUnixTime);
			attachment.setCreatedBy(file.getOwner());
			attachment.setEncryptionParams(JsonUtil.mapper.writeValueAsString(encryptionParams));
			attachment.setFileUID(uuid);
			attachment.setReadParams(readParams.asJsonValue());
			attachment.setStatus(EnumFileStatus.AVAILABLE);
			attachment.setStorageType(storage.getStorageType());
			attachment.setUpdatedAt(currentUnixTime);
			attachment.setUpdatedBy(file.getOwner());

			// Save encryption details.
			return attachmentCrudRepository.save(attachment);
		} catch (CipherException | JsonProcessingException | AttachmentStorageException e) {
			throw new AttachmentException(e);
		}
	}

	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public Attachment removeAttachment(DeleteRequest request) throws InvalidFileException, AttachmentException {
		try {
			Optional<Attachment> optAttachment = attachmentCrudRepository.findById(request.getFileUID());
			if (optAttachment.isPresent()) {
				Attachment attachment = optAttachment.get();

				// Delete attachment file in storage
				storage.deleteData(storage.fromReadParamsText(attachment.getReadParams()));

				attachment.setStatus(EnumFileStatus.DELETED);
				attachment.setUpdatedAt(AppUtil.getUnixTime());
				attachment.setUpdatedBy(request.getOwner());

				return attachmentCrudRepository.save(attachment);
			}
			else {
				throw new InvalidFileException("Not found", request.getFileUID());
			}
		} catch (AttachmentStorageException | IOException e) {
			throw new AttachmentException(e);
		}
	}

	public RetrieveResponse getAttachment(RetrieveRequest request) throws AttachmentException, InvalidFileException {
		RetrieveResponse response = new RetrieveResponse();
		Attachment attachment = new Attachment();

		try {
			Optional<Attachment> optAttachment = attachmentCrudRepository.findById(request.getFileUID());
			if (optAttachment.isPresent()) {
				attachment = optAttachment.get();

				// If file status is available, return file as base64.
				if (EnumFileStatus.AVAILABLE == attachment.getStatus()) {
					// Prepare read parameter for loading a file from physical storage
					ReadParams readParams = storage.fromReadParamsText(attachment.getReadParams());

					// Load encrypted data from physical storage
					byte[] encryptedData = storage.readData(readParams);

					// Prepare encryption parameter for decryption
					EncryptionParams encryptionParams = storage
							.fromEncryptionParamsText(attachment.getEncryptionParams());

					log.info("Load file data size :{}, encryption parameters :{}",
							encryptedData != null ? encryptedData.length : "NULL",
							encryptionParams != null ? encryptionParams : "NULL");

					// Decryption
					byte[] decryptedData = cipherService.decrypt(encryptedData, encryptionParams);

					response.setChecksum(CipherUtil.createCheckSum(decryptedData));
					response.setContentBody(CipherUtil.byteToBase64String(decryptedData));
					response.setContentType(attachment.getContentType());
					response.setFileUID(attachment.getFileUID().toString());
				} else {
					// Otherwise throw InvalidFileException
					throw new InvalidFileException("Deleted", request.getFileUID());
				}
			} else {
				// Otherwise throw InvalidFileException
				throw new InvalidFileException("Not found", request.getFileUID());
			}
			return response;
		} catch (AttachmentStorageException | CipherException | NoSuchAlgorithmException | IOException e) {
			throw new AttachmentException(e);
		}
	}
	
	/* Only for unit test */
	void setStorage(IAttachmentStorage storage) {
		this.storage = storage;
	}
}
