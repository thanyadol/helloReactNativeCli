package com.appman.core.syncservice.exception;

public class AttachmentStorageException extends Exception {

	private static final long serialVersionUID = 1539483515024769811L;

	public AttachmentStorageException() {
		super();
	}

	public AttachmentStorageException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public AttachmentStorageException(String message, Throwable cause) {
		super(message, cause);
	}

	public AttachmentStorageException(String message) {
		super(message);
	}

	public AttachmentStorageException(Throwable cause) {
		super(cause);
	}
}
