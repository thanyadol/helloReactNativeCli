package com.appman.core.syncservice.dto;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class SaveBatchAttachmentResponse implements Serializable {
	private static final long serialVersionUID = 8461655481432194337L;

	@ApiModelProperty(notes = "Attachment reference key :front-end-key, value :Database UUID", example = "[{\"001\": \"0f8fad5b-d9cb-469f-a165-70867728950a\"}, {\"002\": \"0f8fad5b-d9cb-469f-a165-70867728950b\"}]")
	@JsonProperty("attachments")
	private Map<String, UUID> attachments = new LinkedHashMap<>();

	public void putAttachment(String key, UUID value) {
		attachments.put(key, value);
	}
}
