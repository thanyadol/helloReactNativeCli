package com.appman.core.syncservice.dto;

import java.io.Serializable;
import java.util.Map;
import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AttachmentNotValidErrorDetail implements Serializable {
	private static final long serialVersionUID = 713298160291146020L;
	
	private String error;
	private Map<String, UUID> attachments;
}
