package com.appman.core.syncservice.repository;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.repository.CrudRepository;

import com.appman.core.syncservice.model.Attachment;

@Qualifier(value = "attachmentCrudRepository")
public interface AttachmentCrudRepository extends CrudRepository<Attachment, UUID> {

}
