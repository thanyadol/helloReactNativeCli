package com.appman.core.syncservice.dto;

import java.io.Serializable;

import com.appman.core.syncservice.util.JsonUtil;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonProcessingException;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ReadParams implements Serializable {
	private static final long serialVersionUID = -5138602918952637310L;

	@JsonProperty("Key")
	protected String key;
	
	public String asJsonValue() throws JsonProcessingException {
		return JsonUtil.mapper.writeValueAsString(this);
	}
}
