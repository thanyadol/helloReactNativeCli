package com.appman.core.syncservice.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class SaveBatchAttachmentRequest implements Serializable {
	private static final long serialVersionUID = 4491579988754450650L;

	@JsonProperty("attachments")
	private List<Base64File> attachments = new ArrayList<>();
}
