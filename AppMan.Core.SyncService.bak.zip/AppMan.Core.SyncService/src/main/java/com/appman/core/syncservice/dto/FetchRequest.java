package com.appman.core.syncservice.dto;

import java.io.Serializable;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class FetchRequest implements Serializable {
	private static final long serialVersionUID = -6577450002731497196L;

	private String owner = "";
	private Long latestUpdatedAt = 0L;
	private Integer limit = 10;

	public FetchRequest(String owner, Long latestUpdatedAt, Integer limit) {
		super();
		
		if (owner != null) {
			this.owner = owner;
		}
		if (latestUpdatedAt != null) {
			this.latestUpdatedAt = latestUpdatedAt;
		}

		if (limit != null) {
			this.limit = limit;
		}
	}
}
