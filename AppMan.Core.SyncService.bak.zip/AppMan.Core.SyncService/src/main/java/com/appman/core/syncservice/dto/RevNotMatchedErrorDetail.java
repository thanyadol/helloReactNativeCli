package com.appman.core.syncservice.dto;

import java.io.Serializable;

import com.appman.core.syncservice.model.DraftDatas;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RevNotMatchedErrorDetail implements Serializable{
	private static final long serialVersionUID = 7426262884319775018L;
	
	private String error;
	private DraftDatas prev;
}
