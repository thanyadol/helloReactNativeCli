package com.appman.core.syncservice.model;

import java.io.IOException;
import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.appman.core.syncservice.util.JsonUtil;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity(name = "DraftDatas")
@Table(name = "DraftDatas")
@Data
@NoArgsConstructor
public class DraftDatas implements Serializable {
	private static final long serialVersionUID = -4976685680123731886L;

	/**
	 * Needs specify double quote as \"DraftDatas_ID_seq\" in Postgres SQL.
	 **/
	@JsonIgnore
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "DraftDatasIDSeq")
	@SequenceGenerator(name = "DraftDatasIDSeq", sequenceName = "\"DraftDatas_ID_seq\"", allocationSize = 50)
	@Column(name = "ID", updatable = false, nullable = false)
	private Long id;

	@ApiModelProperty(notes = "front-end key", example = "A00001", position = 10)
	@JsonProperty("key")
	@Column(name = "Key", length = 36)
	private String key;

	@ApiModelProperty(notes = "rev", example = "cbaf48dc2a3b3a971c9ff596f6b09e0511633a71", position = 20)
	@JsonProperty("rev")
	@Column(name = "Rev", length = 40)
	private String rev;

	@JsonIgnore
	@Column(name = "Owner", length = 128)
	private String owner;

	@ApiModelProperty(notes = "Draft type", example = "app", position = 30)
	@Column(name = "DraftType", length = 128)
	private String draftType;

	@Column(name = "Data", columnDefinition = "text")
	private String data; // Json string

	@ApiModelProperty(notes = "Data created in unix time", example = "1545376061", position = 40)
	@Column(name = "CreatedAt")
	private Long createdAt;

	@ApiModelProperty(notes = "Data updated in unix time", example = "1545376062", position = 50)
	@Column(name = "UpdatedAt")
	private Long updatedAt;

	@JsonIgnore
	@Column(name = "CreatedBy", length = 128)
	private String createdBy;

	@JsonIgnore
	@Column(name = "UpdatedBy", length = 128)
	private String updatedBy;

	@ApiModelProperty(notes = "Attachment reference key :front-end-key, value :Database UUID", example = "{\"001\": \"0f8fad5b-d9cb-469f-a165-70867728950a\", \"002\": \"0f8fad5b-d9cb-469f-a165-70867728950b\"}", position = 60)
	@JsonProperty("attachments")
	private transient Map<String, UUID> attachments = new LinkedHashMap<>();

	public DraftDatas(String key, String rev, String draftType, String data) {
		this.key = key;
		this.rev = rev;
		this.draftType = draftType;
		this.data = data;
	}

	@ApiModelProperty(notes = "Json data", example = "{\"draftType\": \"application\", \"data\": {\"insured\": {\"firstName\": {\"text\": \"ทดสอบ\"}}}}", position = 70)
	@JsonProperty("data")
	public Object getObjectData() throws IOException {
		return JsonUtil.mapper.readValue(data, Object.class);
	}
	
	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.id).toHashCode();
	}

	@Override
	public boolean equals(Object other) {
		if (other instanceof DraftDatas) {
			DraftDatas that = (DraftDatas) other;
			return new EqualsBuilder().append(this.id, that.id).isEquals();
		} else {
			return false;
		}
	}
}
