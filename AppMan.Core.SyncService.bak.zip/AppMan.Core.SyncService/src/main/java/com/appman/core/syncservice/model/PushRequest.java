package com.appman.core.syncservice.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class PushRequest implements Serializable{
	private static final long serialVersionUID = -1158567800934951105L;
	
	private String pushedBy;
    private DraftDatas body;
}
