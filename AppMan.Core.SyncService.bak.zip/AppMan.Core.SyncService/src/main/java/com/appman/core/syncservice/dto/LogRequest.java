package com.appman.core.syncservice.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class LogRequest {
	@ApiModelProperty(notes = "File path. examples :'.', './sync-service.log', '../'", example = "./sync-service.log")
	@JsonProperty("path")
	private String path;

	@ApiModelProperty(notes = "Line amount to be loaded.", example="1000")
	@JsonProperty("line")
	private int line;
}
