package com.appman.core.syncservice.exception;

public class DataNotFoundException extends Exception {
	private static final long serialVersionUID = 8111644764774136035L;
	private String key;
	
	public static final String DATA_NOT_FOUND_MESSAGE = "Data not found";

	public DataNotFoundException() {
		super(DATA_NOT_FOUND_MESSAGE);
	}

	public DataNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public DataNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}

	public DataNotFoundException(String message) {
		super(message);
	}

	public DataNotFoundException(Throwable cause) {
		super(DATA_NOT_FOUND_MESSAGE, cause);
	}

	public DataNotFoundException(String message, String key) {
		super(message);
		this.key = key;
	}

	public String getKey() {
		return key;
	}
}
