package com.appman.core.syncservice.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@JsonPropertyOrder({ "localFileID", "contentType", "contentBody", "checksum" })
public class Base64File implements Serializable {
	private static final long serialVersionUID = 6848204158730633682L;

	@ApiModelProperty(notes = "front-end localFileID", example = "A00001", position = 10)
	@JsonProperty("localFileID")
	private String localFileID;

	@ApiModelProperty(notes = "File content type", example = "image/png", position = 20)
	@JsonProperty("contentType")
	private String contentType;

	@ApiModelProperty(notes = "Base64 file data", example = "TU0AKgAAAAgADAEAAAMAAAAB==", position = 30)
	@JsonProperty("contentBody")
	private String contentBody;

	@ApiModelProperty(notes = "Check sum of binary data before converted to base64 for verification", example = "Axbg0x89dx", position = 40)
	@JsonProperty("checksum")
	private String checksum;

	// Convenient, a data byte array which is generated from base64 contentBody
	@JsonIgnore
	private byte[] raw;

	// Convenient, an owner
	@JsonIgnore
	private String owner;
}
