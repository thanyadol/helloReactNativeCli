mvn -Pddb clean package
