rm -rf dockerimage
mkdir dockerimage
mkdir dockerimage/binary
mkdir dockerimage/target
cp -f ./target/*.jar ./dockerimage/binary/
cp -f ./target/*.jar ./dockerimage/target/
cp -f README.md dockerimage/
cp -f Dockerfile dockerimage/
cp -f docker-image.sh dockerimage/
cp -f docker-run.sh dockerimage/