mvn -f pom-war.xml -Pldb clean package
