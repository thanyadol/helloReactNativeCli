docker run -d -p 8080:8080 -m 2048m sync
