-- Schema 
CREATE SCHEMA IF NOT EXISTS "AGMCORE" AUTHORIZATION admin;

-- UUID Generator
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Drop existing table
drop table if exists "AGMCORE"."Attachments" cascade;
drop table if exists "AGMCORE"."DraftDatas" cascade;
drop sequence if exists "AGMCORE"."DraftDatas_ID_seq";

-- Create sequence
create sequence "AGMCORE"."DraftDatas_ID_seq" start 1 increment 1;

-- Create table
create table "AGMCORE"."Attachments" (
   "FileUID" uuid not null,
   "ContentType" varchar(64),
   "CreatedAt" int8,
   "CreatedBy" varchar(128),
   "EncryptionParams" text,
   "ReadParams" text,
   "Status" int4,
   "StorageType" varchar(64),
   "UpdatedAt" int8,
   "UpdatedBy" varchar(128),
   primary key ("FileUID")
);
  
create table "AGMCORE"."DraftDatas" (
   "ID" int8 not null,
   "CreatedAt" int8,
   "CreatedBy" varchar(128),
   "Data" text,
   "DraftType" varchar(128),
   "Key" varchar(36),
   "Owner" varchar(128),
   "Rev" varchar(40),
   "UpdatedAt" int8,
   "UpdatedBy" varchar(128),
   primary key ("ID")
);


-- For integration unit test only
-- Login to PostgresSQL with administrator privilege on "postgre" database.
CREATE DATABASE testdb;
CREATE USER test WITH ENCRYPTED PASSWORD 'passwd';
GRANT ALL PRIVILEGES ON DATABASE testdb TO test;
-- Login to PostgresSQL with test user on "testdb" database. 
CREATE SCHEMA "AGMCORETEST";
GRANT USAGE ON SCHEMA "AGMCORETEST" TO test;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA "AGMCORETEST" TO test;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA "AGMCORETEST" TO test;
GRANT ALL ON SCHEMA "AGMCORETEST" to test; 