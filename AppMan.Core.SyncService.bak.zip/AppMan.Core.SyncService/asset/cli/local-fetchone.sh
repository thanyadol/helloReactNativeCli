echo "Example command :local-fetchone.sh key0001"
KEY=$1
curl "http://localhost:8080/sync/fetch/$KEY"
