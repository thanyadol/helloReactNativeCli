curl -XPOST -H "Content-type: application/json" -d '{
  "key": "key0001",
  "rev": "rev0001",
  "draftType": "draft",
  "data" : {
	"insured": {
		"firstName": {
			"value": "Appman",
			"dirty": true
		},
		"lastName":{
			"value": "Manapp",
			"dirty": true
		}
	}
  },  
  "attachments": {}
}' 'http://localhost:8080/sync/push'