curl -XPOST -H "Content-type: application/json" -d '{
  "key": "key0001",
  "rev": "rev0001",
  "draftType": "draft",
  "data" : {
	"insured": {
		"firstName": {
			"value": "Appman",
			"dirty": true
		},
		"lastName":{
			"value": "Manapp",
			"dirty": true
		}
	}
  },  
  "attachments": {
    "localFileID1": "0f8fad5b-d9cb-469f-a165-70867728950a",
    "localFileID2": "0f8fad5b-d9cb-469f-a165-70867728950b",
    "localFileID3": "0f8fad5b-d9cb-469f-a165-70867728950c"
  }
}' 'http://localhost:8080/sync/push'