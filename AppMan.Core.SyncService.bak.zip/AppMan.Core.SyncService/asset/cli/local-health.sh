curl "http://localhost:8080/sync/health"
