curl -XPOST -H "Content-type: application/json" -d '{
  "key": "key0001",
  "rev": "rev0001",
  "draftType": "draft",
  "data" : {
	"insured": {
		"firstName": {
			"value": "AppmaN",
			"dirty": true
		},
		"lastName":{
			"value": "ManapP",
			"dirty": true
		}
	}
  },  
  "attachments": {}
}' 'http://localhost:8080/sync/push'