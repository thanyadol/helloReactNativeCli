curl -s -XPOST -H "Content-type: application/json" -d '{
  "path": "/opt/tomcat/logs"
}' 'http://dev-tlprompt-api.thailife.com:8280/interfaceDFL/rest/middleware/1.0/log/list'
