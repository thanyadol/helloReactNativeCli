curl -XPOST -H "Content-type: application/json" -d '{
  "key": "key0001",
  "rev": "52ead6f874cb48b2c574a8bb798fba9388828c03",
  "draftType": "draft",
  "data" : {
	"insured": {
		"firstName": {
			"value": "Appman#2",
			"dirty": true
		},
		"lastName":{
			"value": "Manapp#2",
			"dirty": true
		},
		"nickName":{
			"value": "ap-ok#2",
			"dirty": true
		}
	}
  },  
  "attachments": {}
}' 'http://localhost:8080/sync/push'
