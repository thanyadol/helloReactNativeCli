FILE_UID=$1
curl "http://localhost:8080/sync/attachment/get/$FILE_UID"