curl -s -XPOST -H "Content-type: application/json" -d '{
  "path": "/opt/tomcat/logs/sync-service.log"
}' 'http://dev-tlprompt-api.thailife.com:8280/interfaceDFL/rest/middleware/1.0/log/load'
