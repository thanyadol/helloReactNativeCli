curl -XPOST -H "Content-type: application/json" -d '{
  "data": {

  },
  "attachments": {},
  "draftType": "app",
  "createdAt": 1548054958,
  "updatedAt": 1548054958,
  "rev": "48f3180c06f8b1d17cc37b46ecd193c11225d501",
  "key": "001",
  "owner": "AGENT_AAA"
}' 'https://tli-dev.appman.co.th/sync/push'
