echo "Example command :local-fetch.sh 'owner=AGENT_AAA&latestUpdatedAt=0&limit=10' "
PARAM=$1
curl "http://localhost:8080/sync/fetch?$PARAM"