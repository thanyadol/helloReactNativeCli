FILE_UID=$1
curl -X DELETE "http://localhost:8080/sync/attachment/remove/$FILE_UID" -H "accept: application/json;charset=UTF-8"