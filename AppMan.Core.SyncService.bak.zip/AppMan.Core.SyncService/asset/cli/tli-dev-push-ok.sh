curl -XPOST -H "Content-type: application/json" -d '{
  "key": "key0001",
  "rev": "rev0001",
  "draftType": "draft",
  "data" : {
	"insured": {
		"firstName": {
			"value": "AppmaN",
			"dirty": true
		},
		"lastName":{
			"value": "ManapP",
			"dirty": true
		}
	}
  },  
  "attachments": {}
}' 'http://dev-tlprompt-api.thailife.com:8280/interfaceDFL/rest/middleware/1.0/push'
