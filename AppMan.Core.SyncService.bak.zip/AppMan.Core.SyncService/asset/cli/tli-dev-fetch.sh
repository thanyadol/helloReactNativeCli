echo "Example command :local-fetch.sh 'owner=AGENT_AAA&latestUpdatedAt=0&limit=10' "
PARAM=$1
curl "http://dev-tlprompt-api.thailife.com:8280/interfaceDFL/rest/middleware/1.0/fetch?$PARAM"