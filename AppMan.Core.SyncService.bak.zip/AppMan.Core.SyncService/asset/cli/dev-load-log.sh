curl -s -XPOST -H "Content-type: application/json" -d '{
  "path": "/opt/tomcat/logs/sync-service.log"
}' 'https://tli-dev.appman.co.th/sync/log/load'
