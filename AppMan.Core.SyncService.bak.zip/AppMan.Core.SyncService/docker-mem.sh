docker ps -q | xargs docker stats --no-stream
