rm *.json
rm *.log
rm *.log.zip
mvn clean
