echo "docker build -t <REPO>:<TAG> ."
docker build -t appmanagm/appman.tli.sync:0.0.1 .
