echo "docker tag <repo>:<tag> <new-repo>:<new-tag>"
echo "docker tag sync:latest sync:0.0.1"
