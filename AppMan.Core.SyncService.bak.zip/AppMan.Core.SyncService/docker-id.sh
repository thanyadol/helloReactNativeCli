docker ps -la | grep sync | cut -c1-12
