mvn -Ptst clean package
