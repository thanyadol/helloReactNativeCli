docker ps -aqf "name=sync"
