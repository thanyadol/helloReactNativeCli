docker exec -it $1 sh
