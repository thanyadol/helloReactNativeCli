echo 'USAGES :./docker-local-tst.sh'
MOCK_SERVICE_PREFIX='http://'
MOCK_SERVICE_LOCAL_IP="$(ifconfig | grep inet | grep netmask | grep broadcast | cut -c7-19)"
MOCK_SERVICE_SUFFIX=':8889/document/sync/Attachment/Get'
MOCK_SERVICE="$MOCK_SERVICE_PREFIX$MOCK_SERVICE_LOCAL_IP$MOCK_SERVICE_SUFFIX"
echo $MOCK_SERVICE
docker run -d -p 8888:8888 -p 9090:9090 -e SYNC_SERVICE_URL=$MOCK_SERVICE -m 2560m pdf-service
