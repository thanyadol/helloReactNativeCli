mvn -f pom-war.xml -Pdev clean package
