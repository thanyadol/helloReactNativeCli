./clean.sh
mvn clean install
