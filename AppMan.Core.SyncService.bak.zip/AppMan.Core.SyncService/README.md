Build steps for DEV environment, run following commands.
package-dev.sh
docker-image.sh
docker push appmanagm/appman.tli.sync:tagname

If environment variable support, use following.
For Apache Tomcat server deployment must specify following before starting the server.
	OSX :export SPRING_PROFILES_ACTIVE=dev
	WIN :set SPRING_PROFILES_ACTIVE=dev	
	
Profiles's environment
   pom.xml, target :jar file.
   it	= Integration test locally must configures local PostgreSQL with database :"seew" and schema :"test" with user/pass :sync/passwd
   			and grant all permissions. 
   loc	= LOCAL environment SpringBoot Tomcat server bundled use Hikari datasource connect to local PostgreSQL database 
			include with disk attachment storage.
   ls3  = LOCAL environment SpringBoot Tomcat server bundled use Hikari datasource connect to local PostgreSQL database 
   			include with S3 attachment storage.
   pre  = LOCAL environment SpringBoot Tomcat server bundled use Hikari datasource 
   			connect to Digital Ocean PostgreSQL database for dev environment include with disk attachment storage.
   dev  = DEV environment based on Docker orchestration SpringBoot Tomcat server bundled use Hikari datasource 
   			connect to Digital Ocean PostgreSQL database for dev environment include with disk attachment storage.
   ldb  = LOCAL environment SpringBoot Tomcat server use propietary DBUtility to creates datasource 
   			connect to local PostgreSQL database include with disk attachemnt storage.
   ddb  = DEV environment based on Docker orchestration SpringBoot Tomcat server use propietary DBUtility to creates datasource 
   			connect to Digital Ocean PostgreSQL database for dev environment include with disk attachment storage.
   For propietary DBUtility profiles(ldb) must configures pom.xml 
   		copy dbconfig.cfg and dbkey.cfg from asset/db/local to src/main/resources.
   
   pom-war.xml, target :war file.
   jdi  = LOCAL environment local Tomcat server use JNDI datasource connect to local PostgreSQL database 
   			include with disk attachment storage.   
   pdb  = LOCAL environment local Tomcat server use propietary DBUtility to creates datasource 
   			connect to local PostgreSQL database include with disk attachment storage.
   sit  = SIT environment AWS Tomcat server use propietary DBUtility to creates datasource 
   			connect to AWS PostgreSQL database include with disk attachment storage.
   uat  = UAT environment AWS Tomcat server use propietary DBUtility to creates datasource 
   			connect to AWS PostgreSQL database include with disk attachemnt storage.
   prd  = Production environment AWS Tomcat server use propietary DBUtility to creates datasource 
   			connect to AWS PostgreSQL database include with disk attachemnt storage.
   For propietary DBUtility profiles(pdb/sit/uat/prd) must configures pom-war.xml 
   			copy dbconfig.cfg and dbkey.cfg from asset/db/client to src/main/resources.