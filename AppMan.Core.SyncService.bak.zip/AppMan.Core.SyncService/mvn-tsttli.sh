mvn spring-boot:run -Ptsttli -Dspring.profiles.active=tsttli
