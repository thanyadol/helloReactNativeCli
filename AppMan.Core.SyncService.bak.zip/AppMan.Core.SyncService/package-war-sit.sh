mvn -f pom-war.xml -Psit clean package
