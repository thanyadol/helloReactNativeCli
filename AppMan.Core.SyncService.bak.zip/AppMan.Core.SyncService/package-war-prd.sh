mvn -f pom-war.xml -Pprd clean package
