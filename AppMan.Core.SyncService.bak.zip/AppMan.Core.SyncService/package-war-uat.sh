mvn -f pom-war.xml -Puat clean package
