﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    /// <summary>
    ///	ชำระด้วยเงินสด = CSH
    ///	ชำระด้วยเงินโอน = TRF
    ///	ชำระด้วยเช็คธนาคาร = TRQ
    ///	ชำระด้วยเช็ค = CLQ
    ///	เช็คคืน = RTQ
    ///	ค่าธรรมเนียมเช็คคืน = COM
    ///	รายการยกเลิก = COR
    ///	ปรับปรุงรายการด้านเจ้าหนี้ = AJD
    ///	ปรับปรุงรายการด้านลูกหนี้ = AJW
    ///	ชำระด้วยบัตรเครดิต("CD ") = CD 
    ///	ชำระผ่าน ATM, ATM Phone = ATM
    ///	ชำระผ่าน CDM   = CDM
    ///	ชำระผ่าน Telephone Banking = TEL
    ///	ชำระผ่าน Tele Fax = FAX
    ///	ชำระผ่าน Call Center =CAL
    ///	ชำระผ่าน IVR    = IVR
    ///	ชำระผ่าน Internet  =  NET
    ///	ชำระผ่าน EDC    = EDC
    ///	ชำระผ่าน SMS & USSD = MOB
    /// </summary>

    [Flags]
    public enum TransactionCode
    {
        [Description("Crash")]
        CSH,

        [Description("Transfer")]
        TRF,


        [Description("Transfer Cheque")]
        TRQ,

        [Description("Cheque")]
        CLQ,

        [Description("Telephone Banking")]
        TEL,

        [Description("CDM")]
        CDM,

        [Description("Credit card")]
        CD,

        [Description("ATM, ATM Phone")]
        ATM,
    }
}