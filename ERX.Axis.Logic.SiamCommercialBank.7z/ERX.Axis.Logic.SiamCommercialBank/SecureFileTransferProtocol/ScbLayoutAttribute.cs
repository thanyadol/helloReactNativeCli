﻿using System;
using System.ComponentModel;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public class ScbLayoutAttribute : Attribute
    {
        /// <summary>
        /// Starting digit in layout file
        /// </summary>
        [Description("Starting digit in layout file")]
        public int Begin { get; set; }

        /// <summary>
        /// Length from begin in layout file
        /// </summary>
        [Description("Length from begin in layout file")]
        public int Length { get; set; }

        /// <summary>
        /// Is required in SCB layout file
        /// </summary>
        [Description("Is required in SCB layout file")]
        public bool Require { get; set; }

        /// <summary>
        /// Section description in layout file e.g. HEADER, DETAIL, TRAILER
        /// </summary>
        [Description("Section description in layout file e.g. HEADER, DETAIL, TRAILER")]
        public string Section;

        /// <summary>
        ///     C	Characters - Left justified, trailing spaces	
        ///     N Numerics - Right justified, leading zeroes
        ///          T   Time - HHMMSS(24 Hour)
        ///     D Date - CCYYMMDD(Ex. "20040131")
        ///     A	"Amount - Amount format v13v3 
        ///     (13 Digits of Numeric and 3 Digits of decimal point)
        ///     Example : 1200.50 --> 0000000001200500"	
        /// </summary>
        public char Type;

        public ScbLayoutAttribute(string section, int begin, int length, bool require = false, char type = 'C')
        {
            this.Section = section;
            this.Type = type;
            this.Begin = begin;
            this.Length = length;
            this.Require = require;
        }
    }
}
