﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    [Flags]
    public enum ProductCode
    {
        /// <summary>
        /// 
        /// </summary>
        [Description("Bahtnet")]
        BNT,


        /// <summary>
        /// 
        /// </summary>
        [Description("DirectCredit")]
        DCP,


        /// <summary>
        /// 
        /// </summary>
        [Description("MediaClearing")]
        MCL,


        /// <summary>
        /// 
        /// </summary>
        [Description("Mcheque")]
        MCP
    }
}
