﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public static class Bank
    {
        public static Dictionary<int, string> THAILAND_BANK_CODE = new Dictionary<int, string>()
        {
            {
                034,
                "Bank for Agriculture and Agricultural Cooperatives"
            },
            { 025, "Bank Of Ayudhya" },
            { 002, "Bangkok Bank" },
            { 022, "Cimb Thai Bank" },
            { 033, "Government Housing Bank" },
            { 030, "Government Savings bank" },
            { 070, "Industrial And Commercial Bank Of China (Thai)" },
            { 066, "Islamic Bank of Thailand" },
            { 004, "Kasikornbank" },
            { 069, "Kiatnakin Bank" },
            { 006, "Krung Thai Bank" },
            { 073, "Land And Houses Bank" },
            { 014, "Siam Commercial Bank" },
            { 065, "Thanachart Bank" },
            { 071, "The Thai Credit Retail Bank" },
            { 067, "Tisco Bank" },
            { 011, "Tmb Bank" },
            { 024, "United Overseas Bank (Thai)" },

            { 000, "Standard Chartered Bank (Thai)" },
        };
    }
}
