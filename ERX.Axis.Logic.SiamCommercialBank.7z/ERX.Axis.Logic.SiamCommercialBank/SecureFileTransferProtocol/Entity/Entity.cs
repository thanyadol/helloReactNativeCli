// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT license.using System

using System;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public abstract class Entity<TKey>
    {
        [JsonProperty("id")]
        public TKey Id { get; set; }


        public string ContainerName { get; set; }
        public string PartitionKey { get; set; }

        public int CreatedInUnixTimeStamp { get; set; }

        [JsonProperty("createdOn")]
        public DateTime Created { get; set; }

        protected Entity()
        {
            this.PartitionKey = "id";
            this.Created = DateTime.UtcNow;
        }
    }
}
