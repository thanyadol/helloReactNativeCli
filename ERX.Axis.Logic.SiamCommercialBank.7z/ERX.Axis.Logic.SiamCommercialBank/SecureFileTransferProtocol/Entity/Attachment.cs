
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.IO;
using System.Text.Json.Serialization;

namespace ERX.Axis.Logic.SiamCommercialBank
{

    public class Attachment : Entity<Guid>
    {

        public Attachment()
        {
            ContainerName = "thailand-siam-commerical-bank-sftp-attachment";
        }

        public string Name { get; set; }

        public string Path { get; set; }

        public Decimal Size { get; set; }

        public string Extension { get; set; }

        //public string Status { get; set; }

        public string By { get; set; }

        public string StorageType { get; set; }

        public string TransactionType { get; set; }

        public Nullable<DateTime> Date { get; set; }

        [JsonIgnore]
        [NotMapped]
        public byte[] Base64EncryptedValue { get; set; }

        [JsonIgnore]
        [NotMapped]
        public byte[] Base64Value { get; set; }

        public string SyncedId { get; set; }
        public DateTime SyncedDate { get; set; }
        public string SyncedStatus { get; set; }

        public string ExceptionMessage { get; set; }
        public string StackTrace { get; set; }

        public int TotalTransaction { get; set; }

    }

}