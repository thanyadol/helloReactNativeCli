﻿using System.ComponentModel.DataAnnotations;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public class PaymentReturnTrailer
    {
        /// <summary>
        /// Fixed to 559
        /// </summary>
        [ScbLayout("Result", begin: 0, length: 3, require: true)]
        [StringLength(3)]
        public string RecordType { get => "559"; }

        //Right justified with leading zeroes. Unsigned.
        //Total number of  ‘510’ records.
        //(excluding header and summary records)
        [ScbLayout("Result", begin: 8, length: 3, require: true, 'N')]
        [StringLength(3)]
        public string TotalTransactions { get; set; }

        //Summation of payment amount (Fld S/no 3 ) in ‘510’ record.
        //14 - 4
        [ScbLayout("Result", begin: 11, length: 18, require: true, 'A')]
        [StringLength(18)]
        public string TotalPaymentAmount { get; set; }


    }
}
