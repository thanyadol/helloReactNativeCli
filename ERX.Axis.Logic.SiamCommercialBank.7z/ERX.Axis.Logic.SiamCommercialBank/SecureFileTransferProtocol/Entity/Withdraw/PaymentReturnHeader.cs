﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public class PaymentReturnHeader
    {
        public Guid AttachmentId { get; set; }

        public string AttachmentName { get; set; }


        public string TransactionType { get; set; }


        /// <summary>
        ///  Value ‘500’
        /// </summary>
        [Description("Value ‘500’")]
        [ScbLayout("Header", begin: 0, length: 3, require: true)]
        [StringLength(3)]
        public string RecordType { get; set; }

        //Format CCYYMMDD
        //This is the date the file is prepared by CN.
        [ScbLayout("Header", begin: 3, length: 8, require: true)]
        [StringLength(8)]
        public string CreationDate { get; set; }

        //Format HHMMSS
        [ScbLayout("Header", begin: 11, length: 6, require: true)]
        [StringLength(6)]
        public string CreationTime { get; set; }

        //Same As Customer Reference in incoming customer payments file
        [ScbLayout("Header", begin: 17, length: 32, require: true)]
        [StringLength(32)]
        public string FileReference { get; set; }

        /// <summary>
        /// Erx company id
        /// </summary>
        [Description("Erx company id")]
        [ScbLayout("Header", begin: 49, length: 12, require: true)]
        [StringLength(12)]
        public string CompanyId { get; set; }

        //Not applicable to customer.
        [ScbLayout("Header", begin: 61, length: 70, require: true)]
        [StringLength(70)]
        public string PaymentType { get; set; }

        //Not applicable to customer.
        [ScbLayout("Header", begin: 131, length: 20, require: true)]
        [StringLength(20)]
        public string ChannelId { get; set; }

        /// <summary>
        ///This is the Batch Reference assigned by Channel (S1)
        /// </summary>
        [Description("This is the Batch Reference assigned by Channel (S1)")]
        [ScbLayout("Header", begin: 151, length: 35, require: true)]
        [StringLength(35)]
        public string BatchReference { get; set; }

        /// <summary>
        /// Value Date of the Payment Batch
        /// </summary>
        [Description("Value Date of the Payment Batch")]
        [ScbLayout("Header", begin: 186, length: 8, require: true)]
        [StringLength(8)]
        public string ValueDate { get; set; }

    }
}
