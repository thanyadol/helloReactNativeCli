﻿using System;
using System.Collections.Generic;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public class PaymentReturn : Entity<Guid>
    {
        public Guid AttachmentId { get; set; }

        public string AttachmentName { get; set; }


        public string TransactionType { get; set; }


        public PaymentReturnHeader Header { get; set; }

        public List<PaymentReturnResult> ResultRecords { get; set; }

        public PaymentReturnTrailer Trailer { get; set; }

    }
}
