﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public class DomesticPaymentCreditDetail
    {
        /// <summary>
        /// Record type for detail fix as "003"
        /// </summary>
        [Description("Fix 003")]
        [ScbLayout("Detail", begin: 0, length: 3, require: true)]
        [StringLength(3)]
        public string RecordType { get => "003"; }

        /// <summary>
        /// Credit seq. start from 1 for each  Debit , 6 digits Sequence
        /// </summary>
        //
        [Description("Credit seq. start from 1 for each  Debit , 6 digits Sequence")]
        [ScbLayout("Detail", begin: 3, length: 6, require: true, 'N')]
        [StringLength(6)]
        public string CreditSequenceNumber { get; set; }

        /// <summary>
        /// Only numeric based on Account Passbook, Customer bank account
        /// </summary>
        [Description("Only numeric based on Account Passbook, Customer bank account")]
        [ScbLayout("Detail", begin: 9, length: 25, require: true)]
        [StringLength(25)]
        public string CreditAccount { get; set; }


        /// <summary>
        /// Withdraw credit amount
        /// "Amount - Amount format v13v3 
        ///(13 Digits of Numeric and 3 Digits of decimal point)
        ///Example : 1200.50 --> 0000000001200500"	
        /// </summary>
        [Description("Withdraw credit amount")]
        [ScbLayout("Detail", begin: 34, length: 16, require: true, 'A')]
        [StringLength(16)]
        public string CreditAmount { get; set; }

        [JsonIgnore]
        public string OneCircleReferenceTicketId { get; set; }


        [JsonIgnore]
        public decimal DecimalCreditAmount { get; set; }

        /// <summary>
        /// THB
        /// </summary>
        [Description("Fixed as THB")]
        [ScbLayout("Detail", begin: 50, length: 3, require: true)]
        [StringLength(3)]
        public string CreditCurrencyCode { get; set; }

        /// <summary>
        /// Ref. To Debit record (002-9) of Debit detail
        /// </summary>
        [Description("Fix 003")]
        [ScbLayout("Detail", begin: 53, length: 8, require: true)]
        [StringLength(8)]
        public string InternalReferenceToDebitDetail { get; set; }

        //
        /// <summary>
        /// Print WHT (Y/N) ? Not use right now
        /// </summary>
        [Description("Print WHT (Y/N) ? Not use right now")]
        [ScbLayout("Detail", begin: 61, length: 1, require: true)]
        [StringLength(1)]
        public string WHTPresent { get; set; }

        /// <summary>
        /// Print Inv (Y/N) ? Not use right now
        /// </summary>
        [Description("Print Inv (Y/N) ? Not use right now")]
        [ScbLayout("Detail", begin: 62, length: 1, require: true)]
        [StringLength(1)]
        public string InvoiceDetailsPresent { get; set; }

        /// <summary>
        /// Print Credit Advice (Y/N) ? Not use right now
        /// </summary>
        [Description("Print Credit Advice (Y/N) ? Not use right now")]
        [ScbLayout("Detail", begin: 63, length: 1, require: true)]
        [StringLength(1)]
        public string CreditAdviceRequired { get; set; }

        /// <summary>
        ///Delivery document method to Beneficiary. (WHT, Invoice , Credit Advice) (M-Mail, C-Counter, P-Pickup, S-ScbLayoutBusinessNet)
        ///(M:Mail=> Send by Registered mail)
        ///(P:Pickup => Send by messenger to Customer)
        ///(C:Counter=> Receiving pickup at ScbLayout branch)
        ///(S:ScbLayoutBusinessNet=> Send back to ScbLayoutBusinessNet )
        /// </summary>
        [Description("Delivery document method to Beneficiary. Not use right now")]
        [ScbLayout("Detail", begin: 64, length: 1, require: false)]
        [StringLength(1)]
        public string DocumentDeliveryMode { get; set; }

        /// <summary>
        /// //* Mandatory if Delivery Mode = "C"
        /// </summary>
        [Description("Mandatory if Delivery Mode = C, not use right now")]
        [ScbLayout("Detail", begin: 65, length: 4, require: false)]
        [StringLength(4)]
        public string PickupLocation { get; set; }

        /// <summary>
        ///Mandatory if WHT Details present.
        ///01 = ภงด 1 ก
        ///02 = ภงด 2
        ///03 = ภงด 3
        ///53 = ภงด 53 
        /// </summary>
        [Description("Mandatory if WHT Details present. Not use right now")]
        [ScbLayout("Detail", begin: 69, length: 2, require: false)]
        [StringLength(2)]
        public string WHTFormType { get; set; }

        /// <summary>
        /// เลขที่บน WHT Form หากระบุเป็นค่าว่าง ธนาคารจะเป็นผู้กำหนดให้, Not use rifght now 
        /// </summary>
        [Description("เลขที่บน WHT Form หากระบุเป็นค่าว่าง ธนาคารจะเป็นผู้กำหนดให้, Not use rifght now ")]
        [ScbLayout("Detail", begin: 71, length: 14, require: false)]
        [StringLength(14)]
        public string WHTTaxRunningNo { get; set; }

        /// <summary>
        ///  ลำดับที่บน WHT Form  หากระบุเป็น "000000" ธนาคารจะเป็นผู้กำหนดให้, Not use right now
        /// </summary>
        [Description("ลำดับที่บน WHT Form  หากระบุเป็น '000000' ธนาคารจะเป็นผู้กำหนดให้, Not use right now")]
        [ScbLayout("Detail", begin: 85, length: 6, require: false, 'N')]
        [StringLength(6)]
        public string WHTAttachmentNo { get; set; }

        /// <summary>
        /// Mandatory if WHT Details present. Count WHT rec(005) which releated to this Credit record (003-2). Not use right now
        /// </summary>
        //
        [Description("Mandatory if WHT Details present. Count WHT rec(005) which releated to this Credit record (003-2). Not use right now")]
        [ScbLayout("Detail", begin: 91, length: 2, require: false, 'N')]
        [StringLength(2)]
        public string TotalWHTRecord { get; set; }


        /// <summary>
        /// Mandatory if WHT Details present. Sum of WHT amt(005-5) which releated to this Credit record (003-2). Not use right now
        /// </summary>
        [Description("Mandatory if WHT Details present. Sum of WHT amt(005-5) which releated to this Credit record (003-2). Not use right now")]
        [ScbLayout("Detail", begin: 93, length: 16, require: false, 'A')]
        [StringLength(16)]
        public string TotalWHTAmount { get => "0";  }


        /// <summary>
        /// Mandatory if Invoice Details present. Count Invoice. Rec(006) which releated to this Credit Record (003-2). Not use right now
        /// </summary>
        [Description("Mandatory if Invoice Details present. Count Invoice. Rec(006) which releated to this Credit Record (003-2). Not use right now")]
        [ScbLayout("Detail", begin: 109, length: 6, require: false, 'N')]
        [StringLength(6)]
        public string TotalInvoiceDetailRecord { get; set; }

        /// <summary>
        /// Mandatory if WHT Details present. Sum of WHT amt(005-5) which releated to this Credit record (003-2).Not use right now
        /// </summary>
        [Description("Mandatory if WHT Details present. Sum of WHT amt(005-5) which releated to this Credit record (003-2).Not use right now")]
        [ScbLayout("Detail", begin: 115, length: 16, require: false, 'A')]
        [StringLength(16)]
        public string TotalInvoiceAmount { get => "0"; }


        /// <summary>
        /// //Mandatory if WHT Details present. (1 : ผู้จ่ายออกครั้งเดียว, 2 : ออกให้ตลอดไป, 3 : หักภาษี ณ ที่จ่าย 4. อื่นๆ , Not use right now
        /// </summary>
        [Description("//Mandatory if WHT Details present. (1 : ผู้จ่ายออกครั้งเดียว, 2 : ออกให้ตลอดไป, 3 : หักภาษี ณ ที่จ่าย 4. อื่นๆ , Not use right now")]
        [ScbLayout("Detail", begin: 131, length: 1, require: false, 'N')]
        [StringLength(1)]
        public string WHTPayType { get; set; }

        /// <summary>
        /// //Mandatory if WHT Details present and WHT Pay Type(003-19) is 4, Not use right now    
        /// </summary>
        [Description("Mandatory if WHT Details present and WHT Pay Type(003-19) is 4, Not use right now")]
        [ScbLayout("Detail", begin: 132, length: 40, require: false)]
        [StringLength(40)]
        public string WHTRemark { get; set; }

        /// <summary>
        /// WHT deduct date Not use right now
        /// </summary>
        [Description("WHT deduct date Not use right now, Not use right now")]
        [ScbLayout("Detail", begin: 172, length: 8, require: false, 'D')]
        [StringLength(8)]
        public string WHTDeductDate { get; set; }

        /// <summary>
        /// Customer bank code,  "MCP", "CCP", "DDP", "XMQ", "XDQ","PAY","PA2","PA3" , "DCP" have to be = "014"
        /// </summary>
        [Description("Customer bank code")]
        [ScbLayout("Detail", begin: 180, length: 3, require: false, 'N')]
        [StringLength(3)]
        public string ReceivingBankCode { get; set; }

        /// <summary>
        /// Customer bank name **only English character or number
        /// </summary>
        //
        [Description("Receiving bank name **only English character or number")]
        [ScbLayout("Detail", begin: 183, length: 35, require: false)]
        [StringLength(35)]
        public string ReceivingBankName { get; set; }

        /// <summary>
        /// Customer bank branch code
        /// Mandatory For MCL, BNT, MCP, CCP, DDP , PA4 , PA5 , PA6 * MCP/DDP Default : "0111" (รัชโยธิน)
        ///  บริการโอนเงินให้ระบุรหัสสาขาของบัญชี  4 หลัก หากเป็นบริการออกเช็คให้ระบุ "0111"
        /// ** input actaul branch code base on Passbook
        /// </summary>
        [Description("Customer bank branch code")]
        [ScbLayout("Detail", begin: 218, length: 4, require: false, 'N')]
        [StringLength(4)]
        public string ReceivingBranchCode { get; set; }


        /// <summary>
        ///  Customer branch name **only English character or number
        /// </summary>
        [Description("Fix 003")]
        [ScbLayout("Detail", begin: 222, length: 35, require: false)]
        [StringLength(35)]
        public string ReceivingBranchName { get; set; }

        /// <summary>
        ///  Mandatory if WHT Details present. B-Bank, C-Corporate. Not use.
        /// </summary>
        //
        [Description("Mandatory if WHT Details present. B-Bank, C-Corporate. Not use.")]
        [ScbLayout("Detail", begin: 257, length: 1, require: false)]
        [StringLength(1)]
        public string WHTSignatory { get; set; }

        /// <summary>
        /// Notofication for transfer amount Bene. ทราบโดยวิธี  F-Fax, S-SMS, E-Email , N-None.
        /// 
        /// "E-Email
        /// *สำหรับรายการที่ scb ส่ง payment cofirmation กลับมาว่าไม่สำเร็จ erx ส่ง email แจ้งลูกค้าว่ารายกงานถอนเงินไม่สำเร็จเนื่องจากอะไรตามที่ทาง scb แจ้งเรามา เช่น ไม่สำเร็จเนื่องจากบัญชีธนาคารของลูกค้าไม่ถูกต้อง"
        /// </summary>
        //
        [Description("Notofication for transfer amount Bene. ทราบโดยวิธี  F-Fax, S-SMS, E-Email , N-None.")]
        [ScbLayout("Detail", begin: 258, length: 1, require: false)]
        [StringLength(1)]
        public string BeneficiaryNotification { get; set; }

        /// <summary>
        /// Mandatory if Product Code is MCP,DDP or CCP.  Not use
        /// </summary>
        [Description("Not use")]
        [ScbLayout("Detail", begin: 259, length: 20, require: false)]
        [StringLength(20)]
        public string CustomerReferenceNumber { get; set; }

        /// <summary>
        /// เอกสารที่ Bene. ต้องนำมาด้วยตอนรับ Cheque, Mandatory if Product Code is MCP,DDP or CCP. Not use
        /// </summary>

        [Description(" เอกสารที่ Bene. ต้องนำมาด้วยตอนรับ Cheque, Mandatory if Product Code is MCP,DDP or CCP. Not use")]
        [ScbLayout("Detail", begin: 279, length: 1, require: false)]
        [StringLength(1)]
        public string ChequeReferenceDocumentType { get; set; }

        /// <summary>
        /// Use in BNT, *for the detail please look up "Debit Type" list on sheet "Reference Type"
        /// สำหรับบริการ Bahtnet (BNT)  ให้ดูที่ sheet : Reference Type ตาราง  Debit Type of BAHTNET
        /// DCA : Current A/C
        /// </summary>

        [Description("DCA : Current A/C, Use in BNT, *for the detail please look up 'Debit Type' list on sheet Reference Type")]
        [ScbLayout("Detail", begin: 280, length: 3, require: false)]
        [StringLength(3)]
        public string PaymentTypeCode { get; set; }


        /// <summary>
        //"* Mandatory for MCL,PA4,PA5,PA6,BNT 
        ///1. Use in Media Clearing for ServiceType, detail on sheet Reference Type.
        ///2. Use in Bahtnet for Objective Code, detail on sheet Reference Type. 
        ///1. MCL: 05 ขายหลักทรัพย์/ To sell property
        ///2. BNT: 22 Trade Transaction
        /// </summary>

        [Description(" MCL: 05 ขายหลักทรัพย์/ To sell property, BNT: 22 Trade Transaction, or 59 (Other) with Remark")]
        [ScbLayout("Detail", begin: 383, length: 2, require: false)]
        [StringLength(2)]
        public string ServicesType { get; set; }



        /// <summary>
        /// Just remark
        /// </summary>
        [Description("Just remark")]
        [ScbLayout("Detail", begin: 385, length: 50, require: false)]
        [StringLength(50)]
        public string Remark { get; set; }

        /// <summary>
        /// //** ScbLayout System Reserved. Please do not input any character to this field
        /// </summary>
        [Description("ScbLayout System Reserved. Please do not input any character to this field")]
        [ScbLayout("Detail", begin: 335, length: 18, require: false)]
        [StringLength(18)]
        public string ScbLayoutRemark { get; set; }


        /// <summary>
        /// เก็บค่าธรรมเนียมที่บริษัท ให้ระบุ "  " (ค่าว่าง 2 ตัวอักษร) (2 of black space)
        /// </summary>
        //Beneficiary charge = "B " , customer charge = "  "
        //เก็บค่าธรรมเนียมที่ผู้รับเงิน ให้ระบุ "B " , เก็บค่าธรรมเนียมที่บริษัท ให้ระบุ "  " (ค่าว่าง 2 ตัวอักษร)
        [Description("(2 of black space)")]
        [ScbLayout("Detail", begin: 233, length: 2, require: false)]
        [StringLength(2)]
        public string BeneficiaryCharge { get; set; }
    }
}
