﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public class DomesticPaymentTrailer
    {
        /// <summary>
        /// Fix "999"
        /// </summary>
        [Description("Fix as 999")]
        [ScbLayout("Trailer", begin: 0, length: 3, require: true, 'C')]
        [StringLength(3)]
        public string RecordType { get => "999"; }

        /// <summary>
        /// Total count all Debit rec.
        /// </summary>
        [Description("Total count all Debit rec.")]
        [ScbLayout("Trailer", begin: 3, length: 6, require: true, 'N')]
        [StringLength(6)]
        public string TotalDebitsRecord { get; set; }

        /// <summary>
        /// Total count all Credit rec.
        /// </summary>
        [Description("Total count all Credit rec.")]
        [ScbLayout("Trailer", begin: 9, length: 6, require: true, 'N')]
        [StringLength(6)]
        public string TotalCreditsRecord { get; set; }


        /// <summary>
        /// Total Amount
        /// "Amount - Amount format v13v3 
        ///(13 Digits of Numeric and 3 Digits of decimal point)
        ///Example : 1200.50 --> 0000000001200500"	
        /// </summary>
        [Description("Total Amount")]
        [ScbLayout("Trailer", begin: 16, length: 16, require: true, 'A')]
        [StringLength(16)]
        public string TotalAmount { get; set; }
    }
}
