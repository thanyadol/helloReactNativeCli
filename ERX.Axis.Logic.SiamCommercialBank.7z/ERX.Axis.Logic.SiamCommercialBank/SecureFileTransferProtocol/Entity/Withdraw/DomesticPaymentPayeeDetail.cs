﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public class DomesticPaymentPayeeDetail
    {
        /// <summary>
        /// Record type for debit detail fixed as 004
        /// </summary>
        [Description("Record type for debit detail fixed as 004")]
        [ScbLayout("Detail", begin: 0, length: 3, require: true)]
        [StringLength(3)]
        public string RecordType { get => "004"; }

        /// <summary>
        ///  Ref. to Debit record (002-9)
        /// </summary>
        [Description()]
        [ScbLayout("Detail", begin: 3, length: 8, require: true)]
        [StringLength(8)]
        public string InternalReferenceToDebitRecord { get; set; }


        /// <summary>
        /// Ref. to Credit record (003-2)
        /// </summary>
        [Description("Ref. to Credit record (003-2)")]
        [ScbLayout("Detail", begin: 11, length: 6, require: true, 'N')]
        [StringLength(6)]
        public string ReferenceCreditSequenceNumber { get; set; }

        /// <summary>
        /// Mandatory if WHT Details present (003-7), not used
        /// </summary>
        [Description("Mandatory if WHT Details present (003-7), not used")]
        [ScbLayout("Detail", begin: 17, length: 15, require: false)]
        [StringLength(15)]
        public string Payee1IDCard { get; set; }


        /// <summary>
        /// Customer name in Thai Accept Both Thai & English Char. (if both fields of 004-5 and 004-10 have value, will use this field to print out credit advice, INV, WHT)
        //* Accept Both Thai & English Char.
        // (if both fields of 004-5 and 004-10 have value, will use this field to print out credit advice, INV, WHT)
        /// </summary>
        [Description("Customer name in Thai Accept Both Thai & English Char. (if both fields of 004-5 and 004-10 have value, will use this field to print out credit advice, INV, WHT)")]
        [ScbLayout("Detail", begin: 32, length: 100, require: false)]
        [StringLength(100)]
        public string Payee1NameInThai { get; set; }

        [JsonIgnore]
        public string OneCircleReferenceInvestorId { get; set; }


        /// <summary>
        /// Not use
        /// </summary>
        [Description("Not use")]
        [ScbLayout("Detail", begin: 132, length: 70, require: false)]
        [StringLength(70)]
        public string Payee1Address1 { get; set; }

        /// <summary>
        /// Not use
        /// </summary>
        [Description("Not use")]
        [ScbLayout("Detail", begin: 202, length: 70, require: false)]
        [StringLength(70)]
        public string Payee1Address2 { get; set; }

        /// <summary>
        /// Not use
        /// </summary>
        [Description("Not use")]
        [ScbLayout("Detail", begin: 272, length: 70, require: false)]
        [StringLength(70)]
        public string Payee1Address3 { get; set; }

        /// <summary>
        /// Mandatory if WHT Details present (003-7), Not use
        /// </summary>
        [Description("Mandatory if WHT Details present (003-7). Not use")]
        [ScbLayout("Detail", begin: 342, length: 10, require: false)]
        [StringLength(10)]
        public string Payee1TaxID { get; set; }


        /// <summary>
        /// Customer name in english
        /// Bahtnet accept only english char. (if Field 004-5 not have value, will use this field)
        /// Do not accept this character   ! < > $ ^ | = _  {  [  }  ] \ ; ""  '  #  @  & %"
        /// </summary>
        [Description(" Customer name in english, not accept special character")]
        [ScbLayout("Detail", begin: 352, length: 70, require: false)]
        [StringLength(70)]
        public string Payee1NameEnglish { get; set; }

        /// <summary>
        /// Mandatory  if Bene notification (003-27) = F. Not use  
        /// </summary>
        [Description("Mandatory  if Bene notification (003-27) = F. Not use")]
        [ScbLayout("Detail", begin: 422, length: 10, require: false)]
        [StringLength(10)]
        public string Payee1FaxNumber { get; set; }

        /// <summary>
        /// Mandatory  if Bene notification (003-27) = S. Not use.
        /// //**not allow to start with 02
        /// </summary>
        [Description("Mandatory  if Bene notification (003-27) = S. Not use.")]
        [ScbLayout("Detail", begin: 432, length: 10, require: false, 'N')]
        [StringLength(10)]
        public string Payee1MobilePhoneNumber { get; set; }

        /// <summary>
        ///"Mandatory  if Bene notification (003-27) = E. 
        ///validate email address template must be corrected e.g.xx@xxx.com
        ///Multiple email address can be separated by "","" or "";""
        ///ให้ระบุอีเมล์ที่ต้องการรับ ห้ามระบุเป็นภาษาไทย หากมีหลายอีเมล์ให้ใช้"","" หรือ "";""  คั่น 
        ///**Do not accept Thai character"
        /// </summary>
        [Description("Customer email address")]
        [ScbLayout("Detail", begin: 442, length: 64, require: false)]
        [StringLength(64)]
        public string Payee1EmailAddress { get; set; }


        /// <summary>
        /// ใช้ในกรณีพิมพ์ชื่อใน WHT คนละชื่อกับชื่อบนหน้า Cheque. Not use
        /// </summary>
        //* 
        [Description("ใช้ในกรณีพิมพ์ชื่อใน WHT คนละชื่อกับชื่อบนหน้า Cheque. Not use")]
        [ScbLayout("Detail", begin: 506, length: 100, require: false)]
        [StringLength(100)]
        public string Payee2NameThai { get; set; }

        /// <summary>
        /// ใช้ในกรณีพิมพ์ชื่อใน WHT คนละชื่อกับชื่อบนหน้า Cheque. Not use
        /// </summary>
        [Description("ใช้ในกรณีพิมพ์ชื่อใน WHT คนละชื่อกับชื่อบนหน้า Cheque. Not use")]
        [ScbLayout("Detail", begin: 606, length: 70, require: false)]
        [StringLength(70)]
        public string Payee2Address1 { get; set; }


        /// <summary>
        /// ใช้ในกรณีพิมพ์ชื่อใน WHT คนละชื่อกับชื่อบนหน้า Cheque. Not use
        /// </summary>
        [Description("ใช้ในกรณีพิมพ์ชื่อใน WHT คนละชื่อกับชื่อบนหน้า Cheque. Not use")]
        [ScbLayout("Detail", begin: 676, length: 70, require: false)]
        [StringLength(70)]
        public string Payee2Address2 { get; set; }


        /// <summary>
        /// ใช้ในกรณีพิมพ์ชื่อใน WHT คนละชื่อกับชื่อบนหน้า Cheque. Not use
        /// </summary>
        [Description("ใช้ในกรณีพิมพ์ชื่อใน WHT คนละชื่อกับชื่อบนหน้า Cheque. Not use")]
        [ScbLayout("Detail", begin: 746, length: 70, require: false)]
        [StringLength(70)]
        public string Payee2Address3 { get; set; }
    }
}
