﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public class DomesticPayment  : Entity<Guid>
    {
        public DomesticPayment()
        {
            ContainerName = "thailand-siam-commerical-bank-domestic-payment";
        }

        public Guid AttachmentId { get; set; }

        public DomesticPaymentHeader Header { get; set; }

        public IEnumerable<DomesticPaymentDebitDetail> DebitDetails { get; set; }

        public IEnumerable<DomesticPaymentCreditDetail> CreditDetails { get; set; }

        public IEnumerable<DomesticPaymentPayeeDetail> PayeeDetails { get; set; }

       // public IEnumerable<DomesticPaymentWHTDetail> WHTDetails { get; set; }

       // public IEnumerable<DomesticPaymentInvoiceDetail> InvoiceDetails { get; set; }

        public DomesticPaymentTrailer Trailer { get; set; }

    }
}
