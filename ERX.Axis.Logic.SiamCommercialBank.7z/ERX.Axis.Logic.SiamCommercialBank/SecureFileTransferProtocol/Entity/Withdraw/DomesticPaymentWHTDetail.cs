﻿using System.ComponentModel.DataAnnotations;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public class DomesticPaymentWHTDetail
    {
        //Fix "005"
        [ScbLayout("Detail", begin: 0, length: 3, require: true)]
        [StringLength(3)]
        public string RecordType { get => "005"; }

        //Ref. to Debit record (002-9)
        [ScbLayout("Detail", begin: 3, length: 8, require: true)]
        [StringLength(8)]
        public string InternalReference { get; set; }

        //Ref. to Credit record (003-2)
        [ScbLayout("Detail", begin: 11, length: 6, require: true)]
        [StringLength(6)]
        public string CreditSequenceNumber { get; set; }

        //WHT seq. Start from 1 for each Credit record.
        [ScbLayout("Detail", begin: 17, length: 2, require: true)]
        [StringLength(2)]
        public string WHTSequenceNumber { get; set; }

        //"WHT Amount ** Cannot be negative amount"
        [ScbLayout("Detail", begin: 19, length: 16, require: true)]
        [StringLength(16)]
        public string WHTAmount { get; set; }

        //Income Type :  1, 2, 3, 4a, 4b, 4b1.1, 4b1.2, 4b1.3, 4b1.4, 4b2, 4b3, 5, 6
        [ScbLayout("Detail", begin: 35, length: 5, require: true)]
        [StringLength(5)]
        public string WHTIncomeType { get; set; }

        //Mandatory when 'WHT Income Type'=6
        [ScbLayout("Detail", begin: 40, length: 80, require: false)]
        [StringLength(80)]
        public string IncomeDescription { get; set; }

        //% of WHT rate (Sample  03 = 3%,   01 = 1%)
        [ScbLayout("Detail", begin: 120, length: 2, require: true)]
        [StringLength(2)]
        public string WHTDeductRate { get; set; }

        //WHT base amt.
        [ScbLayout("Detail", begin: 122, length: 16, require: true)]
        [StringLength(16)]
        public string IncomeTypeAmount { get; set; }
    }
}
