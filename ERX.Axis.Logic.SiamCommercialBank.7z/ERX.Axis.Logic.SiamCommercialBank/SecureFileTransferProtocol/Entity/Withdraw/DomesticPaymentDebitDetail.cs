﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public class DomesticPaymentDebitDetail
    {
        /// <summary>
        /// Record type for debit detail fixed as 002
        /// </summary>
        [Description("Record type for debit detail fixed as 002")]
        [ScbLayout("Detail", begin: 0, length: 3, require: true)]
        [StringLength(3)]
        public string RecordType { get => "002"; }

        /// <summary>
        /// Product code
        /// BNT : Bahtnet
        /// DCP : Direct Credit
        /// MCL : Media Clearing(Smart Credit)
        /// </summary>
        [Description("Product code")]
        [ScbLayout("Detail", begin: 3, length: 3, require: true)]
        [StringLength(3)]
        public string ProductCode { get; set; }

        /// <summary>
        /// Transfer date, cheque datee, or BTN date should have to be bank working day
        /// </summary>
        [Description("Transfer date, cheque datee, or BTN date should have to be bank working day")]
        [ScbLayout("Detail", begin: 6, length: 8, require: true, 'D')]
        [StringLength(8)]
        public string ValueDate { get; set; }

        /// <summary>
        /// ERX For client account
        /// </summary>   
        [Description("ERX For client account")]
        [ScbLayout("Detail", begin: 14, length: 25, require: true, 'C')]
        [StringLength(25)]
        public string DebitAccountNumber { get; set; }

 
        /// <summary>
        /// Debit Account  type : "0" +  4th Digit of A/C no.        
        /// </summary>
        [Description("Debit Account  type : '0' +  4th Digit of A/C no.")]
        [ScbLayout("Detail", begin: 39, length: 2, require: false, 'N')]
        [StringLength(2)]
        public string DebitAccountType { get; set; }

        /// <summary>
        /// "0" + 1st to 3rd Digit of A/C no.
        /// </summary>
        [Description("'0' + 1st to 3rd Digit of A/C no.")]
        [ScbLayout("Detail", begin: 41, length: 4, require: false)]
        [StringLength(4)]
        public string DebitBranchCode { get; set; }

        /// <summary>
        /// THB
        /// </summary>
        [Description("Fixed as THB")]
        [ScbLayout("Detail", begin: 45, length: 3, require: true)]
        [StringLength(3)]
        public string DebitCurrencyCode { get => "THB"; }

        /// <summary>
        /// Total Credit amount (Sum of Credit Amount (003-4) which related to this Debit record (002-9))
        /// "Amount - Amount format v13v3 
        /// (13 Digits of Numeric and 3 Digits of decimal point)
        /// Example : 1200.50 --> 0000000001200500"	
        /// </summary>
        [Description("Total Credit amount (Sum of Credit Amount (003-4) which related to this Debit record (002-9))")]
        [ScbLayout("Detail", begin: 48, length: 16, require: true, 'A')]
        [StringLength(16)]
        public string DebitAmount { get; set; }

        //
        /// <summary>
        ///  For reference by Credit Record (003-6) with format WC20201030000001 (WC + YYYYMMDD + 6 digits Sequence)
        /// </summary>
        [Description("For reference by Credit Record (003-6) with format WC20201030000001 (WC + YYYYMMDD + 6 digits Sequence)")]
        [ScbLayout("Detail", begin: 64, length: 8, require: true)]
        [StringLength(8)]
        public string DebitInternalReference { get; set; }

        /// <summary>
        /// Total count Credit record (003) which releated to this Debit record (002-9)
        /// </summary>
        [Description("Total count Credit record (003) which releated to this Debit record (002-9)")]
        [ScbLayout("Detail", begin: 72, length: 6, require: true, 'N')]
        [StringLength(6)]
        public string TotalCreditRecord { get; set; }

        //
        /// <summary>
        /// บัญชีตัดค่าธรรมเนียม (Fee A/C no.)
        /// </summary>
        [Description("บัญชีตัดค่าธรรมเนียม (Fee A/C no.)")]
        [ScbLayout("Detail", begin: 78, length: 15, require: true)]
        [StringLength(15)]
        public string FeeDebitAccount { get; set; }

        /// <summary>
        /// Space
        /// </summary>
        [Description("Space")]
        [ScbLayout("Detail", begin: 93, length: 9, require: false)]
        [StringLength(9)]
        public string Filler { get; set; }

        //* 
        /// <summary>
        /// "Mandatory for MCL
        /// Blank = Next day
        /// 2 = Same day afternoon"
        /// </summary>
        [Description("Mandatory for MCL, Blank = Next day, 2 = Same day afternoon")]
        [ScbLayout("Detail", begin: 102, length: 1, require: false)]
        [StringLength(1)]
        public string MediaClearingCycle { get; set; }


        /// <summary>
        /// Fee, "0" +  4th Digit of Fee A/C no.
        /// </summary>
        [Description("Fee, '0' +  4th Digit of Fee A/C no.")]
        [ScbLayout("Detail", begin: 103, length: 2, require: false, 'N')]
        [StringLength(2)]
        public string FeeDebitAccountType { get; set; }

        /// <summary>
        /// Fee, "0" + 1st to 3rd Digit of Fee A/C no.
        /// </summary>
        [Description("Fee, '0' + 1st to 3rd Digit of Fee A/C no.")]
        [ScbLayout("Detail", begin: 105, length: 4, require: false, 'N')]
        [StringLength(4)]
        public string FeeDebitBranchCode { get; set; }
    }
}
