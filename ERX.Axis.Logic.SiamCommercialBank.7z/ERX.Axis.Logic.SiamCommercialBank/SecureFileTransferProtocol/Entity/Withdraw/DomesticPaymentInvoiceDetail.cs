﻿using System.ComponentModel.DataAnnotations;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public class DomesticPaymentInvoiceDetail
    {
        //Fix "006"
        [ScbLayout("Detail", begin: 0, length: 3, require: true)]
        [StringLength(3)]
        public string RecordType { get => "006"; }

        //Ref. to Debit record (002-9)
        [ScbLayout("Detail", begin: 3, length: 8, require: true)]
        [StringLength(8)]
        public string InternalReference { get; set; }

        //Ref. to Credit record (003-2)
        [ScbLayout("Detail", begin: 11, length: 6, require: true)]
        [StringLength(6)]
        public string CreditSequenceNumber { get; set; }

        //Invoice seq. Start from 1 for each Credit (present INV)
        [ScbLayout("Detail", begin: 17, length: 6, require: true)]
        [StringLength(6)]
        public string InvoiceSequenceNumber { get; set; }

        //Invoice number
        [ScbLayout("Detail", begin: 23, length: 15, require: true)]
        [StringLength(15)]
        public string InvoiceNumber { get; set; }

        //"*Invoice amount (Not include VAT)  
        //** Can be negative amount or zero"
        [ScbLayout("Detail", begin: 23, length: 15, require: true)]
        [StringLength(15)]
        public string InvoiceAmount { get; set; }

        //Invoice date.
        [ScbLayout("Detail", begin: 38, length: 16, require: false)]
        [StringLength(16)]
        public string InvoiceDate { get; set; }

        //Invoice Description
        [ScbLayout("Detail", begin: 54, length: 8, require: false)]
        [StringLength(8)]
        string InvoiceDescription { get; set; }

        //Purchase Order Number
        [ScbLayout("Detail", begin: 132, length: 15, require: false)]
        [StringLength(15)]
        string PONumber { get; set; }

        //VAT Amount    ** Can be negative amount
        [ScbLayout("Detail", begin: 147, length: 16, require: false)]
        [StringLength(16)]
        string VATAmount { get; set; }

        //Payee charge amount (use for display in advice only)
        [ScbLayout("Detail", begin: 163, length: 16, require: false)]
        [StringLength(16)]
        string PayeeChargeAmount { get; set; }

        //WHT Amount  ** Can be negative amount
        [ScbLayout("Detail", begin: 179, length: 16, require: false)]
        [StringLength(16)]
        string WHTAmount { get; set; }

        //"T" or "E"
        [ScbLayout("Detail", begin: 195, length: 1, require: true)]
        [StringLength(1)]
        string PrintLanguage { get; set; }
    }
}
