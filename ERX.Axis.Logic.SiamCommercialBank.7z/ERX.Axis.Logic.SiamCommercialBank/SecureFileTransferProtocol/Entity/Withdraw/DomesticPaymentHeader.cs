﻿using System.ComponentModel.DataAnnotations;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public class DomesticPaymentHeader
    {
        //Fix "001"
        [ScbLayout("Header", begin: 0, length: 3, require: true)]
        [StringLength(3)]
        public string RecordType { get => "001"; }

        //ScbLayout Company Id
        [ScbLayout("Header", begin: 3, length: 12, require: true)]
        [StringLength(12)]
        public string CompanyId { get; set; }


        //ScbLayout Company Id
        [ScbLayout("Header", begin: 15, length: 32, require: true)]
        [StringLength(32)]
        public string CustomerReference { get; set; }


        //Date of generate/extract data
        [ScbLayout("Header", begin: 47, length: 8, require: true, 'D')]
        [StringLength(8)]
        public string MessageDate { get; set; }


        //Time of generate/extract data
        [ScbLayout("Header", begin: 55, length: 6, require: true, 'T')]
        [StringLength(6)]
        public string MessageTime { get; set; }


        //Fix "BCM" 
        [ScbLayout("Header", begin: 61, length: 3, require: true)]
        [StringLength(3)]
        public string ChanelId { get => "BCM"; }

        //??
        [ScbLayout("Header", begin: 65, length: 32, require: false)]
        [StringLength(32)]
        public string BatchReference { get; set; }
    }
}
