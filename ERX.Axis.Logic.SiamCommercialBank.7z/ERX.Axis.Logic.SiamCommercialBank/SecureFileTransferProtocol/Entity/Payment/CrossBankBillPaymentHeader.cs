﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public class CrossBankBillPaymentHeader 
    {

        public Guid AttachmentId { get; set; }

        public string AttachmentName { get; set; }


        public string TransactionType { get; set; }



        /// <summary>
        /// "H" = Header
        /// </summary>
        [Description("Record Type")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "recordType")] // to cosmos (egress)
        [ScbLayout("Header", begin: 0, length: 1)]
        [StringLength(1)]
        public string RecordType { get; set; }


        /// <summary>
        /// Running Sequence No. casting from string(6) to integer
        /// </summary>
        [Description("Sequence No.")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "sequenceNo")] // to cosmos (egress)
        [ScbLayout("Header", begin: 1, length: 6)]
        public int SequenceNo { get; set; }

        
        /// <summary>
        /// รหัสธนาคาร = 014 (SCB)
        /// </summary>
        [Description("Bank Code")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "bankCode")] // to cosmos (egress)
        [ScbLayout("Header", begin: 7, length: 3)]
        [StringLength(3)]
        public string BankCode { get; set; }


        /// <summary>
        /// เลขที่บัญชีบริษัท
        /// </summary>
        [Description("Company Account")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "companyAccount")] // to cosmos (egress)
        [ScbLayout("Header", begin: 10, length: 10)]
        [StringLength(10)]
        public string CompanyAccount { get; set; }


        /// <summary>
        /// ชื่อบริษัท
        /// </summary>
        [Description("Company Name")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "companyName")] // to cosmos (egress)
        [ScbLayout("Header", begin: 20, length: 40)]
        [StringLength(40)]
        public string CompanyName { get; set; }

        /// <summary>
        /// Effective Date (AS  AT)  --DDMMYYYY (วันที่ส่งข้อมูล)
        /// </summary>
        [Description("Effective Date (AS  AT)")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "effectiveDate")] // to cosmos (egress)
        [ScbLayout("Header", begin: 60, length: 8)]
        [StringLength(8)]
        public string EffectiveDate { get; set; }

        /// <summary>
        /// ใช้สำหรับธนาคารกรุงเทพ  --reserve for Bangkok bank
        /// </summary>
        [Description("Service Code")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "serviceCode")] // to cosmos (egress)
        [ScbLayout("Header", begin: 68, length: 8)]
        [StringLength(8)]
        public string ServiceCode { get; set; }

    }


}
