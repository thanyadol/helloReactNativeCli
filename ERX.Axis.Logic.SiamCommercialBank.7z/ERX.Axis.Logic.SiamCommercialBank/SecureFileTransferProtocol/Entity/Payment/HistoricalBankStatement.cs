﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace ERX.Axis.Logic.SiamCommercialBank
{

    public class HistoricalBankStatement : Entity<string>
    {

        public HistoricalBankStatement()
        {
            ContainerName = "thailand-siam-commerical-bank-historical-bank-statement";
        }


        public Guid AttachmentId { get; set; }
        public string AttachmentName { get; set; }


        /// <summary>
        /// เลขที่บัญชี
        /// </summary>
        [Description("Account No.")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "account")] // to cosmos (egress)
        [ScbLayout("Detail", begin: 0, length: 10)]
        [StringLength(10)]
        public string Account { get; set; }

        /// <summary>
        ///  วันที่ทำรายการ  --format dd/mm/yyyy
        /// </summary>
        [Description("Transaction Date")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "date")] // to cosmos (egress)
        [ScbLayout("Detail", begin: 10, length: 10)]
        [StringLength(10)]
        public string Date { get; set; }

        /// <summary>
        /// เวลาที่ทำรายการ -- format HH:MM
        /// </summary>
        [Description("Transaction Time")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "time")] // to cosmos (egress)
        [ScbLayout("Detail", begin: 20, length: 5)]
        [StringLength(5)]
        public string Time { get; set; }


        /// <summary>
        /// วันที่ชำระเงิน (วันที่ที่มีผลชำระเงิน) format = DDMMYYYY
        /// </summary>
        [Description("Transaction Date as unix time stamp")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "transactionUnixTimeStamp")] // to cosmos (egress)
        public int TransactionUnixTimeStamp { get; set; }  //DDMMYYYYY


        /// <summary>
        /// Transaction Code
        /// </summary>
        [Description("Transaction Code")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "transCode")] // to cosmos (egress)
        [ScbLayout("Detail", begin: 25, length: 3)]
        [StringLength(3)]
        public string TransCode { get; set; }

        /// <summary>
        ///  ช่องทางการใช้บริการ
        /// </summary>
        [Description("Chanel of service")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "channel")] // to cosmos (egress)
        [ScbLayout("Detail", begin: 28, length: 4)]
        [StringLength(4)]
        public string Channel { get; set; }

        /// <summary>
        /// หมายเลขเช็ค
        /// </summary>
        [Description("Cheque No.")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "chequeNo")] // to cosmos (egress)
        [ScbLayout("Detail", begin: 32, length: 8)]
        [StringLength(8)]
        public string ChequeNo { get; set; }

        /// <summary>
        /// แสดงสถานะของบัญชี (Dr, Cr)  -- what is this ???
        /// </summary>
        [Description("Express the Account status")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "atmSign")] // to cosmos (egress)
        [ScbLayout("Detail", begin: 40, length: 1)]
        [StringLength(1)]
        public string AtmSign { get; set; }

        /// <summary>
        /// จำนวนเงิน (หน่วยเป็นพันบาท) สองหน่วยสุดท้ายเป็นสตางค์)
        /// </summary>
        [Description("Transaction amount")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "transAmt")] // to cosmos (egress)
        [ScbLayout("Detail", begin: 41, length: 16)]
        [StringLength(16)]
        public decimal TransAmt { get; set; }

        /// <summary>
        /// แสดงสถานะของบัญชี (Dr, Cr)   -- what is this ???
        /// </summary>
        [Description("Express the account status")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "")] // to cosmos (egress)
        [ScbLayout("Detail", begin: 57, length: 1)]
        [StringLength(1)]
        public string BalSign { get; set; }

        /// <summary>
        ///  จำนวนเงิน (หน่วยเป็นพันบาท) สองหน่วยสุดท้ายเป็นสตางค์)
        /// </summary>
        [Description("Transaction balance")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "transBal")] // to cosmos (egress)
        [ScbLayout("Detail", begin: 58, length: 16)]
        [StringLength(16)]
        public decimal TransBal { get; set; }


        /// <summary>
        /// คำอธิบาย
        /// </summary>
        [Description("Transaction description")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "description")] // to cosmos (egress)
        [ScbLayout("Detail", begin: 74, length: 40)]
        [StringLength(40)]
        public string Description { get; set; }
    }
}
