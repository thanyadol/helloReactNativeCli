﻿using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public class CrossBankBillPayment : Entity<string>
    {
        public CrossBankBillPayment()
        {
            Details = new List<CrossBankBillPaymentDetail>();
        }

        public Guid AttachmentId { get; set; }

        public string AttachmentName { get; set; }
        public string TransactionType { get; set; }

        /// <summary>
        /// See CrossBankBillPaymentHeader
        /// </summary>
        [Description("Header section of CrossBankBillPayment")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "header")] // to cosmos (egress)
        internal CrossBankBillPaymentHeader Header { get; set; }

        /// <summary>
        /// See CrossBankBillPaymentDetail  --List
        /// </summary>
        [Description("Body section of CrossBankBillPayment")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "details")] // to cosmos (egress)
        internal List<CrossBankBillPaymentDetail> Details { get; set; }

        /// <summary>
        /// See CrossBankBillPaymentTotal
        /// </summary>
        [Description("Total section of CrossBankBillPayment")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "total")] // to cosmos (egress)
        internal CrossBankBillPaymentTotal Total { get; set; }

    }
}
