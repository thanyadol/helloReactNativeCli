﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public class CrossBankBillPaymentDetail  : Entity<string>
    {
        public CrossBankBillPaymentDetail()
        {
            ContainerName = "thailand-siam-commerical-bank-cross-bank-bill-payment";
        }

        /// <summary>
        /// Reference to CrossBankBillPaymentHeader
        /// </summary>
        [Description("Reference to CrossBankBillPaymentHeader")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "headerId")] // to cosmos (egress)
        public CrossBankBillPaymentHeader Header { get; set; }


        /// <summary>
        /// "D" = Detail
        /// </summary>
        [Description("Record Type")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "recordType")] // to cosmos (egress)
        [ScbLayout("Detail", begin: 0, length: 1)]
        [StringLength(1)]
        public string RecordType { get; set; }

        /// <summary>
        /// Running Sequence No. casting from string(6) to integer
        /// </summary>
        [Description("Sequence No.")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "sequenceNo")] // to cosmos (egress)
        [ScbLayout("Detail", begin: 1, length: 6)]
        public int SequenceNo { get; set; }

        /// <summary>
        /// รหัสธนาคาร = 014 (SCB)
        /// </summary>
        [Description("Bank Code")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "bankCode")] // to cosmos (egress)
        [ScbLayout("Detail", begin: 7, length: 3)]
        [StringLength(3)]
        public string BankCode { get; set; }


        /// <summary>
        /// เลขที่บัญชีบริษัท
        /// </summary>
        [Description("Company Account")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "companyAccount")] // to cosmos (egress)
        [ScbLayout("Detail", begin: 10, length: 10)]
        [StringLength(10)]
        public string CompanyAccount { get; set; }

        /// <summary>
        /// วันที่ชำระเงิน (วันที่ที่มีผลชำระเงิน) format = DDMMYYYY
        /// </summary>
        [Description("Payment Date")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "paymentDate")] // to cosmos (egress)
        [ScbLayout("Detail", begin: 20, length: 8)]
        [StringLength(8)]
        public string PaymentDate { get; set; }  //DDMMYYYYY


        /// <summary>
        /// เวลาที่ชำระเงิน format = "HHMMSS'
        /// </summary>
        [Description("Payment Time")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "paymentTime")] // to cosmos (egress)
        [ScbLayout("Detail", begin: 28, length: 6)]
        [StringLength(6)]
        public string PaymentTime { get; set; }  //HHMMSS



        /// <summary>
        /// วันที่ชำระเงิน (วันที่ที่มีผลชำระเงิน) format = DDMMYYYY
        /// </summary>
        [Description("Payment Date as unix time stamp")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "paymentUnixTimeStamp")] // to cosmos (egress)
        public int PaymentUnixTimeStamp { get; set; }  //DDMMYYYYY



        /// <summary>
        /// ชื่อผู้ชำระเงิน
        /// </summary>
        [Description("Customer Name")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "customerName")] // to cosmos (egress)
        [ScbLayout("Detail", begin: 34, length: 50)]
        [StringLength(40)]
        public string CustomerName { get; set; }

        /// <summary>
        /// หมายเลขลูกค้า 1
        /// </summary>
        [Description("Customer No./Ref 1")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "customerNoRef1")] // to cosmos (egress)
        [ScbLayout("Detail", begin: 84, length: 20)]
        [StringLength(40)]
        public string CustomerNoRef1 { get; set; }

        /// <summary>
        /// หมายเลขลูกค้า 2
        /// </summary>
        [Description("Ref 2")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "customerNoRef2")] // to cosmos (egress)
        [ScbLayout("Detail", begin: 104, length: 20)]
        [StringLength(40)]
        public string CustomerNoRef2 { get; set; }

        /// <summary>
        /// หมายเลขลูกค้า 3 
        /// </summary>
        [Description("Ref 3")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "customerNoRef3")] // to cosmos (egress)
        [ScbLayout("Detail", begin: 124, length: 20)]
        [StringLength(20)]
        public string CustomerNoRef3 { get; set; }


        /// <summary>
        /// รหัสสาขา (รายการจากธนาคารอื่น = 0000) for other bank = 0000
        /// </summary>
        [Description("Branch No.")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "branchNo")] // to cosmos (egress)
        [ScbLayout("Detail", begin: 144, length: 4)]
        [StringLength(4)]
        public string BranchNo { get; set; }


        /// <summary>
        /// Terminal No. // Terminal No	Channel
        ///     1147 =	SMS & USSD
        ///     1800 =	SCB Business Net
        ///     2000 = ATM
        ///     2100 =	ATM Phone
        ///     2150 =	SCB Easy Phone
        ///     2200 =	CDM
        ///     2456 =	SCB Easy Call Center
        ///     2550 =	SCB Easy Net & SCB Mobile Banking
        ///     2690 =	M-Pay
        ///     5000 =	SCB Partner
        ///     5100 =	EDC
        ///     Others = Counter
        /// </summary>
        [Description("")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "tellerNo")] // to cosmos (egress)
        [ScbLayout("Detail", begin: 148, length: 4)]
        [StringLength(4)]
        public string TellerNo { get; set; }

        /// <summary>
        /// Kind of Transaction -- "D" = Debit, "C" = Credit
        /// </summary>
        [Description("Kind of Transaction")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "kindOfTransaction")] // to cosmos (egress)
        [ScbLayout("Detail", begin: 152, length: 1)]
        [StringLength(1)]
        public string KindOfTransaction { get; set; }

        /// <summary>
        /// Transactio Code see TransctionCode Enum
        /// </summary>
        [Description("Transactio Code")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "transactionCode")] // to cosmos (egress)
        [ScbLayout("Detail", begin: 153, length: 3)]
        [StringLength(3)]
        public string TransactionCode { get; set; }

        /// <summary>
        /// หมายเลขเช็ค
        /// </summary>
        [Description("Cheque No.")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "chequeNo")] // to cosmos (egress)
        [ScbLayout("Detail", begin: 156, length: 7)]
        [StringLength(7)]
        public string ChequeNo { get; set; }


        /// <summary>
        /// จำนวนเงิน
        /// </summary>
        [Description("Amount")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "amount")] // to cosmos (egress)
        [ScbLayout("Detail", begin: 163, length: 13)]
        public decimal Amount { get; set; }

        /// <summary>
        /// รหัสธนาคารเจ้าของเช็ค
        /// </summary>
        [Description("Chq Bank Code")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "chqBankCode")] // to cosmos (egress)
        [ScbLayout("Detail", begin: 176, length: 3)]
        [StringLength(3)]
        public string ChqBankCode { get; set; }

        /// <summary>
        /// Biller ID ที่ทำรายการชำระเงิน -New Field on Cross Bank Bill Payment
        /// </summary>
        [Description("Biller ID")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "billerID")] // to cosmos (egress)
        [ScbLayout("Detail", begin: 196, length: 15)]
        [StringLength(15)]
        public string BillerID { get; set; }

        /// <summary>
        /// รหัสธนาคารที่ทำรายการพร้อมเพย์  --New Field on Cross Bank Bill Payment
        /// </summary>
        [Description("Sending Bank Code")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "sendingBankCode")] // to cosmos (egress)
        [ScbLayout("Detail", begin: 243, length: 3)]
        [StringLength(3)]
        public string SendingBankCode { get; set; }

        /// <summary>
        /// หมายเลขเช็ค  --New Field on Cross Bank Bill Payment
        /// </summary>
        [Description("New Cheque No.")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "newChequeNo")] // to cosmos (egress)
        [ScbLayout("Detail", begin: 246, length: 10)]
        [StringLength(10)]
        public string NewChequeNo { get; set; }


        /// <summary>
        /// 
        /// </summary>
        public CrossBankBillPaymentTotal Total { get; set; }
    }
}
