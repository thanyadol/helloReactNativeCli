﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public class CrossBankBillPaymentTotal
    {
        /// <summary>
        /// Reference to CrossBankBillPaymentHeader
        /// </summary>
        [Description("Reference to CrossBankBillPaymentHeader")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "headerId")] // to cosmos (egress)
        public string HeaderId { get; set; }

        /// <summary>
        /// "T" = Total
        /// </summary>
        [Description("Record Type")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "recordType")] // to cosmos (egress)
        [ScbLayout("Total", begin: 0, length: 1)]
        [StringLength(1)]
        public string RecordType { get; set; }


        /// <summary>
        /// Running Sequence No. casting from string(6) to integer
        /// </summary>
        [Description("Sequence No.")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "sequenceNo")] // to cosmos (egress)
        [ScbLayout("Total", begin: 1, length: 6)]
        [StringLength(6)]
        public int SequenceNo { get; set; }


        /// <summary>
        /// รหัสธนาคาร = 014 (SCB)
        /// </summary>
        [Description("Bank Code")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "bankCode")] // to cosmos (egress)
        [ScbLayout("Total", begin: 7, length: 3)]
        [StringLength(3)]
        public string BankCode { get; set; }


        /// <summary>
        /// เลขที่บัญชีบริษัท
        /// </summary>
        [Description("Company Account")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "companyAccount")] // to cosmos (egress)
        [ScbLayout("Total", begin: 10, length: 10)]
        [StringLength(10)]
        public string CompanyAccount { get; set; }

        /// <summary>
        /// 0000000000000 -- fixed
        /// </summary>
        [Description("Total Debit Amount")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "totalDebitAmount")] // to cosmos (egress)
        [ScbLayout("Total", begin: 20, length: 13)]
        public decimal TotalDebitAmount { get; set; }

        /// <summary>
        /// 000000 --fixed
        /// </summary>
        [Description("Total Debit Transaction")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "totalDebitTransaction")] // to cosmos (egress)
        [ScbLayout("Total", begin: 33, length: 6)]
        public decimal TotalDebitTransaction { get; set; }

        /// <summary>
        /// ผลรวมจำนวนเงิน
        /// </summary>
        [Description("Total Credit Amount")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "totalCreditAmount")] // to cosmos (egress)
        [ScbLayout("Total", begin: 39, length: 13)]
        public decimal TotalCreditAmount { get; set; }

        /// <summary>
        ///  ผลรวมจำนวนรายการ
        /// </summary>
        [Description("Total Credit Transaction")]
        [Newtonsoft.Json.JsonProperty(PropertyName = "totalCreditTransaction")] // to cosmos (egress)
        [ScbLayout("Total", begin: 52, length: 6)]
        public decimal TotalCreditTransaction { get; set; }
    }
}
