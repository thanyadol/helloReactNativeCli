﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    /// <summary>
    /// Bank account class compisite by Investor and ONE CIRCLE transaction
    ///
    /// </summary>

    public class BankAccount
    {
        [JsonProperty("investorId")]
        public string InvestorId { get; set; }

        [JsonProperty("id")]
        public string Id { get; set; }

        [JsonProperty("createdDate")]
        public int? CreatedDate { get; set; }

        [JsonProperty("accountName")]
        public string AccountName { get; set; }

        [JsonProperty("bankName")]
        public string BankName { get; set; }

        [JsonProperty("accountNumber")]
        public string AccountNumber { get; set; }

        [JsonProperty("branch")]
        public string Branch { get; set; }

        [JsonProperty("province")]
        public string Province { get; set; }

        [JsonProperty("country")]
        public string Country { get; set; }

        [JsonProperty("swiftCode")]
        public string SwiftCode { get; set; }

        [JsonProperty("isPrimary")]
        public bool? IsPrimary { get; set; }

        [JsonProperty("isVerified")]
        public bool? IsVerified { get; set; }

        [JsonProperty("isRejected")]
        public bool? IsRejected { get; set; }

        [JsonProperty("bahtnetZone")]
        public string BahtnetZone { get; set; }

        [JsonProperty("bankAddress")]
        public Address BankAddress { get; set; }

        [JsonProperty("bankShortName")]
        public string BankShortName { get; set; }

        [JsonProperty("imageId")]
        public string ImageId { get; set; }

        [JsonProperty("verifyStepId")]
        public string VerifyStepId { get; set; }

        [JsonProperty("lastModifiedDate")]
        public int? LastModifiedDate { get; set; }

        // [JsonProperty("_flagged")]
        // public object Flagged { get; set; }
        

    }
}
