using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    /// <summary>
    /// ONE CIRCLE Investor
    /// </summary>
    /// 

    public class Investor : Entity<string>
    {
        public Investor()
        {
            ContainerName = "investors";
        }

        [JsonProperty("oktaId")]
        public string OktaId { get; set; }

        [JsonProperty("matiReferenceId")]
        public string MatiReferenceId { get; set; }

        [JsonProperty("isSedInvestor")]
        public bool? IsSedInvestor { get; set; }

        [JsonProperty("operationId")]
        public string OperationId { get; set; }

        [JsonProperty("isSubmitConfirmed")]
        public bool? IsSubmitConfirmed { get; set; }

        [JsonProperty("submitConfirmedDateTime")]
        public int? SubmitConfirmedDateTime { get; set; }


        [JsonProperty("countryOfBirth")]
        public Country CountryOfBirth { get; set; }

        [JsonProperty("residenceCountry")]
        public Country ResidenceCountry { get; set; }

        [JsonProperty("phoneNumbers")]
        public List<Phone> PhoneNumbers { get; set; }

        [JsonProperty("bankAccounts")]
        public List<BankAccount> BankAccounts { get; set; }

        //[JsonProperty("ultimateBeneficialOwnerContact")]
        //public object UltimateBeneficialOwnerContact { get; set; }

        [JsonProperty("emergencyContact")]
        public Contact EmergencyContact { get; set; }


        [JsonProperty("thailandIdCard")]
        public Card ThailandIdCard { get; set; }

        [JsonProperty("nationality")]
        public string Nationality { get; set; }

        [JsonProperty("maritalStatus")]
        public string MaritalStatus { get; set; }

        [JsonProperty("education")]
        public string Education { get; set; }

        [JsonProperty("occupation")]
        public string Occupation { get; set; }

        [JsonProperty("occupationDescription")]
        public string OccupationDescription { get; set; }

        [JsonProperty("yearsOfWork")]
        public int? YearsOfWork { get; set; }

        [JsonProperty("incomePerMonth")]
        public string IncomePerMonth { get; set; }

        [JsonProperty("sourceOfIncome")]
        public string SourceOfIncome { get; set; }

        [JsonProperty("sourceOfIncomeDesc")]
        public string SourceOfIncomeDesc { get; set; }

        [JsonProperty("countrySourceOfIncome")]
        public Country CountrySourceOfIncome { get; set; }


        //[JsonProperty("employeeContact")]
        //public object EmployeeContact { get; set; }
        /*
        [JsonProperty("hasRelationErxEmployee")]
        public bool? HasRelationErxEmployee { get; set; }

        [JsonProperty("accountClosedDate")]
        public int? AccountClosedDate { get; set; }

        [JsonProperty("accountOpenedDate")]
        public int? AccountOpenedDate { get; set; }

        [JsonProperty("isLockedTransaction")]
        public bool? IsLockedTransaction { get; set; }

        [JsonProperty("investorType")]
        public string InvestorType { get; set; }

        [JsonProperty("totalToken")]
        public int? TotalToken { get; set; }



        //[JsonProperty("passports")]
        // public object Passports { get; set; }

        [JsonProperty("passport")]
        public Passport Passport { get; set; }

        [JsonProperty("fatcaQuestions")]
        public FatcaQuestions FatcaQuestions { get; set; }

        [JsonProperty("suitabilityTest")]
        public Suitability SuitabilityTest { get; set; }

        [JsonProperty("launchpadOverviewFlags")]
        public Flag LaunchpadOverviewFlags { get; set; }


        [JsonProperty("matiIdentityIds")]
        public MatiIdentityIds MatiIdentityIds { get; set; }

        [JsonProperty("homePhones")]
        public List<Phone> HomePhones { get; set; }

        [JsonProperty("mobilePhone")]
        public Phone MobilePhone { get; set; }

        [JsonProperty("businessPhones")]
        public List<Phone> BusinessPhones { get; set; }


        [JsonProperty("accountType")]
        public string AccountType { get; set; }

        [JsonProperty("accountCreditLine")]
        public string AccountCreditLine { get; set; }

        [JsonProperty("lockedDate")]
        public int? LockedDate { get; set; }

        [JsonProperty("riskDate")]
        public int? RiskDate { get; set; }

        [JsonProperty("tradeLevel")]
        public int? TradeLevel { get; set; }

        [JsonProperty("isThaiIdFrontUploaded")]
        public bool? IsThaiIdFrontUploaded { get; set; }

        [JsonProperty("isThaiIdBackUploaded")]
        public bool? IsThaiIdBackUploaded { get; set; }

        [JsonProperty("isPassportUploaded")]
        public bool? IsPassportUploaded { get; set; }

        [JsonProperty("isIdentityVerificationStarted")]
        public bool? IsIdentityVerificationStarted { get; set; }

        [JsonProperty("matiStatusProgress")]
        public string MatiStatusProgress { get; set; }

        [JsonProperty("complyAdvantageStatusProgress")]
        public string ComplyAdvantageStatusProgress { get; set; }

        [JsonProperty("dopaStatusProgress")]
        public string DopaStatusProgress { get; set; }

        [JsonProperty("ledStatusProgress")]
        public string LedStatusProgress { get; set; }

        [JsonProperty("investmentObjective")]
        public string InvestmentObjective { get; set; }

        [JsonProperty("investmentObjectiveDescription")]
        public string InvestmentObjectiveDescription { get; set; }

        // [JsonProperty("alphaPointAccount")]
        //public object AlphaPointAccount { get; set; }

        //[JsonProperty("approve1")]
        //public object Approve1 { get; set; }

        //[JsonProperty("approve2")]
        // public object Approve2 { get; set; }

        [JsonProperty("isKycCompleted")]
        public bool? IsKycCompleted { get; set; }

        [JsonProperty("isRiskLevel3")]
        public bool? IsRiskLevel3 { get; set; }

        [JsonProperty("isValidDocument")]
        public bool? IsValidDocument { get; set; }

        [JsonProperty("isAlphaPointAccountCreated")]
        public bool? IsAlphaPointAccountCreated { get; set; }

        [JsonProperty("isLocked")]
        public bool? IsLocked { get; set; }

        [JsonProperty("isRejectEmailSent")]
        public bool? IsRejectEmailSent { get; set; }

        [JsonProperty("rejectReason")]
        public string RejectReason { get; set; }

        [JsonProperty("changeKey")]
        public string ChangeKey { get; set; }

        [JsonProperty("categories")]
        public string Categories { get; set; }

        [JsonProperty("parentFolderId")]
        public string ParentFolderId { get; set; }

        [JsonProperty("dateOfBirth")]
        public int? DateOfBirth { get; set; }

        //[JsonProperty("fileAs")]
        //public object FileAs { get; set; }


        [JsonProperty("additionalName")]
        public string AdditionalName { get; set; }

        [JsonProperty("familyName")]
        public string FamilyName { get; set; }

        //[JsonProperty("nickName")]
        //public string NickName { get; set; }

        //[JsonProperty("initials")]
        //public object Initials { get; set; }

        [JsonProperty("namePrefix")]
        public string NamePrefix { get; set; }

        [JsonProperty("nameSuffix")]
        public string NameSuffix { get; set; }

        [JsonProperty("fullName")]
        public string FullName { get; set; }

        [JsonProperty("gender")]
        public string Gender { get; set; }

        [JsonProperty("generation")]
        public int? Generation { get; set; }


        //[JsonProperty("imAddresses")]
        //public object ImAddresses { get; set; }

        [JsonProperty("businessType")]
        public string BusinessType { get; set; }

        [JsonProperty("businessTypeDescription")]
        public string BusinessTypeDescription { get; set; }

        [JsonProperty("jobTitle")]
        public string JobTitle { get; set; }

        [JsonProperty("jobTitleDescription")]
        public string JobTitleDescription { get; set; }

        [JsonProperty("companyName")]
        public string CompanyName { get; set; }

        [JsonProperty("department")]
        public string Department { get; set; }

        [JsonProperty("officeLocation")]
        public string OfficeLocation { get; set; }

        [JsonProperty("profession")]
        public string Profession { get; set; }

        [JsonProperty("businessHomePage")]
        public string BusinessHomePage { get; set; }

        [JsonProperty("assistantName")]
        public string AssistantName { get; set; }

        [JsonProperty("manager")]
        public string Manager { get; set; }


        [JsonProperty("businessAddress")]
        public Address BusinessAddress { get; set; }

        [JsonProperty("otherAddress")]
        public Address OtherAddress { get; set; }

        //[JsonProperty("spouseContact")]
        //public string SpouseContact { get; set; }

        [JsonProperty("children")]
        public int? Children { get; set; }

        [JsonProperty("personalNotes")]
        public string PersonalNotes { get; set; }

        [JsonProperty("lastModifiedDate")]
        public int? LastModifiedDate { get; set; }*/


        [JsonProperty("homeAddress")]
        public Address HomeAddress { get; set; }

        [JsonProperty("emailAddresses")]
        public List<Email> EmailAddresses { get; set; }


        [JsonProperty("displayName")]
        public string DisplayName { get; set; }

        [JsonProperty("givenName")]
        public string GivenName { get; set; }

    }



    public class Email
    {
        [JsonProperty("address")]
        public string Address { get; set; }

        [JsonProperty("displayName")]
        public string DisplayName { get; set; }

        [JsonProperty("type")]
        public string Type { get; set; }

        [JsonProperty("isPrimary")]
        public bool? IsPrimary { get; set; }
    }


    public class Contact
    {
        [JsonProperty("id")]
        public string Id { get; set; }

        [JsonProperty("createdDate")]
        public int? CreatedDate { get; set; }

        [JsonProperty("relation")]
        public string Relation { get; set; }

        [JsonProperty("changeKey")]
        public string ChangeKey { get; set; }

        [JsonProperty("categories")]
        public string Categories { get; set; }

        [JsonProperty("parentFolderId")]
        public string ParentFolderId { get; set; }

        [JsonProperty("dateOfBirth")]
        public int? DateOfBirth { get; set; }

        //[JsonProperty("fileAs")]
        //public string FileAs { get; set; }

        [JsonProperty("displayName")]
        public string DisplayName { get; set; }

        [JsonProperty("givenName")]
        public string GivenName { get; set; }

        [JsonProperty("additionalName")]
        public string AdditionalName { get; set; }

        [JsonProperty("familyName")]
        public string FamilyName { get; set; }

        [JsonProperty("nickName")]
        public string NickName { get; set; }

        [JsonProperty("initials")]
        public string Initials { get; set; }

        [JsonProperty("namePrefix")]
        public string NamePrefix { get; set; }

        [JsonProperty("nameSuffix")]
        public string NameSuffix { get; set; }

        [JsonProperty("fullName")]
        public string FullName { get; set; }

        [JsonProperty("gender")]
        public string Gender { get; set; }

        [JsonProperty("generation")]
        public int? Generation { get; set; }

        [JsonProperty("emailAddresses")]
        public List<Email> EmailAddresses { get; set; }

        [JsonProperty("imAddresses")]
        public string ImAddresses { get; set; }

        [JsonProperty("businessType")]
        public string BusinessType { get; set; }

        [JsonProperty("businessTypeDescription")]
        public string BusinessTypeDescription { get; set; }

        [JsonProperty("jobTitle")]
        public string JobTitle { get; set; }

        [JsonProperty("jobTitleDescription")]
        public string JobTitleDescription { get; set; }

        [JsonProperty("companyName")]
        public string CompanyName { get; set; }

        [JsonProperty("department")]
        public string Department { get; set; }

        [JsonProperty("officeLocation")]
        public string OfficeLocation { get; set; }

        [JsonProperty("profession")]
        public string Profession { get; set; }

        [JsonProperty("businessHomePage")]
        public string BusinessHomePage { get; set; }

        [JsonProperty("assistantName")]
        public string AssistantName { get; set; }

        [JsonProperty("manager")]
        public string Manager { get; set; }

        [JsonProperty("homePhones")]
        public Phone HomePhones { get; set; }

        [JsonProperty("mobilePhone")]
        public Phone MobilePhone { get; set; }

        [JsonProperty("businessPhones")]
        public Address BusinessPhones { get; set; }

        [JsonProperty("homeAddress")]
        public Address HomeAddress { get; set; }

        [JsonProperty("businessAddress")]
        public Address BusinessAddress { get; set; }

        [JsonProperty("otherAddress")]
        public string OtherAddress { get; set; }

        [JsonProperty("spouseContact")]
        public string SpouseContact { get; set; }

        [JsonProperty("children")]
        public string Children { get; set; }

        [JsonProperty("personalNotes")]
        public string PersonalNotes { get; set; }

        [JsonProperty("lastModifiedDate")]
        public int? LastModifiedDate { get; set; }

        // [JsonProperty("_flagged")]
        // public object Flagged { get; set; }
    }

    public class Confidence
    {
        [JsonProperty("id_number")]
        public double IdNumber { get; set; }

        [JsonProperty("name_th")]
        public double NameTh { get; set; }

        [JsonProperty("first_name_en")]
        public double FirstNameEn { get; set; }

        [JsonProperty("last_name_en")]
        public double LastNameEn { get; set; }

        [JsonProperty("date_of_birth_th")]
        public double DateOfBirthTh { get; set; }

        [JsonProperty("date_of_birth_en")]
        public double DateOfBirthEn { get; set; }

        [JsonProperty("religion_th")]
        public double? ReligionTh { get; set; }

        [JsonProperty("address_th")]
        public double AddressTh { get; set; }

        [JsonProperty("date_of_issue_th")]
        public double DateOfIssueTh { get; set; }

        [JsonProperty("date_of_issue_en")]
        public double DateOfIssueEn { get; set; }

        [JsonProperty("date_of_expiry_th")]
        public double DateOfExpiryTh { get; set; }

        [JsonProperty("date_of_expiry_en")]
        public double DateOfExpiryEn { get; set; }

        [JsonProperty("serial_number")]
        public double SerialNumber { get; set; }

        [JsonProperty("portrait")]
        public double? Portrait { get; set; }
    }



    public class FatcaQuestions
    {
        [JsonProperty("isUsCitizen")]
        public bool? IsUsCitizen { get; set; }

        [JsonProperty("isHolderOfUsPermanentResidence")]
        public bool? IsHolderOfUsPermanentResidence { get; set; }

        [JsonProperty("hasToPayUsTax")]
        public bool? HasToPayUsTax { get; set; }

        [JsonProperty("wasBornInUsa")]
        public bool? WasBornInUsa { get; set; }

        //[JsonProperty("w9Form")]
        // public object W9Form { get; set; }

        [JsonProperty("isW9FormVerified")]
        public bool? IsW9FormVerified { get; set; }

        // [JsonProperty("w8Form")]
        // public object W8Form { get; set; }

        [JsonProperty("isW8FormVerified")]
        public bool? IsW8FormVerified { get; set; }

        //   [JsonProperty("fatcaFormDs4083")]
        //  public object FatcaFormDs4083 { get; set; }

        [JsonProperty("isFatcaFormDS4083Verified")]
        public bool? IsFatcaFormDS4083Verified { get; set; }
    }


    public class MatiIdentityIds
    {
    }


    public class Country
    {
        [JsonProperty("countryName")]
        public string CountryName { get; set; }

        [JsonProperty("countryCode")]
        public string CountryCode { get; set; }
    }

    public class Address
    {
        [JsonProperty("type")]
        public string Type { get; set; }

        [JsonProperty("mailClass")]
        public string MailClass { get; set; }

        [JsonProperty("isPrimary")]
        public bool? IsPrimary { get; set; }

        [JsonProperty("agent")]
        public string Agent { get; set; }

        [JsonProperty("housename")]
        public string Housename { get; set; }

        [JsonProperty("street")]
        public string Street { get; set; }

        [JsonProperty("poBox")]
        public string PoBox { get; set; }

        [JsonProperty("neighborhood")]
        public string Neighborhood { get; set; }

        [JsonProperty("city")]
        public string City { get; set; }

        [JsonProperty("subregion")]
        public string Subregion { get; set; }

        [JsonProperty("region")]
        public string Region { get; set; }

        [JsonProperty("postalCode")]
        public string PostalCode { get; set; }

        [JsonProperty("country")]
        public Country Country { get; set; }

        [JsonProperty("formattedAddress")]
        public string FormattedAddress { get; set; }
    }



    //
    public class Phone
    {
        [JsonProperty("type")]
        public string Type { get; set; }

        [JsonProperty("uri")]
        public string Uri { get; set; }

        [JsonProperty("isPrimary")]
        public bool? IsPrimary { get; set; }

        [JsonProperty("text")]
        public string Text { get; set; }
    }

    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 
    
    public class Front
    {
        [JsonProperty("idNumber")]
        public string IdNumber { get; set; }

        [JsonProperty("nameTh")]
        public string NameTh { get; set; }

        [JsonProperty("firstNameEn")]
        public string FirstNameEn { get; set; }

        [JsonProperty("lastNameEn")]
        public string LastNameEn { get; set; }

        [JsonProperty("dateOfBirthTh")]
        public string DateOfBirthTh { get; set; }

        [JsonProperty("dateOfBirthEn")]
        public string DateOfBirthEn { get; set; }

        [JsonProperty("religionTh")]
        public string ReligionTh { get; set; }

        [JsonProperty("addressTh")]
        public string AddressTh { get; set; }

        [JsonProperty("dateOfIssueTh")]
        public string DateOfIssueTh { get; set; }

        [JsonProperty("dateOfIssueEn")]
        public string DateOfIssueEn { get; set; }

        [JsonProperty("dateOfExpiryTh")]
        public string DateOfExpiryTh { get; set; }

        [JsonProperty("dateOfExpiryEn")]
        public string DateOfExpiryEn { get; set; }

        [JsonProperty("serialNumber")]
        public string SerialNumber { get; set; }

        [JsonProperty("portrait")]
        public string Portrait { get; set; }

        [JsonProperty("confidence")]
        public Confidence Confidence { get; set; }

        [JsonProperty("referenceId")]
        public string ReferenceId { get; set; }

        [JsonProperty("createdDateTime")]
        public int? CreatedDateTime { get; set; }

        [JsonProperty("confirmedDateTime")]
        public int? ConfirmedDateTime { get; set; }
    }


    public class Back
    {
        [JsonProperty("serial")]
        public string Serial { get; set; }

        [JsonProperty("laser")]
        public string Laser { get; set; }

        [JsonProperty("confidence")]
        public Confidence Confidence { get; set; }

        [JsonProperty("referenceId")]
        public string ReferenceId { get; set; }

        [JsonProperty("createdDateTime")]
        public int? CreatedDateTime { get; set; }

        [JsonProperty("confirmedDateTime")]
        public int? ConfirmedDateTime { get; set; }
    }

    public class Card
    {
        [JsonProperty("front")]
        public Front Front { get; set; }

        [JsonProperty("back")]
        public Back Back { get; set; }
    }


    public class Summary
    {
        [JsonProperty("identity-verification")]
        public string IdentityVerification { get; set; }
    }

    public class Detail
    {
        [JsonProperty("document-alteration")]
        public string DocumentAlteration { get; set; }

        [JsonProperty("basic-watchlist")]
        public string BasicWatchlist { get; set; }

        [JsonProperty("facematch")]
        public string Facematch { get; set; }

        [JsonProperty("selfie")]
        public string Selfie { get; set; }

        [JsonProperty("biometric-check")]
        public string BiometricCheck { get; set; }
    }

    public class Data
    {
        [JsonProperty("summary")]
        public Summary Summary { get; set; }

        [JsonProperty("detail")]
        public Detail Detail { get; set; }
    }

    public class Flag
    {
        [JsonProperty("overall")]
        public string Overall { get; set; }

        [JsonProperty("data")]
        public Data Data { get; set; }
    }

    public class Answer
    {
        [JsonProperty("score")]
        public int? Score { get; set; }

        [JsonProperty("text")]
        public string Text { get; set; }
    }

    public class Suitability
    {

        [JsonProperty("answer1")]
        public Answer Answer1 { get; set; }

        [JsonProperty("answer2")]
        public Answer Answer2 { get; set; }

        [JsonProperty("answer3")]
        public Answer Answer3 { get; set; }

        [JsonProperty("answer4")]
        public Answer Answer4 { get; set; }

        [JsonProperty("answer5")]
        public Answer Answer5 { get; set; }

        [JsonProperty("answer6")]
        public Answer Answer6 { get; set; }

        [JsonProperty("answer7")]
        public Answer Answer7 { get; set; }

        [JsonProperty("answer8")]
        public Answer Answer8 { get; set; }

        [JsonProperty("answer9")]
        public Answer Answer9 { get; set; }

        [JsonProperty("answer10")]
        public Answer Answer10 { get; set; }

        [JsonProperty("answer11")]
        public Answer Answer11 { get; set; }

        [JsonProperty("answer12")]
        public Answer Answer12 { get; set; }

        [JsonProperty("answer13")]
        public Answer Answer13 { get; set; }

        [JsonProperty("answer14")]
        public Answer Answer14 { get; set; }

        [JsonProperty("riskLevel")]
        public string RiskLevel { get; set; }

        [JsonProperty("level")]
        public string Level { get; set; }

        [JsonProperty("score")]
        public int? Score { get; set; }

        [JsonProperty("nextTestDate")]
        public int? NextTestDate { get; set; }

        [JsonProperty("isConfirmed")]
        public bool? IsConfirmed { get; set; }
    }

    public class Passport
    {
        [JsonProperty("passport_type")]
        public string PassportType { get; set; }

        [JsonProperty("country_code")]
        public string CountryCode { get; set; }

        [JsonProperty("passport_number")]
        public string PassportNumber { get; set; }

        [JsonProperty("nationality")]
        public object Nationality { get; set; }

        [JsonProperty("surname")]
        public string Surname { get; set; }

        [JsonProperty("given_name")]
        public string GivenName { get; set; }

        [JsonProperty("sex")]
        public string Sex { get; set; }

        [JsonProperty("date_of_birth")]
        public string DateOfBirth { get; set; }

        [JsonProperty("date_of_expiry")]
        public string DateOfExpiry { get; set; }

        [JsonProperty("date_of_issue")]
        public object DateOfIssue { get; set; }

        [JsonProperty("place_of_birth")]
        public object PlaceOfBirth { get; set; }

        [JsonProperty("place_of_issue")]
        public object PlaceOfIssue { get; set; }

        [JsonProperty("issuing_authority")]
        public object IssuingAuthority { get; set; }

        [JsonProperty("confidence")]
        public Confidence Confidence { get; set; }

        /*[JsonProperty("_ref")]
        public string Ref { get; set; }

        [JsonProperty("_createdDateTime")]
        public DateTime CreatedDateTime { get; set; }

        [JsonProperty("_confirmedDateTime")]
        public DateTime ConfirmedDateTime { get; set; }*/
    }



}