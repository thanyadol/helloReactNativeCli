﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    /// <summary>
    /// ONE CIRCLE customer deposit / withdraw ticket
    /// </summary>
    /// 
    public class Transaction : Entity<string>
    {
        public Transaction()
        {
            ContainerName = "transactions";
            PartitionKey = "investorId";
        }


        /// <summary>
        /// Investor id from Investor entity for reconcile with QR code ref1 field
        /// </summary>
        /// 
        [JsonProperty("investorId")]
        public string InvestorId { get; set; }

        [JsonProperty("productCodeTarget")]
        public string ProductCodeTarget { get; set; }

        [JsonProperty("status")]
        public string Status { get; set; }

        [JsonProperty("type")]
        public string Type { get; set; }

        [JsonProperty("sourceAccount")]
        public BankAccount SourceAccount { get; set; }

        [JsonProperty("destinationAccount")]
        public BankAccount DestinationAccount { get; set; }

        [JsonProperty("sourceAccountRemarks")]
        public string SourceAccountRemarks { get; set; }

        [JsonProperty("destinationAccountRemarks")]
        public string DestinationAccountRemarks { get; set; }

        [JsonProperty("amount")]
        public decimal? Amount { get; set; }

        [JsonProperty("asset")]
        public decimal? Asset { get; set; }

        [JsonProperty("feeAmount")]
        public decimal? FeeAmount { get; set; }

        [JsonProperty("feeAsset")]
        public decimal? FeeAsset { get; set; }

        [JsonProperty("remarks")]
        public string Remarks { get; set; }

        [JsonProperty("isVerified")]
        public bool IsVerified { get; set; }

        [JsonProperty("isApproved")]
        public bool IsApproved { get; set; }

        [JsonProperty("requestDate")]
        public DateTime? RequestDate { get; set; }

        [JsonProperty("verifiedDate")]
        public DateTime? VerifiedDate { get; set; }

        [JsonProperty("approvedDate")]
        public DateTime? ApprovedDate { get; set; }

        [JsonProperty("transactionDate")]
        public DateTime TransactionDate { get; set; }

        [JsonProperty("scheduledTransactionDate")]
        public DateTime? ScheduledTransactionDate { get; set; }

        [JsonProperty("actualTransactionDate")]
        public DateTime? ActualTransactionDate { get; set; }

        [JsonProperty("transactionScheduledDateTime")]
        public DateTime? TransactionScheduledDateTime { get; set; }

        [JsonProperty("endingBalance")]
        public decimal? EndingBalance { get; set; }

        [JsonProperty("fee")]
        public decimal? Fee { get; set; }

        [JsonProperty("assetType")]
        public string AssetType { get; set; }

        [JsonProperty("imageId")]
        public string ImageId { get; set; }

        [JsonProperty("verifyStepId")]
        public string VerifyStepId { get; set; }

        [JsonProperty("steps")]
        public string Steps { get; set; }

        [JsonProperty("bankAccount")]
        public BankAccount BankAccount { get; set; }

        [JsonProperty("csvTransactionId")]
        public string CsvTransactionId { get; set; }

        [JsonProperty("reconciledDateTime")]
        public string ReconciledDateTime { get; set; }


        /// <summary>
        /// Ticket id for reconcile with QR code ref2 field
        /// </summary>

        [JsonProperty("ticketId")]
        public string TicketId { get; set; }

        [JsonProperty("alphaPointTicketId")]
        public string AlphaPointTicketId { get; set; }

        [JsonProperty("lastModifiedDate")]
        public DateTime? LastModifiedDate { get; set; }


    }
}
