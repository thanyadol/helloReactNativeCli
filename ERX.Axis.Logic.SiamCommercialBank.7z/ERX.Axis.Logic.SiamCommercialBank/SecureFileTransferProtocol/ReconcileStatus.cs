﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    /// <summary>
    ///   RECONCILED or CLEARED 
    /// </summary>
    public enum ReconcileStatus
    {
        /// <summary>
        /// 
        /// </summary>
        [Description("Reconciled")]
        RECONCILED,

        /// <summary>
        /// 
        /// </summary>
        [Description("None")]
        None,

        /// <summary>
        /// 
        /// </summary>
        [Description("Cleared")]
        CLEARED,

    }
}
