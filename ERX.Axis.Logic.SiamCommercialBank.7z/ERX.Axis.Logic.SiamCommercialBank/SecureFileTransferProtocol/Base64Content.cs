﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public class Base64Content
    {
        public string Name { get; set; }

        public string Path { get; set; }

        public Decimal Size { get; set; }

        public string Extension { get; set; }


        public string TransactionType { get; set; }

        public Nullable<DateTime> Date { get; set; }

        public byte[] Base64Value { get; set; }
    }
}
