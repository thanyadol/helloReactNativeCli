using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    /// <summary>
    /// 
    /// </summary>

    public enum SyncStatus
    {
        /// <summary>
        /// 
        /// </summary>
        [Description("RUNNING")]
        RUNNING,

        /// <summary>
        /// 
        /// </summary>
        [Description("FAILED")]
        FAILED,

        /// <summary>
        /// 
        /// </summary>
        [Description("SUCCEEDED")]
        SUCCEEDED,

    }
}