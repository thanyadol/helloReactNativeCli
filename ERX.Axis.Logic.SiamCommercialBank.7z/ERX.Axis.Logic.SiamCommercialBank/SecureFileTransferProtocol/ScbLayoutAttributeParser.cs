using ERX.Axis.Logic.SiamCommercialBank;
using System;
using System.Reflection;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public class ScbLayoutAttributeParser<T>
    {
        public T Parse(string line)
        {
            var entity = (T)Activator.CreateInstance(typeof(T));
            var properties = typeof(T).GetProperties();
            //for all properties
            foreach (var propertyInfo in properties)
            {
                var attribute = (ScbLayoutAttribute)propertyInfo.GetCustomAttribute(typeof(ScbLayoutAttribute));

                if (attribute == null) continue;
                var strValue = line.SubStringShorter(attribute.Begin, attribute.Length).Trim();

                //switch type and cast a decimal / int value
                System.TypeCode propertyType = Type.GetTypeCode(propertyInfo.PropertyType);
                switch (propertyType)
                {
                    case TypeCode.Int16:
                    case TypeCode.Int32:
                        var intValue = Convert.ToInt32(strValue);
                        propertyInfo.SetValue(entity, intValue);
                        break;
                    case TypeCode.Decimal:
                        var decimalValue = Convert.ToDecimal(strValue);
                        propertyInfo.SetValue(entity, decimalValue);
                        break;
                    default:
                        propertyInfo.SetValue(entity, strValue);
                        break;
                }
            }

            return entity;
        }

    }
}