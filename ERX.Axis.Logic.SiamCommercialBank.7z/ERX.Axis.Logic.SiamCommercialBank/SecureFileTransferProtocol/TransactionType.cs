﻿using System;
using System.ComponentModel;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public enum TransactionType
    {
        /// <summary>
        /// 
        /// </summary>
        [Description("Intraday Bill Payment")]
        INTRADAYBILLPAYMENT,

        /// <summary>
        /// 
        /// </summary>
        [Description("Historical Bill Payment")]
        HISTORICALBILLPAYMENT,

        /// <summary>
        /// 
        /// </summary>
        [Description("Historical Statement")]
        HISTORICALSTATEMENT,


        /// <summary>
        /// 
        /// </summary>
        [Description("Domestic Payment")]
        DOMESTICPAYMENT,

        /// <summary>
        /// 
        /// </summary>
        [Description("Domestic Return")]
        DOMESTICRETURN,
    }


    /// <summary>
    /// 
    /// </summary>
    public enum TicketType
    {
        /// <summary>
        /// 
        /// </summary>
        [Description("Deposit")]
        DEPOSIT,

        /// <summary>
        /// 
        /// </summary>
        [Description("Withdraw")]
        WITHDRAW,

    }
}