using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public interface ICrossBankPaymentService
    {
        Task<CrossBankBillPaymentDetail> GetAsync(string id);
        Task<CrossBankBillPayment> CreateAsync(CrossBankBillPayment crossBankBillPayment);
        bool TryParseAsync(string[] lines, out CrossBankBillPayment crossBankBillPayment);

        Task<IEnumerable<CrossBankBillPaymentDetail>> ListAsync(CrossBankBillPaymentParams param);
    }

    internal class CrossBankPaymentService : ICrossBankPaymentService
    {
        private readonly IRepository<string, CrossBankBillPaymentDetail> _detailRepository;
        public CrossBankPaymentService(IRepository<string, CrossBankBillPaymentDetail> detailRepository)
        {
            _detailRepository = detailRepository ?? throw new ArgumentNullException(nameof(detailRepository));
        }


        public async Task<CrossBankBillPayment> CreateAsync(CrossBankBillPayment crossBankBillPayment)
        {

            //--for tracking
            crossBankBillPayment.Header.AttachmentId = crossBankBillPayment.AttachmentId;
            crossBankBillPayment.Header.AttachmentName = crossBankBillPayment.AttachmentName;
            crossBankBillPayment.Header.TransactionType = crossBankBillPayment.TransactionType;

            //await _headerRepository.CreateAsync(payment.Header);

            var entities = crossBankBillPayment.Details
               .Select(c =>
               {
                   //generate unique id
                   c.Id = Math.Abs((crossBankBillPayment.Header.TransactionType + c.PaymentDate + c.PaymentTime + c.CustomerNoRef1 + c.CustomerNoRef2 + c.Amount).GetHashCode()).ToString(); //TODO: get hash code
                   c.Created = DateTime.UtcNow;

                   c.Header = crossBankBillPayment.Header;
                   c.Total = crossBankBillPayment.Total;

                   return c;
               }).ToList();


            var created =  await _detailRepository.BulkCreateAsync(entities);
            crossBankBillPayment.Details = created.ToList();

            return crossBankBillPayment;
        }

        public async Task<CrossBankBillPaymentDetail> GetAsync(string id)
        {
            return await _detailRepository.GetByIdAsync(id).ConfigureAwait(false);
        }


        /// <summary>
        /// return a list of cross bank bill payment transction
        /// </summary>
        public async Task<IEnumerable<CrossBankBillPaymentDetail>> ListAsync(CrossBankBillPaymentParams param)
        {
            var entity = await _detailRepository.ListAsync().ConfigureAwait(false);

            //time
            Int32 start = (Int32)(param.StartDate.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
            Int32 end = (Int32)(param.EndDate.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;


            entity = entity.Where(c => c.PaymentUnixTimeStamp >= start && c.PaymentUnixTimeStamp <= end);


            //company account
            if (!string.IsNullOrEmpty(param.CompanyAccount))
            {
                entity = entity.Where(c => c.CompanyAccount == param.CompanyAccount);
            }

            //transaction type
            if (!string.IsNullOrEmpty(param.TransactionCode))
            {
                entity = entity.Where(c => c.TransactionCode == param.TransactionCode);
            }


            //amount
            if (param.MinAmount != null)
            {
                entity = entity.Where(c => c.Amount >= param.MinAmount);
            }

            //amount
            if (param.MaxAmount != null)
            {
                entity = entity.Where(c => c.Amount <= param.MaxAmount);
            }

            //company account type
            if (!string.IsNullOrEmpty(param.CompanyAccount))
            {
                entity = entity.Where(c => c.CompanyAccount == param.CompanyAccount);
            }


            if (!string.IsNullOrEmpty(param.Ref1))
            {
                entity = entity.Where(c => c.CustomerNoRef1 == param.Ref1);
            }


            if (!string.IsNullOrEmpty(param.Ref2))
            {
                entity = entity.Where(c => c.CustomerNoRef2 == param.Ref2);
            }


            return entity.ToList();
        }



        public bool TryParseAsync(string[] lines, out CrossBankBillPayment crossBankBillPayment)
        {
            var entity = new CrossBankBillPayment();

            crossBankBillPayment = entity;

            try
            {

                var headerParser = new ScbLayoutAttributeParser<CrossBankBillPaymentHeader>();
                var header = lines.FirstOrDefault();
                entity.Header = headerParser.Parse(header);

                var totalParser = new ScbLayoutAttributeParser<CrossBankBillPaymentTotal>();
                var total = lines.LastOrDefault();
                entity.Total = totalParser.Parse(total);

                var detailParser = new ScbLayoutAttributeParser<CrossBankBillPaymentDetail>();
                var details = lines.Skip(1).Take(lines.Length - 2);


                foreach (string line in details)
                {
                    if (line.FirstOrDefault() == 'D')
                    {
                        var detail = detailParser.Parse(line);

                        //correct amount as double point precision
                        detail.Amount = detail.Amount / 100;

                        //unix timestamp for query
                        DateTime transactionDate = DateTime.ParseExact(detail.PaymentDate + detail.PaymentTime, "ddMMyyyyHHmmss", System.Globalization.CultureInfo.InvariantCulture);
                        Int32 unixTimestamp = (Int32)(transactionDate.Subtract(new DateTime(1970, 1, 1)).TotalSeconds);

                        detail.PaymentUnixTimeStamp = unixTimestamp;

                        entity.Details.Add(detail);
                    }
                }

                //re-assign
                crossBankBillPayment = entity;
                return true;

            } catch { return false; }

        }



    }

}