﻿using System;
using System.IO;
using System.Text;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using BANK = ERX.Axis.Logic.SiamCommercialBank.Bank;
using Microsoft.Extensions.Options;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public interface IDomesticPaymentService
    {
        Task<IEnumerable<DomesticPayment>> ParseAsync(IEnumerable<Transaction> transactions, IEnumerable<Investor> investors, string batchReferenceId);
        Task<DomesticPayment> CreateAsync(DomesticPayment domesticPayment);
    }

    public class DomesticPaymentService : IDomesticPaymentService
    {
        private readonly IRepository<Guid, DomesticPayment> _domesticPaymentRepository;
        private readonly DomesticPaymentConfiguration _domesticPaymentConfiguration;


        public DomesticPaymentService(IRepository<Guid, DomesticPayment> domesticPaymentRepository, IOptions<DomesticPaymentConfiguration> configuration)
        {
            _domesticPaymentRepository = domesticPaymentRepository;
            _domesticPaymentConfiguration = configuration.Value;
        }

        public async  Task<DomesticPayment> CreateAsync(DomesticPayment domesticPayment)
        {
            var entity = await _domesticPaymentRepository.CreateAsync(domesticPayment);
            return entity;
        }

        public async Task<IEnumerable<DomesticPayment>> ParseAsync(IEnumerable<Transaction> transactions, IEnumerable<Investor> investors, string batchReferenceId)
        {
            string erxCurrentAccount = _domesticPaymentConfiguration.CurrentAccountNumber;
            string erxSavingAccount = _domesticPaymentConfiguration.SavingAccountNumber;

            const string SCB_BANK_CODE = "014";
            const string SCB_RATCHAYOTHIN_BRANCH_CODE = "0111";

            const string SCB_REFERENCE_TRANSFER_TYPE_OTHER_MCL = "59";
            const string SCB_REFERENCE_OBJECT_TYPE_OTHER_BNT = "00";
            const string SCB_REFERENCE_DEBIT_TYPE_BNT = "DCA";

            // TODO : should move to appsettings //default at debit cuurent A/C
            string debitAccountNumber = erxCurrentAccount;
            string debitInternalReferencePrefix = _domesticPaymentConfiguration.DebitInternalReferencePrefix;
            string feeDebitAccountNumber = _domesticPaymentConfiguration.FeeDebitAccountNumber;
            string companyCode = _domesticPaymentConfiguration.CompanyCode;

            int debitSequence = 1;
            int creditSequence = 1;

            var debitDetails = new List<DomesticPaymentDebitDetail>();
            var creditDetails = new List<DomesticPaymentCreditDetail>();
            var payeeDetails = new List<DomesticPaymentPayeeDetail>();

            foreach (var t in transactions)
            {
                var words = t.BankAccount.Branch.Split(':');
                string branchCode = words[0];
                string branchName = words[1];

                var cc = new DomesticPaymentCreditDetail
                { 
                    CustomerReferenceNumber = t.TicketId,
                    //RecordType = RecordType.CREDIT_DETAIL.GetDescription(),

                    //for reference
                    OneCircleReferenceTicketId = t.TicketId,

                    //6 digits
                    CreditSequenceNumber = creditSequence.ToString(),
                    CreditAccount = t.BankAccount.AccountNumber,

                    CreditAmount = (t.Amount * 1000)?.ToString("############"),

                    DecimalCreditAmount = t.Amount.GetValueOrDefault(),

                    // InternalReferenceToDebitDetail = debitDetail.DebitInternalReference,
                    CreditCurrencyCode = "THB",

                    WHTPresent = "N",
                    InvoiceDetailsPresent = "N",
                    CreditAdviceRequired = "Y",

                    ReceivingBankName = t.BankAccount.BankName,
                    ReceivingBranchName = branchName,

                    BeneficiaryNotification = "E",

                    //BeneficiaryCharge = "  ",
                };

                //some logic
                cc.DocumentDeliveryMode = t.ProductCodeTarget == ProductCode.MCP.ToString() || cc.CreditAdviceRequired == "Y" ? "S" : null;

                //other(59) for BNT 
                cc.PaymentTypeCode = t.ProductCodeTarget == ProductCode.BNT.ToString() ? SCB_REFERENCE_DEBIT_TYPE_BNT : null;

                cc.ServicesType = t.ProductCodeTarget == ProductCode.BNT.ToString() ? SCB_REFERENCE_OBJECT_TYPE_OTHER_BNT : SCB_REFERENCE_TRANSFER_TYPE_OTHER_MCL;


                //* "MCP", "CCP", "DDP", "XMQ", "XDQ","PAY","PA2","PA3" , "DCP" have to be = "014"
                if(t.ProductCodeTarget == ProductCode.MCP.ToString() || t.ProductCodeTarget == ProductCode.DCP.ToString())
                {
                    cc.ReceivingBankCode = SCB_BANK_CODE;
                } 
                else if (t.ProductCodeTarget ==  ProductCode.BNT.ToString() || t.ProductCodeTarget == ProductCode.MCL.ToString())
                {
                    var mappingBankCode = BANK.THAILAND_BANK_CODE.Single(p => p.Value == t.BankAccount.BankName).Key.ToString();
                    cc.ReceivingBankCode = mappingBankCode;
                }
                else
                {
                    cc.ReceivingBankCode = null;
                }

                //*Mandatory For MCL, BNT, MCP, CCP, DDP , PA4 , PA5 , PA6 * MCP/DDP Default : "0111" (รัชโยธิน)
                if (t.ProductCodeTarget == ProductCode.MCP.ToString())
                {
                    cc.ReceivingBranchCode = SCB_RATCHAYOTHIN_BRANCH_CODE;
                }
                else if(t.ProductCodeTarget == ProductCode.BNT.ToString() || t.ProductCodeTarget == ProductCode.MCL.ToString())
                {
                    cc.ReceivingBranchCode = branchCode;
                }
                else { cc.ReceivingBranchCode = null; }


                debitAccountNumber = erxCurrentAccount;
                //Logic to select erx bank account
                /*if (t.Amount > 50000)
                {
                    debitAccountNumber = erxSavingAccount;
                }
                else
                {
                    debitAccountNumber = erxCurrentAccount;
                }*/

                var dd = debitDetails.Where(c => c.DebitAccountNumber == debitAccountNumber
                            && c.ProductCode == t.ProductCodeTarget)
                            .FirstOrDefault();

                //logic to decision add debit row
                //check productype and debit account number
                if (t.ProductCodeTarget == ProductCode.BNT.ToString() 
                    || dd == null)
                {

                    dd = new DomesticPaymentDebitDetail
                    {
                        ProductCode = t.ProductCodeTarget,
                        //ValueDate = DateTime.Now.AddDays(1).ToString("yyyyMMdd"),  //next day

                        DebitAccountType = "0" + debitAccountNumber[3],
                        DebitAccountNumber = debitAccountNumber,
                        DebitBranchCode = "0" + debitAccountNumber.Substring(0, 3),

                        FeeDebitAccount = feeDebitAccountNumber,
                        FeeDebitAccountType = "0" + feeDebitAccountNumber[3],
                        FeeDebitBranchCode = "0" + feeDebitAccountNumber.Substring(0, 3),
                    };

                    //value date logic
                    //Bnt ห้ามเป็นวันหยุด 
                    //dcpได้ปกติ 
                    //mcl ต้อง + 2ไม่นับวันหยุดนะคร้บ
                    var additionalValueDate = t.ProductCodeTarget == ProductCode.MCL.ToString() ? 2 : 1;
                    dd.ValueDate = DateTime.Now.AddBusinessDays(additionalValueDate).ToString("yyyyMMdd");

                    //WC + YYYYMMDD + 6 digits Sequence
                    var debitInternalReference = debitInternalReferencePrefix + debitSequence.ToString("D6");

                    dd.DebitInternalReference = debitInternalReference;
                    debitSequence++;

                    debitDetails.Add(dd);
                }

                //set reference
                cc.InternalReferenceToDebitDetail = dd.DebitInternalReference;

                creditDetails.Add(cc);

                var p = new DomesticPaymentPayeeDetail()
                {
                    InternalReferenceToDebitRecord = dd.DebitInternalReference,
                    ReferenceCreditSequenceNumber = cc.CreditSequenceNumber,
                };

                var inv = investors.Where(c => c.Id == t.InvestorId).FirstOrDefault();
                if (inv != null)
                {
                    //for reference
                    p.OneCircleReferenceInvestorId = inv.Id;

                    p.Payee1NameEnglish = inv.GivenName;
                    p.Payee1NameInThai = inv.GivenName;

                    p.Payee1EmailAddress = inv.EmailAddresses.FirstOrDefault().Address;

                    //require if BNT
                    if (t.ProductCodeTarget == ProductCode.BNT.ToString())
                    {
                        p.Payee1Address1 = $"{inv.HomeAddress.Housename} {inv.HomeAddress.Subregion} {inv.HomeAddress.Region} {inv.HomeAddress.PostalCode}";
                    }
                }

                payeeDetails.Add(p);

                creditSequence++;
            }

            /// transform
            /// grouping
            /// summary
            var entities = new List<DomesticPayment>();

            foreach (var debit in debitDetails)
            {
                var entity = new DomesticPayment()
                {
                    Id = Guid.NewGuid(),

                    DebitDetails = new List<DomesticPaymentDebitDetail>() { debit },
                    CreditDetails = creditDetails.Where(c => c.InternalReferenceToDebitDetail == debit.DebitInternalReference).OrderBy(c => c.CreditSequenceNumber),

                    PayeeDetails = payeeDetails.Where(c => c.InternalReferenceToDebitRecord == debit.DebitInternalReference)
                };

                //header 
                var header = new DomesticPaymentHeader()
                {
                    CompanyId = companyCode,
                    MessageDate = DateTime.Now.ToString("yyyyMMdd"),
                    MessageTime = DateTime.Now.ToString("HHmmss"),

                    CustomerReference = "helloworld",   //can be whatever text

                    BatchReference = batchReferenceId.ToString()
                };
                entity.Header = header;

                //calculate
                var totalCreditRecordDisplay = entity.CreditDetails.Count().ToString();
                var totalAmountDisplay = entity.CreditDetails.Sum(c => c.DecimalCreditAmount * 1000).ToString("############");

                debit.DebitAmount = totalAmountDisplay;
                debit.TotalCreditRecord = totalCreditRecordDisplay;

                var trailer = new DomesticPaymentTrailer()
                {

                    TotalDebitsRecord = "1",
                    TotalCreditsRecord = totalCreditRecordDisplay,

                    TotalAmount = totalAmountDisplay,
                };

                entity.Trailer = trailer;

                entities.Add(entity);
            }

            return await Task.FromResult(entities);
        }

    }
}