﻿using ERX.Axis.Logic.SiamCommercialBank.Gateway;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public interface IExchangeService
    {

        /// <summary>
        /// List investor by list of ids
        /// </summary>
        /// 
        [Description("List investor by list of ids")]
        Task<IEnumerable<Investor>> ListInvestorAsync(string[] ids);

        /// <summary>
        /// reconcile qr code payment with oc transaction and scb confirm payment by transaction date
        /// </summary>
        [Description("econcile qr code payment with oc transaction and scb confirm payment by transaction date")]
        Task<IEnumerable<QRCodePaymentReconcile>> ListReconcilePaymentAsync(DateTime startDate, DateTime endDate);


        /// <summary>
        /// List peiding approved deposit ticket by date
        /// </summary>
        /// 
        [Description("List some status deposit ticket by date")]
        Task<IEnumerable<Transaction>> ListDepositTransactionAsync(DateTime startDate, DateTime endDate);


        /// <summary>
        /// List pending approved deposit ticket by date
        /// </summary>
        /// 
        [Description("List some status withdraw ticket by date")]
        Task<IEnumerable<Transaction>> ListWithdrawTransactionAsync(DateTime startDate, DateTime endDate);

        Task<IEnumerable<QRCodePaymentRequest>> ListQRCode(string[] tickets);
        Task<IEnumerable<PaymentConfirmationRequest>> ListConfirmPaymentAsync(string[] tickets);
    }

    public class ExchangeService : IExchangeService
    {
        private readonly IRepository<Guid, QRCodePaymentRequest> _qrCodeRequestRepository;
        private readonly IRepository<string, Transaction> _transactionRepository;
        private readonly IRepository<string, Investor> _investorRepository;

        private readonly IRepository<string, PaymentConfirmationRequestGateway> _confirmPaymentRepository;

        public const string TRANSACTION_STATUS_PENDDING_APPROVAL = "PendingApproval";

        public ExchangeService(IRepository<Guid, QRCodePaymentRequest> qrCodeRequestRepository, IRepository<string, Transaction> transactionRepository, IRepository<string,
                                                    PaymentConfirmationRequestGateway> confirmPaymentRepository, IRepository<string, Investor> investorRepository)
        {
            _qrCodeRequestRepository = qrCodeRequestRepository;
            _transactionRepository = transactionRepository;
            _investorRepository = investorRepository;
            _confirmPaymentRepository = confirmPaymentRepository;

        }

        /// <summary>
        /// List investor by list of ids
        /// </summary>
        /// 
        [Description("List investor by list of ids")]
        public async Task<IEnumerable<Investor>> ListInvestorAsync(string[] ids)
        {
            var entity = await _investorRepository.ListAsync().ConfigureAwait(false);

            //where
            entity = entity.Where(c => ids.Contains(c.Id));

            if (entity == null)
            {
                throw new EntityNotFoundException();
            }

            return entity;
        }

        /// <summary>
        /// List peiding approved deposit ticket by date
        /// </summary>
        /// 
        [Description("List some status deposit ticket by date")]
        public async Task<IEnumerable<Transaction>> ListDepositTransactionAsync(DateTime startDate, DateTime endDate)
        {
            var entity = await _transactionRepository.ListAsync().ConfigureAwait(false);

            //where
            entity = entity.Where(c => c.Type == TicketType.DEPOSIT.GetDescription()
                            && c.Status == TRANSACTION_STATUS_PENDDING_APPROVAL 
                            //&& (c.TransactionDate.Date >= startDate.Date && c.TransactionDate.Date <= endDate.Date)
                            );

            if (entity == null)
            {
                throw new EntityNotFoundException();
            }

            return entity;
        }

        /// <summary>
        /// List pending approved deposit ticket by date
        /// </summary>
        /// 
        [Description("List some status withdraw ticket by date")]
        public async Task<IEnumerable<Transaction>> ListWithdrawTransactionAsync(DateTime startDate, DateTime endDate)
        {
            var entity = await _transactionRepository.ListAsync().ConfigureAwait(false);

            //where
            entity = entity.Where(c => c.Type == TicketType.WITHDRAW.GetDescription()
                            && c.Status == TRANSACTION_STATUS_PENDDING_APPROVAL
                          //  && (c.TransactionDate.Date >= startDate.Date && c.TransactionDate.Date <= endDate.Date)
                          );

            if (entity == null)
            {
                throw new EntityNotFoundException();
            }

            return entity;
        }

        /// <summary>
        /// List QRCode request for payment by ticketId mapping ref2
        /// </summary>
        /// 
        [Description("List QRCode request for payment by ticketId mapping ref2")]
        public async Task<IEnumerable<QRCodePaymentRequest>> ListQRCode(string[] tickets)
        {
            var entity = await _qrCodeRequestRepository.ListAsync().ConfigureAwait(false);

            //mappping --remove "-"
            // tickets = tickets.Select(x => x.Replace("_", "")).ToArray();

            //where
            entity = entity.Where(c => tickets.Contains(c.Ref2));

            if (entity == null)
            {
                throw new EntityNotFoundException();
            }

            return entity;
        }


        /// <summary>
        /// List QRCode request for payment by ticketId mapping ref2
        /// </summary>
        /// 
        [Description("List confirm payment by ticketId mapping ref2")]
        public async Task<IEnumerable<PaymentConfirmationRequest>> ListConfirmPaymentAsync(string[] tickets)
        {
            var entities = await _confirmPaymentRepository.ListAsync().ConfigureAwait(false);

            //select entity
            var entity = entities.ToList().Select(c => c.Entity);

            //where
            entity = entity.Where(c => tickets.Contains(c.BillPaymentRef2));

            if (entity == null)
            {
                throw new EntityNotFoundException();
            }

            return entity;
        }

        /// <summary>
        /// reconcile qr code payment with oc transaction and scb confirm payment by transaction date
        /// </summary>
        [Description("econcile qr code payment with oc transaction and scb confirm payment by transaction date")]
        public async Task<IEnumerable<QRCodePaymentReconcile>> ListReconcilePaymentAsync(DateTime startDate, DateTime endDate)
        {
            var entities = new List<QRCodePaymentReconcile>();

            //list the deposit ticket by qr ref2  --repplace string "_" with ""
            var depositTickets = await this.ListDepositTransactionAsync(startDate, endDate).ConfigureAwait(false);

            //depositTickets = depositTickets.ToList();
            depositTickets = depositTickets.Where(c => c.TransactionDate.Date >= startDate.Date && c.TransactionDate.Date <= endDate.Date);

            //replace "-" for ref2
            depositTickets = depositTickets.Select(c =>
                { c.TicketId = c.TicketId.Replace("-", "", StringComparison.OrdinalIgnoreCase); return c; }
            );
            //to arrays
            var ids = depositTickets.Select(c => c.TicketId).ToArray();

            //list qr 
            var qrCodes = await this.ListQRCode(ids).ConfigureAwait(false);

            //list confirm payment
            var confirmPayments = await this.ListConfirmPaymentAsync(ids).ConfigureAwait(false);

            //Logic to compare   -- mapping => ref1 / ref2/ ref3 / amount / bank account name / bank account number
            foreach (var t in depositTickets)
            {
                var entity = new QRCodePaymentReconcile()
                {
                    Id = Guid.NewGuid(),
                    Ticket = t,
                    ReconcileDate = DateTime.Now,

                    Status = ReconcileStatus.None.ToString()
                };

                //add by reference
                entities.Add(entity);

                //find qr code
                var qrCode = qrCodes.Where(c => c.Ref2 == t.TicketId).FirstOrDefault();
                if (qrCode != null)
                {
                    entity.QRCode = qrCode;
                }
                else
                {
                    entity.Description = "QRCode not found";
                    continue;
                }

                //find confirm payment
                var confirmPayment = confirmPayments.Where(c => c.BillPaymentRef2 == t.TicketId).FirstOrDefault();
                if (confirmPayment != null)
                {
                    entity.ConfirmPayment = confirmPayment;
                    entity.Status = ReconcileStatus.CLEARED.ToString();
                }
                else
                {
                    entity.Description = "Confirm payment not found";
                    continue;
                }

                //compared
                if (entity.QRCode.Ref1 != entity.ConfirmPayment.BillPaymentRef1)
                {
                    entity.Description = "Reference1 is not valid";
                    continue;
                }

                if (entity.QRCode.Ref2 != entity.ConfirmPayment.BillPaymentRef2)
                {
                    entity.Description = "Reference2 is not valid";
                    continue;
                }

                if (entity.QRCode.Ref3 != entity.ConfirmPayment.BillPaymentRef3)
                {
                    entity.Description = "Reference3 is not valid";
                    continue;
                }


                if (entity.Ticket.Amount != Convert.ToDecimal(entity.ConfirmPayment.Amount, CultureInfo.InvariantCulture))
                {
                    entity.Description = "Amount is not valid";
                    continue;
                }


                if (entity.Ticket.BankAccount.AccountName != entity.ConfirmPayment.PayerAccountName)
                {
                    entity.Description = "Payer bank account name is not valid";
                    continue;
                }

                if (entity.Ticket.BankAccount.AccountNumber != entity.ConfirmPayment.PayerAccountNumber)
                {
                    entity.Description = "Payer bank account number is not valid";
                    continue;
                }

                //set status to clear
                entity.Status = ReconcileStatus.RECONCILED.ToString();

            }

            return entities;
        }

    }
}
