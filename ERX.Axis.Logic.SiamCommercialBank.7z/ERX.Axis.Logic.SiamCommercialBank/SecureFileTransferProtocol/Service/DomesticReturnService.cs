﻿using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public interface IDomesticReturnService
    {
        Task<PaymentReturn> CreateAsync(PaymentReturn paymentReturn);
        bool TryParseAsync(string[] lines, out PaymentReturn paymentReturn);
    }

    internal class DomesticReturnService : IDomesticReturnService
    {
        private readonly IRepository<Guid, PaymentReturnResult> _resultRepository;

        public DomesticReturnService(IRepository<Guid, PaymentReturnResult> resultRepository)
        {
            _resultRepository = resultRepository ?? throw new ArgumentNullException(nameof(resultRepository));
        }

        public async Task<PaymentReturn> CreateAsync(PaymentReturn paymentReturn)
        {
            //move value for tracking
            paymentReturn.Header.AttachmentId = paymentReturn.AttachmentId;
            paymentReturn.Header.AttachmentName = paymentReturn.AttachmentName;
            paymentReturn.Header.TransactionType = paymentReturn.TransactionType;

            //await _headerRepository.CreateAsync(payment.Header);

            var entities = paymentReturn.ResultRecords
               .Select(c =>
               {
                   //generate unique id
                   c.Id = Guid.NewGuid();
                   c.Created = DateTime.UtcNow;

                   c.Header = paymentReturn.Header;
                   c.Trailer = paymentReturn.Trailer;

                   return c;
               }).ToList();


            var created = await _resultRepository.BulkCreateAsync(entities);
            paymentReturn.ResultRecords = created.ToList();
            return paymentReturn;
        }

        public bool TryParseAsync(string[] lines, out PaymentReturn paymentReturn)
        {
            var entity = new PaymentReturn();

            paymentReturn = entity;

            try
            {
                var headerParser = new ScbLayoutAttributeParser<PaymentReturnHeader>();
                var header = lines.FirstOrDefault();
                entity.Header = headerParser.Parse(header);

                var trailerParser = new ScbLayoutAttributeParser<PaymentReturnTrailer>();
                var total = lines.LastOrDefault();
                entity.Trailer = trailerParser.Parse(total);

                var resultParser = new ScbLayoutAttributeParser<PaymentReturnResult>();
                var results = lines.Skip(1).Take(lines.Length - 2);

                foreach (string line in results)
                {
                    if (line.Substring(0, 3) == "510")
                    {
                        var result = resultParser.Parse(line);

                        //correct amount as double point precision
                        //detail.NetPaymentAmount = detail.NetPaymentAmount / 100;
                        //detail.PaymentAmount = detail.PaymentAmount / 100;

                        //unix timestamp for query
                        DateTime paymentDate = DateTime.ParseExact(entity.Header.CreationDate + entity.Header.CreationTime, 
                                                        "ddMMyyyyHHmmss", System.Globalization.CultureInfo.InvariantCulture);
                       
                        Int32 unixTimestamp = (Int32)(paymentDate.Subtract(new DateTime(1970, 1, 1)).TotalSeconds);
                        result.PaymentUnixTimeStamp = unixTimestamp;

                        entity.ResultRecords.Add(result);
                    }
                }

                //re-assign
                paymentReturn = entity;
                return true;

            } catch {return false; }

        }



    }

}
