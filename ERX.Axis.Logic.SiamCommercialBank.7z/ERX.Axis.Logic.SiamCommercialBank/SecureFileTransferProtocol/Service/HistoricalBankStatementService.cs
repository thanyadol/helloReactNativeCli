using System;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public interface IHistoricalBankStatementService
    {
        bool TryParseAsync(string[] lines, out IEnumerable<HistoricalBankStatement> historicalBankStatement);
        Task<IEnumerable<HistoricalBankStatement>> CreateRangeAsync(IEnumerable<HistoricalBankStatement> statements);

        Task<IEnumerable<HistoricalBankStatement>> ListAsync();
    }

    public class HistoricalBankStatementService : IHistoricalBankStatementService
    {
        //payment status
        private readonly IRepository<string, HistoricalBankStatement> _historicalBankStatementRepository;

        public HistoricalBankStatementService(IRepository<string, HistoricalBankStatement> historicalBankStatementRepository)
        {
            _historicalBankStatementRepository = historicalBankStatementRepository ?? throw new ArgumentNullException(nameof(historicalBankStatementRepository));
        }

        public async Task<IEnumerable<HistoricalBankStatement>> ListAsync()
        {
            var query = "SELECT * FROM s WHERE s.object = 'HistoricalBankStatement'";
            return await _historicalBankStatementRepository.ListAsync(query);
        }


        public async Task<IEnumerable<HistoricalBankStatement>> CreateRangeAsync(IEnumerable<HistoricalBankStatement> statements)
        {
            statements = statements
                  .Select(c =>
                  {
                      //generate unique id
                      c.Id = Math.Abs((c.Account + c.Date + c.Time + c.TransCode + c.TransAmt).GetHashCode()).ToString();
                      c.Created = DateTime.Now;
                      //c.Object = "HistoricalBankStatement";
                      return c;
                  }).ToList();

            return await _historicalBankStatementRepository.BulkCreateAsync(statements);
        }

        public bool TryParseAsync(string[] lines, out IEnumerable<HistoricalBankStatement> historicalBankStatement)
        {
            var _scbStatementAttributeParser = new ScbLayoutAttributeParser<HistoricalBankStatement>();
            var entities = new List<HistoricalBankStatement>();

            historicalBankStatement = entities;

            try
            {
                foreach (string line in lines)
                {
                    var statement = _scbStatementAttributeParser.Parse(line);

                    //correct amount as double point precision
                    statement.TransAmt = statement.TransAmt / 100;
                    statement.TransBal = statement.TransBal / 100;

                    //unix timestamp for query
                    DateTime transactionDate = DateTime.ParseExact(statement.Date + statement.Time, "dd/MM/yyyyHH:mm", System.Globalization.CultureInfo.InvariantCulture);
                    Int32 unixTimestamp = (Int32)(transactionDate.Subtract(new DateTime(1970, 1, 1)).TotalSeconds);

                    statement.TransactionUnixTimeStamp = unixTimestamp;

                    entities.Add(statement);
                }

                historicalBankStatement = entities;
                return true;
            }  catch { return false; }
        }



    }

}