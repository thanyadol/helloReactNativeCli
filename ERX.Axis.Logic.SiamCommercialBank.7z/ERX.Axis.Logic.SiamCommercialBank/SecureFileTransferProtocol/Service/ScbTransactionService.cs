﻿
using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Polly;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public interface IScbTransactionService
    {
        Task<IEnumerable<Attachment>> SyncPaymentAsync(TransactionType type, string path);
        Task<IEnumerable<Attachment>> SyncStatementAsync(TransactionType type, string path);

        Task<IEnumerable<Attachment>> SyncDomesticPaymentAsync(string path);

        Task<IEnumerable<Attachment>> SyncDomesticReturnAsync(string path);

    }

    public class ScbTransactionService : IScbTransactionService
    {
        private readonly IHttpService<Attachment, Attachment> _httpHashService;

        private readonly IRepository<Guid, Attachment> _attachmentRepository;

        private readonly IBase64CryptoService _base64CryptoService;
        private readonly ISftpClientService _sftpClientService;
        private readonly IAzureBlobStorageService _azureBlobStorageService;

        private readonly ICrossBankPaymentService _crossBankPaymentService;
        private readonly IHistoricalBankStatementService _historyStatementService;

        private readonly IExchangeService _exchangeService;

        private readonly IDomesticPaymentService _domesticPaymentService;
        private readonly IDomesticReturnService _domesticReturnService;

        private readonly DomesticPaymentConfiguration _domesticPaymentConfiguration;

        private readonly ILogger<ScbTransactionService> _logger;

        public ScbTransactionService(IRepository<Guid, Attachment> attachmentRepository, IBase64CryptoService base64CryptoService,  ISftpClientService sftpClientService, 
                                            IAzureBlobStorageService azureBlobStorageService, ICrossBankPaymentService crossBankPaymentService, IHistoricalBankStatementService historyStatementService,
                                            IExchangeService exchangeService, IDomesticPaymentService domesticPaymentService, IDomesticReturnService domesticReturnService,
                                            IHttpService<Attachment, Attachment> httpHashService, IOptions<DomesticPaymentConfiguration> domesticPaymentConfiguration, ILogger<ScbTransactionService> logger)
        {
            _attachmentRepository = attachmentRepository ?? throw new ArgumentNullException(nameof(attachmentRepository));
            _base64CryptoService = base64CryptoService;
            _sftpClientService = sftpClientService;
            _azureBlobStorageService = azureBlobStorageService;

            _crossBankPaymentService = crossBankPaymentService;
            _historyStatementService = historyStatementService;
            _exchangeService = exchangeService;
            _domesticPaymentService = domesticPaymentService;

            _domesticReturnService = domesticReturnService;
            _httpHashService = httpHashService;

            _domesticPaymentConfiguration = domesticPaymentConfiguration.Value;

            _logger = logger;

        }

        private async Task<byte[]> EncryptAsync(byte[] value)
        {
            string scb_key = _domesticPaymentConfiguration.ScbEncryptPublicKey;
            var base64EncyptedValue = await _base64CryptoService.GpgEncryptAsync(value, scb_key).ConfigureAwait(false);

            return base64EncyptedValue;
        }


        public async Task<Attachment> GeneralHashAsync(Attachment attachment)
        {
            var uri = _domesticPaymentConfiguration.HashingUri; 
            var request = new Attachment(){ Base64Value = attachment.Base64Value };

            var response = await _httpHashService.RequesAsync("POST", uri, request).ConfigureAwait(false);
            return response;
        }


        /// <summary>
        /// sync an outbound erx customer withdraw data to scb ftp
        /// </summary>
        /// <param name="path">outbound domestic payment path</param>
        /// <returns>list of all attachment and status</returns>
        public async Task<IEnumerable<Attachment>> SyncDomesticPaymentAsync(string path)
        {
            var type = TransactionType.DOMESTICPAYMENT;

            string base64Guid = Convert.ToBase64String(Guid.NewGuid().ToByteArray());
            var syncedDate = DateTime.Now;
            var syncedBlobPath = "emrelog-" + type.ToString().ToLower() + syncedDate.ToString("_ddMMyyyy-HH:mm");
            var syncedStatus = SyncStatus.RUNNING;

            //TODO : should load from appsettings
            string domesticPaymentPrefix = _domesticPaymentConfiguration.DomesticPaymentPrefix;
            string companyCode = _domesticPaymentConfiguration.CompanyCode;

            string scbBankCode = "014";
            string domesticPaymentSuffix = _domesticPaymentConfiguration.DomesticPaymentSuffix;

            string fileExtension = ".txt.gpg";
            string ctrlFileExtension = ".ctrl";

            var exceptionMessage = "";

            DateTime start = DateTime.Now.AddHours(-24);
            DateTime end = DateTime.Now.AddHours(24);

            //load withdraw transaction from OC
            var transactions = await _exchangeService.ListWithdrawTransactionAsync(start, end).ConfigureAwait(false);

            //filter investor from OC by transaction.investorId
            var ids = transactions.Select(c => c.InvestorId).ToArray();

            var investors = await _exchangeService.ListInvestorAsync(ids).ConfigureAwait(false); ;

            //parse attribulte to  SCBBusinessPay-BulkERP_via_sFTP_v3.1,  layout
            var domesticPayments = await _domesticPaymentService.ParseAsync(transactions, investors, base64Guid).ConfigureAwait(false);

            var entities = new List<Attachment>();

            foreach(var dp in domesticPayments)
            { 
                var entity = new Attachment();

                //persist domestic payment
                await _domesticPaymentService.CreateAsync(dp).ConfigureAwait(false);

                //put it to line break string
                string lines = await BulkERPMediaTypeFormatter.WriteResponseBodyAsync(dp);

                //convert to bye array (base 64) 
                var base64Content = Encoding.ASCII.GetBytes(lines);
                entity.Base64Value = base64Content;

                var base64HashContent = await this.GeneralHashAsync(entity).ConfigureAwait(true);

                //encypted 
                var base64EncyptedValue = await this.EncryptAsync(base64HashContent.Base64Value);
                
                entity.Base64EncryptedValue = base64EncyptedValue;
                entity.Base64Value = base64HashContent.Base64Value;

               ///“BulkERP_” + [SCB Corp ID] + “014” (3 digit) + “PAY” (3 digit) + Sending Date(8 digit) + Sending Time(6 digit).txt.gpg
               /// Sending Date(8 digit) : YYYYMMDD
               /// Sending Time(6 digit) : HHMMSS
               ///
               /// example BulkERP_SCBCORP014PAY20150127151534.txt.gpg

               //generate file name
               var date = DateTime.Now;
               var name = domesticPaymentPrefix + companyCode + scbBankCode + domesticPaymentSuffix
                                                                                        + date.ToString("yyyyMMdd") + date.ToString("HHmmss");
                entity.Path = path;
                string fullname = $"{path}/{name}{fileExtension}";

                entity.Name = fullname;

                //copy file  to blobs
                using var encryptedStreamContent = new MemoryStream(entity.Base64EncryptedValue);

                //put to ftp with retry polly
                var policy = Policy
                .Handle<SftpNotValidException>()
                .WaitAndRetryForeverAsync(retryAttempt => TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)),
                (exception, timespan) =>
                {
                    _logger.LogInformation("WaitAndRetry: " + timespan.TotalMilliseconds + " milliseconds");
                });

                await policy.ExecuteAsync(
                    async () =>
                    {

                        //try x times with Polly
                        await _sftpClientService.UploadStreamAsync(encryptedStreamContent, fullname).ConfigureAwait(true);

                    }).ConfigureAwait(false);

                //write and put controle file with polly retry
                //Payment File Name + .ctrl
                string line = $"{name}{fileExtension}";
                var base64CtrlContent = Encoding.ASCII.GetBytes(line);
                using var ctrlStreamContent = new MemoryStream(base64CtrlContent);
                string ctrlFullname = $"{path}/{name}{ctrlFileExtension}";

                await policy.ExecuteAsync(
                    async () =>
                    {
                    //try x times with Polly
                    await _sftpClientService.UploadStreamAsync(ctrlStreamContent, ctrlFullname).ConfigureAwait(true);

                    }).ConfigureAwait(false);

                try
                {
                    //upload blob
                    var uri = new Uri(_azureBlobStorageService.BlobUrl + $"/{syncedBlobPath}-{syncedStatus}/{fullname}");
                    await _azureBlobStorageService.UploadBlobAsync(uri, encryptedStreamContent).ConfigureAwait(true);
                }
                catch (AzureNotValidException)
                {
                    syncedStatus = SyncStatus.FAILED;
                    exceptionMessage = "Fail to upload file to blob";
                }

                //log attachment
                entity.Id = Guid.NewGuid();
                entity.SyncedDate = syncedDate;
                entity.SyncedStatus = syncedStatus.ToString();
                entity.SyncedId = base64Guid;

                //total credit rows
                entity.TotalTransaction = transactions.Count();

                entity.TransactionType = type.ToString();
                entity.ExceptionMessage = exceptionMessage;

                await _attachmentRepository.CreateAsync(entity).ConfigureAwait(false);

                entities.Add(entity);
                }
   
                return entities;
        }


        /// <summary>
        /// sync payment return file, running at  + 1hr from SyncDomesticPaymentAsync
        /// </summary>
        /// <param name="path">outbound return file file path</param>
        /// <returns></returns>

        public async Task<IEnumerable<Attachment>> SyncDomesticReturnAsync(string path)
        {
            var entities = new List<Attachment>();

            var type = TransactionType.DOMESTICRETURN;

            //string ctrlFileExtension = ".ctrl";

            var id = Guid.NewGuid().ToString();
            var syncedDate = DateTime.Now;
            var syncedBlobPath = "[emrelog]-" + type.ToString().Capitalize() + syncedDate.ToString("_ddMMyyyy-HH:mm");

            //list inbound sftp transaction / statement file 
            var sftpFiles = await _sftpClientService.ListFileAsync(path).ConfigureAwait(false);

            //remove ctrl file
            //sftpFiles = sftpFiles.Where(c => !c.Name.Contains(ctrlFileExtension, StringComparison.InvariantCultureIgnoreCase));

            _logger.LogInformation("ListFileAsync: " + sftpFiles.Count());

            int i = 1;

            foreach (var file in sftpFiles)
            {
                _logger.LogInformation($"file ({i} of {sftpFiles.Count()}): " + file.FullName);

                var syncedStatus = SyncStatus.RUNNING;
                var exceptionMessage = "";

                var transactionType = type;

                //download file as stream
                var attachment = new Attachment()
                {
                    Id = Guid.NewGuid(),
                    Created = DateTime.Now,

                    Name = file.Name,
                    Path = file.FullName,
                    SyncedStatus = syncedStatus.ToString(),
                    SyncedId = id,
                    SyncedDate = syncedDate,
                    TransactionType = type.ToString(),
                };

                //persist attachement
                var entityAttachment = await _attachmentRepository.CreateAsync(attachment).ConfigureAwait(false);

                var policy = Policy
                .Handle<SftpNotValidException>()
                .WaitAndRetryForeverAsync(retryAttempt => TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)),
                (exception, timespan) =>
                {
                    _logger.LogInformation("WaitAndRetry: " + timespan.TotalMilliseconds + " milliseconds");
                });

                await policy.ExecuteAsync(
                    async () =>
                    {
                        //try x times with Polly
                        var fileAsync = await _sftpClientService.DownloadAsStreamAsync(file.FullName).ConfigureAwait(true);

                        //mappp value
                        entityAttachment.Name = fileAsync.Name;
                        entityAttachment.Path = fileAsync.Path;
                        entityAttachment.Extension = fileAsync.Extension;
                        entityAttachment.Size = fileAsync.Size;
                        entityAttachment.Base64EncryptedValue = fileAsync.Base64Value;

                    }).ConfigureAwait(false);

                //copy file  to blobs
                using var encryptedStreamContent = new MemoryStream(entityAttachment.Base64EncryptedValue);

                try
                {
                    //upload blob
                    var uri = new Uri(_azureBlobStorageService.BlobUrl + $"/{syncedBlobPath}-{syncedStatus}/{file.Name.Replace(" ", "_", StringComparison.OrdinalIgnoreCase)}");
                    await _azureBlobStorageService.UploadBlobAsync(uri, encryptedStreamContent).ConfigureAwait(true);
                }
                catch (AzureNotValidException)
                {
                    syncedStatus = SyncStatus.FAILED;
                    exceptionMessage = "Fail to upload file to blob";
                    continue;
                }

                i++;

                //decypted file
                var base64Value = await _base64CryptoService.GpgDecryptAsync(entityAttachment.Base64EncryptedValue);

                //var sreamContent = new StreamReader(new MemoryStream(decryptedAttachment.Base64Value));
                //var contents = await sreamContent.ReadToEndAsync();
                var content = Encoding.GetEncoding(874).GetString(base64Value).Trim();
                if (string.IsNullOrEmpty(content))
                {
                    //go next file
                    //update synce status
                    syncedStatus = SyncStatus.FAILED;
                    exceptionMessage = "Empty file content";
                }

                //Encoding.Default.GetString(decryptedAttachment.Base64Value);
                var lines = content.Split(Environment.NewLine.ToCharArray(), StringSplitOptions.None);  

                //try parse
                PaymentReturn paymentReturn;
                if (!_domesticReturnService.TryParseAsync(lines, out paymentReturn))

                {
                    //update synce status
                    syncedStatus = SyncStatus.FAILED;
                    exceptionMessage = "Content is not valid";
                }
                else
                {
                    if (!paymentReturn.ResultRecords.Any()) // TODO : check null
                    {
                        //update synce status
                        syncedStatus = SyncStatus.FAILED;
                        exceptionMessage = "Content no detail";
                    }
                    else
                    {
                        //TODO : please change to detail only

                        paymentReturn.AttachmentId = entityAttachment.Id;
                        paymentReturn.AttachmentName = entityAttachment.Name;
                        paymentReturn.TransactionType = type.ToString();

                        //dailyBillPayment.Header.Id = await _crossBankPaymentService.GetHeaderIdAsync(dailyBillPayment.Header);
                        try
                        {
                            var created = await _domesticReturnService.CreateAsync(paymentReturn);

                            //set total transction
                            entityAttachment.TotalTransaction = created.ResultRecords.Count;

                            //done
                            syncedStatus = SyncStatus.SUCCEEDED;
                        }
                        catch (CosmosException ex)
                        {
                            if (ex.StatusCode == System.Net.HttpStatusCode.Conflict)
                            {
                                // Unique key constraint violation ...
                                //update synce status
                                syncedStatus = SyncStatus.FAILED;
                                exceptionMessage = ex.Message;
                                // entityAttachment.StackTrace = ex.StackTrace;
                            }
                            else
                            {
                                throw;
                            }
                        }
                    }
                }
                try
                {
                    //delete file
                    await _sftpClientService.DeleteFileAsync(file.FullName).ConfigureAwait(false);

                }
                catch (SftpNotValidException)
                {
                    syncedStatus = SyncStatus.FAILED;
                    exceptionMessage = "Fail to delete sftp file";
                }

                entityAttachment.SyncedStatus = syncedStatus.ToString();
                entityAttachment.ExceptionMessage = exceptionMessage;

                //update attachment with status
                await _attachmentRepository.UpdateAsync(entityAttachment.Id, entityAttachment).ConfigureAwait(false);
                entities.Add(entityAttachment);
            }

            return entities;
        }


        /// <summary>
        ///  sync an inbound scb reconcile payment to erx database
        /// </summary>
        /// <param name="type"></param>
        /// <param name="path"></param>
        /// <returns>list of all attachment and status</returns>
        public async Task<IEnumerable<Attachment>> SyncPaymentAsync(TransactionType type, string path)
        {

            var entities = new List<Attachment>();

            var id = Guid.NewGuid().ToString();
            var syncedDate = DateTime.Now;
            var syncedBlobPath = "[emrelog]-" + type.ToString().Capitalize() + syncedDate.ToString("_ddMMyyyy-HH:mm");

            //list inbound sftp transaction / statement file 
            var sftpFiles = await _sftpClientService.ListFileAsync(path).ConfigureAwait(false);

            _logger.LogInformation("ListFileAsync: " + sftpFiles.Count());

            int i = 1;

            foreach (var file in sftpFiles)
            {
                _logger.LogInformation($"file ({i} of {sftpFiles.Count()}): " + file.FullName);

                var syncedStatus = SyncStatus.RUNNING;
                var exceptionMessage = "";

                var transactionType = type;

                //download file as stream
                var attachment = new Attachment()
                {
                    Id = Guid.NewGuid(),
                    Created = DateTime.Now,

                    Name = file.Name,
                    Path = file.FullName,
                    SyncedStatus = syncedStatus.ToString(),
                    SyncedId = id,
                    SyncedDate = syncedDate,
                    TransactionType = type.ToString(),
                };

                //persist attachement
                var entityAttachment = await _attachmentRepository.CreateAsync(attachment).ConfigureAwait(false);

                var policy = Policy
                .Handle<SftpNotValidException>()
                .WaitAndRetryForeverAsync(retryAttempt => TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)),
                (exception, timespan) =>
                {
                    _logger.LogInformation("WaitAndRetry: " + timespan.TotalMilliseconds + " milliseconds");
                });

                await policy.ExecuteAsync(
                    async () =>
                    {
                        //try x times with Polly
                        var fileAsync = await _sftpClientService.DownloadAsStreamAsync(file.FullName).ConfigureAwait(true);

                        //mappp value
                        entityAttachment.Name = fileAsync.Name;
                        entityAttachment.Path = fileAsync.Path;
                        entityAttachment.Extension = fileAsync.Extension;
                        entityAttachment.Size = fileAsync.Size;
                        entityAttachment.Base64EncryptedValue = fileAsync.Base64Value;

                    }).ConfigureAwait(false);

                //copy file  to blobs
                using var encryptedStreamContent = new MemoryStream(entityAttachment.Base64EncryptedValue);

                try
                {
                    //upload blob
                    var uri = new Uri(_azureBlobStorageService.BlobUrl + $"/{syncedBlobPath}-{syncedStatus}/{file.Name.Replace(" ", "_", StringComparison.OrdinalIgnoreCase)}");
                    await _azureBlobStorageService.UploadBlobAsync(uri, encryptedStreamContent).ConfigureAwait(true);
                }
                catch (AzureNotValidException)
                {
                    syncedStatus = SyncStatus.FAILED;
                    exceptionMessage = "Fail to upload file to blob";
                    continue;
                }

                i++;

                //decypted file
                var base64Value = await _base64CryptoService.GpgDecryptAsync(entityAttachment.Base64EncryptedValue);

                //var sreamContent = new StreamReader(new MemoryStream(decryptedAttachment.Base64Value));
                //var contents = await sreamContent.ReadToEndAsync();
                var content = Encoding.GetEncoding(874).GetString(base64Value).Trim();
                if (string.IsNullOrEmpty(content))
                {
                    //go next file
                    //update synce status
                    syncedStatus = SyncStatus.FAILED;
                    exceptionMessage = "Empty file content";
                }

                //Encoding.Default.GetString(decryptedAttachment.Base64Value);
                var lines = content.Split(Environment.NewLine.ToCharArray(), StringSplitOptions.None);  //TODO: enviroment.newline 

                //try parse
                CrossBankBillPayment crossBankBillPayment;
                if (!_crossBankPaymentService.TryParseAsync(lines, out crossBankBillPayment))
                
                {
                    //update synce status
                    syncedStatus = SyncStatus.FAILED;
                    exceptionMessage = "Content is not valid";
                }
                else
                {
                    if (!crossBankBillPayment.Details.Any()) // TODO : check null
                    {
                        //update synce status
                        syncedStatus = SyncStatus.FAILED;
                        exceptionMessage = "Content no detail";
                    }
                    else
                    {
                        //TODO : please change to detail only

                        crossBankBillPayment.AttachmentId = entityAttachment.Id;
                        crossBankBillPayment.AttachmentName = entityAttachment.Name;
                        crossBankBillPayment.TransactionType = type.ToString();

                        //dailyBillPayment.Header.Id = await _crossBankPaymentService.GetHeaderIdAsync(dailyBillPayment.Header);
                        try
                        {
                            var created = await _crossBankPaymentService.CreateAsync(crossBankBillPayment);

                            //set total transction
                            entityAttachment.TotalTransaction = created.Details.Count;

                            //done
                            syncedStatus = SyncStatus.SUCCEEDED;
                        }
                        catch (CosmosException ex)
                        {
                            if (ex.StatusCode == System.Net.HttpStatusCode.Conflict)
                            {
                                // Unique key constraint violation ...
                                //update synce status
                                syncedStatus = SyncStatus.FAILED;
                                exceptionMessage = ex.Message;
                                // entityAttachment.StackTrace = ex.StackTrace;
                            }
                            else
                            {
                                throw;
                            }
                        }
                    }
                }
                try
                {
                    //delete file
                    await _sftpClientService.DeleteFileAsync(file.FullName).ConfigureAwait(false);

                }
                catch (SftpNotValidException)
                {
                    syncedStatus = SyncStatus.FAILED;
                    exceptionMessage = "Fail to delete sftp file";
                }

                entityAttachment.SyncedStatus = syncedStatus.ToString();
                entityAttachment.ExceptionMessage = exceptionMessage;

                //update attachment with status
                await _attachmentRepository.UpdateAsync(entityAttachment.Id, entityAttachment).ConfigureAwait(false);
                entities.Add(entityAttachment);
            }

            return entities;
        }

        /// <summary>
        //  sync an inbound scb reconcile statement to erx database
        /// </summary>
        /// <param name="type"></param>
        /// <param name="path"></param>
        /// <returns>list of all attachment and status</returns>
        public async Task<IEnumerable<Attachment>> SyncStatementAsync(TransactionType type, string path)
        {
            var entities = new List<Attachment>();

            var id = Guid.NewGuid().ToString();
            var syncedDate = DateTime.UtcNow;
            var syncedBlobPath = "emrelog-" + type.ToString().Capitalize() + syncedDate.ToString("_ddMMyyyy-HH:mm");

            //list inbound sftp transaction / statement file 
            var sftpFiles = await _sftpClientService.ListFileAsync(path).ConfigureAwait(false);

            //var attachment = new Attachment();
            _logger.LogInformation("ListFileAsync: " + sftpFiles.Count());

            int i = 1;

            foreach (var file in sftpFiles)
            {
                _logger.LogInformation($"file ({i} of {sftpFiles.Count()}): " + file.FullName);

                var syncedStatus = SyncStatus.RUNNING;
                var exceptionMessage = "";

                var transactionType = type;

                //download file as stream
                var attachment = new Attachment()
                {
                    Id = Guid.NewGuid(),
                    Created = DateTime.Now,

                    Name = file.Name,
                    Path = file.FullName,
                    SyncedStatus = syncedStatus.ToString(),
                    SyncedId = id,
                    SyncedDate = syncedDate,
                    TransactionType = type.ToString(),
                };

                //persist attachement
                var entityAttachment = await _attachmentRepository.CreateAsync(attachment).ConfigureAwait(false);

                var policy = Policy
                .Handle<SftpNotValidException>()
                .WaitAndRetryForeverAsync(retryAttempt => TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)),
                (exception, timespan) =>
                {
                    _logger.LogInformation("WaitAndRetry: " + timespan.TotalMilliseconds + " milliseconds");
                });

                await policy.ExecuteAsync(
                    async () =>
                    {
                        //try x times with Polly
                        var fileAsync = await _sftpClientService.DownloadAsStreamAsync(file.FullName).ConfigureAwait(true);

                        //mappp value
                        entityAttachment.Name = fileAsync.Name;
                        entityAttachment.Path = fileAsync.Path;
                        entityAttachment.Extension = fileAsync.Extension;
                        entityAttachment.Size = fileAsync.Size;
                        entityAttachment.Base64EncryptedValue = fileAsync.Base64Value;

                    }).ConfigureAwait(false);

                //copy file  to blobs
                using var encryptedStreamContent = new MemoryStream(entityAttachment.Base64EncryptedValue);

                try
                {
                    //upload blob
                    var uri = new Uri(_azureBlobStorageService.BlobUrl + $"/{syncedBlobPath}-{syncedStatus}/{file.Name.Replace(" ", "_", StringComparison.OrdinalIgnoreCase)}");
                    await _azureBlobStorageService.UploadBlobAsync(uri, encryptedStreamContent).ConfigureAwait(true);
                }
                catch (AzureNotValidException)
                {
                    syncedStatus = SyncStatus.FAILED;
                    exceptionMessage = "Fail to upload file to blob";
                    continue;
                }

                i++;

                //decypted file
                var base64Value = await _base64CryptoService.GpgDecryptAsync(entityAttachment.Base64EncryptedValue);

                //var sreamContent = new StreamReader(new MemoryStream(decryptedAttachment.Base64Value));
                //var contents = await sreamContent.ReadToEndAsync();
                var content = Encoding.GetEncoding(874).GetString(base64Value).Trim();
                if (string.IsNullOrEmpty(content))
                {
                    //go next file
                    //update synce status
                    syncedStatus = SyncStatus.FAILED;
                    exceptionMessage = "Empty file content";
                }

                //Encoding.Default.GetString(decryptedAttachment.Base64Value);
                var lines = content.Split(Environment.NewLine.ToCharArray(), StringSplitOptions.None);  //TODO: enviroment.newline 


                //try parse
                IEnumerable<HistoricalBankStatement> historyStatements;
                if (!_historyStatementService.TryParseAsync(lines, out historyStatements))
                {
                    //update synce status
                    syncedStatus = SyncStatus.FAILED;
                    exceptionMessage = "Content is not valid";
                }
                else
                {
                    //set parent attachemtn id
                    historyStatements = historyStatements
                            .Select(c => { c.AttachmentId = entityAttachment.Id; c.AttachmentName = entityAttachment.Name; return c; }).ToList();

                    try
                    {
                        var created = await _historyStatementService.CreateRangeAsync(historyStatements).ConfigureAwait(false);

                        //set total transction
                        entityAttachment.TotalTransaction = created.Count();

                        //done
                        syncedStatus = SyncStatus.SUCCEEDED;
                    }
                    catch (CosmosException ex)
                    {
                        if (ex.StatusCode == System.Net.HttpStatusCode.Conflict)
                        {
                            // Unique key constraint violation ...
                            //update synce status
                            syncedStatus = SyncStatus.FAILED;
                            exceptionMessage = ex.Message;
                            // entityAttachment.StackTrace = ex.StackTrace;
                        }
                        else
                        {
                            throw;
                        }
                    }
                }

                try
                {
                    //delete file
                    await _sftpClientService.DeleteFileAsync(file.FullName).ConfigureAwait(false);

                }
                catch (SftpNotValidException)
                {
                    syncedStatus = SyncStatus.FAILED;
                    exceptionMessage = "Fail to delete sftp file";
                }

                entityAttachment.SyncedStatus = syncedStatus.ToString();
                entityAttachment.ExceptionMessage = exceptionMessage;

                //update attachment with status
                await _attachmentRepository.UpdateAsync(entityAttachment.Id, entityAttachment).ConfigureAwait(false);
                entities.Add(entityAttachment);
            }

            return entities;
        }

    }
}
