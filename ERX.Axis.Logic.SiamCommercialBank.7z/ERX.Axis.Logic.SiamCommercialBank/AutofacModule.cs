﻿using Autofac;
using System.Reflection;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public class AutofacModule
    {
        protected void Load(ContainerBuilder builder)
        {
            builder.RegisterAssemblyTypes(Assembly.GetExecutingAssembly())
                .AsSelf()
                .AsImplementedInterfaces();

            builder.RegisterGeneric(typeof(Repository<,>))
                .AsImplementedInterfaces()
                .SingleInstance();
        }
    }
}
