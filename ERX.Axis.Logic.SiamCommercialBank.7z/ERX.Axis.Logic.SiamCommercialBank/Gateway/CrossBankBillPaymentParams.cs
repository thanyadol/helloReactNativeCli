﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public class CrossBankBillPaymentParams
    {
        /// <summary>
        /// Used for HTTPPOST incomming request, require
        /// </summary>
        ///
        public DateTime StartDate { get; set; }

        /// <summary>
        /// Used for HTTPPOST incomming request, require
        /// </summary>
        ///
        public DateTime EndDate { get; set; }

        public string TransactionCode { get; set; }

        public decimal? MinAmount { get; set; }

        public decimal? MaxAmount { get; set; }


        public string CompanyAccount { get; set; }

        public string Ref1 { get; set; }

        public string Ref2 { get; set; }

    }
}
