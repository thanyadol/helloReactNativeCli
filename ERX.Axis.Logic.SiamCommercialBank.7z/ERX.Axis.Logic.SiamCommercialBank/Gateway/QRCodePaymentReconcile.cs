﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace ERX.Axis.Logic.SiamCommercialBank.Gateway
{
    public class QRCodePaymentReconcile
    {

        /// <summary>
        /// system generated to identity row
        /// </summary>
        /// 
        [JsonProperty("id")]
        public Guid Id { get; set; }


        /// <summary>
        /// One Circle transaction
        /// </summary>
        /// 
        [JsonProperty("ticket")]
        public Transaction Ticket { get; set; }


        /// <summary>
        /// QRCode http request
        /// </summary>
        /// 
        [JsonProperty("qrCode")]
        public QRCodePaymentRequest QRCode { get; set; }


        /// <summary>
        /// Confirm payment from SCB server
        /// </summary>
        /// 
        [JsonProperty("confirmPayment")]
        public PaymentConfirmationRequest ConfirmPayment { get; set; }

        /// <summary>
        /// Used for HTTPPOST incomming request
        /// </summary>
        ///
        public DateTime StartDate { get; set; }

        /// <summary>
        /// Used for HTTPPOST incomming request
        /// </summary>
        ///
        public DateTime EndDate { get; set; }


        public DateTime ReconcileDate { get; set; }

        /// <summary>
        /// Reconcile status processing from Business logic
        /// RECONCILED or CLEARED  
        /// </summary>
        /// 
        public string Status { get; set; }


        /// <summary>
        /// Description from status
        /// </summary>
        /// 
        public string Description { get; set; }

    }
}
