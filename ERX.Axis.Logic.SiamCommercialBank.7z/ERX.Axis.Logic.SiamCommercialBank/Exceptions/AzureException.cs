﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public class AzureNotValidException : Exception
    {

        private const string DEFAULT_MESSAGE = "AzureNotValidException";
        public string rev { get; }
        public string value { get; }

        public AzureNotValidException()
           : base(DEFAULT_MESSAGE)
        {
        }

        public AzureNotValidException(string message)
       : base(message)
        {
        }

        public AzureNotValidException(string message, Exception inner)
       : base(message, inner)
        {
        }

    }
}
