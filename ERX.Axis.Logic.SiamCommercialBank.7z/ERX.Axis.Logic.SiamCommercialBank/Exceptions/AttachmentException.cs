// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT license.using System

using System;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public class AttachmentException : Exception
    {
        public AttachmentException() { }

        public AttachmentException(string message) : base(message) { }
    }

    public class AttachmentNotValidException : AttachmentException
    {
    }

    public class AttachmentNotFoundException : AttachmentException
    {
    }


}
