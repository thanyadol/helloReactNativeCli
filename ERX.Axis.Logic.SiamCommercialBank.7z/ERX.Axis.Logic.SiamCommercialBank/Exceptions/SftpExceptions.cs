using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public class SftpNotValidException : Exception
    {

        private const string DEFAULT_MESSAGE = "SftpNotValidException";
        public string rev { get; }
        public string value { get; }

        public SftpNotValidException()
           : base(DEFAULT_MESSAGE)
        {
        }
        public SftpNotValidException(string message)
            : base(message)

        { }

    }
}