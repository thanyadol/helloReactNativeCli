﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public class DomesticPaymentConfiguration
    { 
        public string HashingUri { get; set; }

        public string SavingAccountNumber { get; set; }

        public string CurrentAccountNumber { get; set; }

        public string FeeDebitAccountNumber { get; set; }

        public string DebitInternalReferencePrefix { get; set; }

        public string CompanyCode { get; set; }
        public string DomesticPaymentPrefix { get; set; }
        public string DomesticPaymentSuffix { get; set; }

        public string ScbEncryptPublicKey { get; set; }
    }
}
