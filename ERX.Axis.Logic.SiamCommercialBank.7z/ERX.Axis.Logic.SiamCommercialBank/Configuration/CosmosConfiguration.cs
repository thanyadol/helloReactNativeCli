
using System;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public class CosmosConfiguration
    {
        public string DatabaseId { get; set; }
        public string ConnectionString { get; set; }
    }

}