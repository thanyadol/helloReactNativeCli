
using System;
namespace ERX.Axis.Logic.SiamCommercialBank
{
    public class AzureBlobStorageConfiguration
    {
        public string BlobUrl { get; set; }
        public string BlobConnectionString { get; set; }
    }

}