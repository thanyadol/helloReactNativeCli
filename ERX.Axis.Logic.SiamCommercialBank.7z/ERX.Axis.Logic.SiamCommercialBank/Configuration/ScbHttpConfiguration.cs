﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public class ScbHttpConfiguration
    {
        public string Url { get; set; }
        public int NumberOfTimes { get; set; }
        public int ExpiryTimeOfDayInHour { get; set; }
        public int ExpiryTimeOfDayInMinute { get; set; }
        public string ApiKey { get; set; }
        public string ApiSecret { get; set; }
    }
}
