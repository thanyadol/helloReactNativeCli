using System;
using System.Collections.Generic;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public class GpgDecryptConfiguration
    {
        public string PassPhase { get; set; }
        public string Key { get; set; }

        public string PrivateKey { get; set; }

    }

}