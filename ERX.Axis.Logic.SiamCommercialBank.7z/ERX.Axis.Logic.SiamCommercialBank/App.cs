﻿
using System;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;


namespace ERX.Axis.Logic.SiamCommercialBank
{
    /// <summary>
    /// For testing
    /// </summary>
    public class App
    {
        private readonly IScbHttpService _scb;   // local reference so we can use the service
        //private readonly IScbTransactionService _synce;

        public App(IScbHttpService scb) // dependency delcared in constructor
        {
            _scb = scb;                       // save the reference provided by DI
        }

        public async Task Run()
        {
            var services = new ServiceCollection();

            services.AddScbHttpDeveloperApi();
            //services.AddScbTransactionSync();


            await Task.Delay(0).ConfigureAwait(false);
        }
    }
}
