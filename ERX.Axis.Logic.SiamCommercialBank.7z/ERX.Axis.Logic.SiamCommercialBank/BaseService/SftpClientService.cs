
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using System.IO;

using Microsoft.Extensions.Options;
using Renci.SshNet.Sftp;
using Renci.SshNet;
using Renci.SshNet.Async;
using Renci.SshNet.Common;
using Microsoft.Extensions.Logging;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public interface ISftpClientService
    {
        Task<IEnumerable<SftpFile>> ListFileAsync(string remoteDirectory = ".");
        Task<Base64Content> DownloadAsStreamAsync(string remoteFilePath);
        Task<bool> UploadStreamAsync(MemoryStream localFileStream, string remoteFilePath);
        Task<bool> DeleteFileAsync(string remoteFilePath);
    }

    public class SftpClientService : ISftpClientService
    {
        private readonly SftpConfiguration _sftpConfiguration;

        public SftpClientService(IOptions<SftpConfiguration> sftpConfiguration)
        {
            _sftpConfiguration = sftpConfiguration.Value;
        }

        public async Task<IEnumerable<SftpFile>> ListFileAsync(string remoteDirectory = ".")
        {

            using var client = new SftpClient(_sftpConfiguration.Host,
                                                _sftpConfiguration.Port == 0 ? 22 : _sftpConfiguration.Port,
                                                _sftpConfiguration.UserName,
                                                _sftpConfiguration.Password);

            PasswordAuthenticationMethod authMethod = new PasswordAuthenticationMethod(_sftpConfiguration.UserName, _sftpConfiguration.Password);
            ConnectionInfo connectionInfo = new ConnectionInfo(_sftpConfiguration.Host, _sftpConfiguration.Port, _sftpConfiguration.UserName, authMethod);

            client.HostKeyReceived += delegate (object sender, HostKeyEventArgs e)
            {
                e.CanTrust = true;
            };

            client.Connect();

            var files = await client.ListDirectoryAsync(remoteDirectory);
            files = files.Where(c => c.IsDirectory == false);

            return files;
            

            /*try
            {
                client.Connect();

                var files = await client.ListDirectoryAsync(remoteDirectory);
                files = files.Where(c => c.IsDirectory == false);

                return files;
            }
            catch (Exception ex)
            {
                throw new SftpNotValidException("It appears there was a problem " + ex.Message + ex.InnerException);
            }
            finally
            {
                client.Disconnect();
            }*/

        }


        public async Task<bool> UploadStreamAsync(MemoryStream localFileStream, string remoteFilePath)
        {
            using var client = new SftpClient(_sftpConfiguration.Host, _sftpConfiguration.Port == 0 ? 22 : _sftpConfiguration.Port, _sftpConfiguration.UserName, _sftpConfiguration.Password);
            try
            {
                client.Connect();
                await client.UploadAsync(localFileStream, remoteFilePath);

                return await Task.FromResult(true);
            }
            catch (Exception ex)
            {
                throw new SftpNotValidException(ex.Message);
            }
            finally
            {
                client.Disconnect();
            }
        }

        public async Task<Base64Content> DownloadAsStreamAsync(string remoteFilePath)
        {
            using var client = new SftpClient(_sftpConfiguration.Host, _sftpConfiguration.Port == 0 ? 22 : _sftpConfiguration.Port, _sftpConfiguration.UserName, _sftpConfiguration.Password);
            try
            {
                client.Connect();

                // Load remote file into a stream
                using (var remoteFileStream = client.OpenRead(remoteFilePath))
                {
                    var file = new Base64Content
                    {
                        Name = Path.GetFileName(remoteFilePath),
                        Path = Path.GetFullPath(remoteFilePath),
                        Extension = Path.GetExtension(remoteFilePath),
                        Size = remoteFileStream.Length,
                        Base64Value = remoteFileStream.ReadFully()
                    };

                    return await Task.FromResult(file);
                }

            }
            catch (Exception ex)
            {
                throw new SftpNotValidException(ex.Message);
            }
            finally
            {
                client.Disconnect();
            }
        }

        public Task<bool> DeleteFileAsync(string remoteFilePath)
        {
            using var client = new SftpClient(_sftpConfiguration.Host, _sftpConfiguration.Port == 0 ? 22 : _sftpConfiguration.Port, _sftpConfiguration.UserName, _sftpConfiguration.Password);
            try
            {
                client.Connect();
                client.DeleteFile(remoteFilePath);

                return Task.FromResult(true);
            }
            catch (Exception ex)
            {
                throw new SftpNotValidException(ex.Message);
            }
            finally
            {
                client.Disconnect();
            }
        }
    }

}