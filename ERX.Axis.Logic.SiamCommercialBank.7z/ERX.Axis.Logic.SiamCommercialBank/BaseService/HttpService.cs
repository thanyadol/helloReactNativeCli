using System;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

using System.Text;
using System.Collections.Generic;
using Newtonsoft.Json;
using Microsoft.AspNetCore.WebUtilities;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public interface IHttpService<TRequest, TResponse>
    {
        Task SetHeaderAsync(Dictionary<string, string> header);

        Task<TResponse> GetAsync(string methodName);

        Task<TResponse> RequesAsync(string type, string url, TRequest request);

    }

    public class HttpService<TRequest, TResponse> : IHttpService<TRequest, TResponse>
    {
        private readonly HttpClient _httpClient;

        public HttpService(HttpClient httpClient)
        {
             _httpClient = httpClient;
        }

        public async Task SetHeaderAsync(Dictionary<string, string> header)
        {
            foreach (var item in header)
            {
                _httpClient.DefaultRequestHeaders.Add(item.Key, item.Value);

            }
            await Task.CompletedTask;
        }

        public async Task<TResponse> GetAsync(string url)
        {
            var result = new HttpResponseMessage();
            try
            {
                result = await _httpClient.GetAsync(url);
            }
            catch (HttpRequestException ex)
            {
                throw new ClientNotSuccessException((int)result.StatusCode, "HTTTPGET", url, ex.Message);
            }

            var httpReponse = await result.Content.ReadAsStringAsync();

            //var httpReponse = await result.Content.ReadAsStringAsync();
            var entity = JsonConvert.DeserializeObject<TResponse>(httpReponse);
            return entity;
        }

        public async Task<TResponse> RequesAsync(string type, string url, TRequest request)
        {
            var result = new HttpResponseMessage();

            switch (type)
            {
                case "GET":
                    var _params = ObjectExtension.ToDictionary<string>(request);
                    var uri = QueryHelpers.AddQueryString(url, _params);
                    result = await _httpClient.GetAsync(uri);
                    break;
                case "POST":
                    var json = JsonConvert.SerializeObject(request);
                    var content = new ByteArrayContent(Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(request)));
                    content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                    result = await _httpClient.PostAsync(url, content);
                    break;
                case "PUT":
                case "DELETE":
                default:
                    throw new NotImplementedException();
                    //break;

            }

            result.EnsureSuccessStatusCode(); 

            var httpReponse = await result.Content.ReadAsStringAsync();
            var entity = JsonConvert.DeserializeObject<TResponse>(httpReponse);
            return entity;
        }
    }
}