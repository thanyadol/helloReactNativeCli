﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using PgpCore;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public interface IBase64CryptoService
    {
       Task<byte[]> GpgEncryptAsync(byte[] attach);
       Task<byte[]> GpgDecryptAsync(byte[] cripher);
       Task<byte[]> GpgEncryptAsync(byte[] attach, string key);
    }

    public class Base64CryptoService : IBase64CryptoService
    {
        private readonly GpgDecryptConfiguration _configuration;

        public Base64CryptoService(IOptions<GpgDecryptConfiguration> configuration)
        {
            _configuration = configuration.Value ?? throw new ArgumentNullException(nameof(configuration.Value));
        }

        public async Task<byte[]> GpgEncryptAsync(byte[] attach)
        {
            using (var pgp = new PGP())
            {
                using var publicKeyStream = _configuration.Key.ToStream();
                using var value = new MemoryStream(attach);

                using (var outputMemoryStream = new MemoryStream())
                {
                    try
                    {
                        await pgp.EncryptStreamAsync(value, outputMemoryStream, publicKeyStream, true, true);
                    }
                    catch (IOException)
                    {
                        throw new AttachmentNotValidException();
                    }
                    //attach.EncryptedValue = outputMemoryStream;
                    attach = outputMemoryStream.ToArray();
                }

            }
            return attach;
        }


        public async Task<byte[]> GpgEncryptAsync(byte[] attach, string key)
        {
            using (var pgp = new PGP())
            {
                using var publicKeyStream = key.ToStream();
                using var value = new MemoryStream(attach);

                using (var outputMemoryStream = new MemoryStream())
                {
                    try
                    {
                        await pgp.EncryptStreamAsync(value, outputMemoryStream, publicKeyStream, true, true);
                    }
                    catch (IOException)
                    {
                        throw new AttachmentNotValidException();
                    }
                    //attach.EncryptedValue = outputMemoryStream;
                    attach = outputMemoryStream.ToArray();
                }

            }
            return attach;
        }


        public async Task<byte[]> GpgDecryptAsync(byte[] cripher)
        {
            using (var pgp = new PGP())
            {
                using var privateKeyStream = _configuration.PrivateKey.ToStream();
                using var value = new MemoryStream(cripher);
                using (var outputMemoryStream = new MemoryStream())
                {
                    try
                    {
                        await pgp.DecryptStreamAsync(value, outputMemoryStream, privateKeyStream, _configuration.PassPhase);
                    }
                    catch (IOException)
                    {
                        throw new AttachmentNotValidException();
                    }

                    cripher = outputMemoryStream.ToArray();
                }

            }

            return cripher;
        }
    }
}
