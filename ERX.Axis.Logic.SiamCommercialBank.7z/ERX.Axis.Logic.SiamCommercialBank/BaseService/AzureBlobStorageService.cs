
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Microsoft.Azure.Storage;
using Microsoft.Azure.Storage.Blob;
using Microsoft.Extensions.Options;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public interface IAzureBlobStorageService
    {
        Task<string> UploadBlobAsync(Uri uri, Stream stream);
        Task<string> UploadBlobAsync(Uri uri, string content);

        Task<string> UploadBlobAsync(string containnerName, string blobName, string localFilePath);
        Task<MemoryStream> DownloadBlobAsync(Uri uri);
        Task<CloudBlockBlob> EnforceCreateIfNotExistsContainnerAsync(Uri uri);

        Task<IEnumerable<Uri>> ListFileAsync(string containnerName, string uri);

        string BlobUrl { get; }
    }

    public class AzureBlobStorageService : IAzureBlobStorageService
    {
        private readonly AzureBlobStorageConfiguration _azureBlobStorageConfiguration;
        private readonly CloudBlobClient _blobClient;
        private readonly CloudStorageAccount _storageAccount;

        public string BlobUrl { get; private set; }

        public AzureBlobStorageService(IOptions<AzureBlobStorageConfiguration> azureBlobStorageConfiguration)
        {
            _azureBlobStorageConfiguration = azureBlobStorageConfiguration.Value ?? throw new ArgumentNullException(nameof(azureBlobStorageConfiguration.Value));

            if (CloudStorageAccount.TryParse(_azureBlobStorageConfiguration.BlobConnectionString, out _storageAccount))
            {
                _blobClient = _storageAccount.CreateCloudBlobClient();
            }
            else
            {
                throw new AzureNotValidException("can't connect azure account storage");
            }

            BlobUrl = _azureBlobStorageConfiguration.BlobUrl;
        }

        public async Task<IEnumerable<Uri>> ListFileAsync(string containnerName, string uri)
        {
            var container = _blobClient.GetContainerReference(containnerName);
            var directory = container.GetDirectoryReference(uri);

            var blobUris = directory.ListBlobs().Select(e => e.Uri).ToList();

            return await Task.FromResult(blobUris);
        }

        private string GetContainerFromUri(Uri uri)
        {
            var items = uri.AbsolutePath.Split("/").Where(x => x != "").ToArray();
            if (items.Length == 0 || string.IsNullOrEmpty(uri.AbsolutePath))
            {
                throw new AzureNotValidException("Can't find container from uri");
            }

            string container = items[0];
            return container;
        }

        public async Task<string> UploadBlobAsync(Uri uri, Stream stream)
        {
            var cloudBlockBlob = await EnforceCreateIfNotExistsContainnerAsync(uri);
            await cloudBlockBlob.UploadFromStreamAsync(stream);

            return cloudBlockBlob.Uri.AbsoluteUri;
        }

        public async Task<string> UploadBlobAsync(Uri uri, string content)
        {
            var cloudBlockBlob = await EnforceCreateIfNotExistsContainnerAsync(uri);
            await cloudBlockBlob.UploadTextAsync(content);

            return cloudBlockBlob.Uri.AbsoluteUri;
        }

        public async Task<string> UploadBlobAsync(string containnerName, string blobName, string localFilePath)
        {
            var container = _blobClient.GetContainerReference(containnerName);
            await container.CreateIfNotExistsAsync();

            var cloudBlockBlob = container.GetBlockBlobReference(blobName);

            await cloudBlockBlob.UploadFromFileAsync(localFilePath);
            return cloudBlockBlob.Uri.AbsoluteUri;
        }

        public async Task<MemoryStream> DownloadBlobAsync(Uri uri)
        {
            var cloudBlockBlob = new CloudBlockBlob(uri, _blobClient.Credentials);
            var isExist = await cloudBlockBlob.ExistsAsync();
            if (!isExist)
                throw new AzureNotValidException($"Could not find { uri }");

            var reader = await cloudBlockBlob.OpenReadAsync();
            var memoryStream = new MemoryStream();
            await reader.CopyToAsync(memoryStream);
            return memoryStream;
        }


        public async Task<CloudBlockBlob> EnforceCreateIfNotExistsContainnerAsync(Uri uri)
        {
            var items = uri.AbsolutePath.Split("/").Where(x => x != "").ToArray();
            if (!items.Any())
            {
                throw new AzureNotValidException("Can't find container from uri");
            }

            string containerName = items[0];

            CloudBlobContainer cloudBlobContainer = _blobClient.GetContainerReference(containerName);
            var result = await cloudBlobContainer.CreateIfNotExistsAsync();
            var blockPath = uri.AbsolutePath.Replace("/" + containerName + "/", "");
            var cloudBlockBlob = cloudBlobContainer.GetBlockBlobReference(blockPath);

            return cloudBlockBlob;
        }
    }
}