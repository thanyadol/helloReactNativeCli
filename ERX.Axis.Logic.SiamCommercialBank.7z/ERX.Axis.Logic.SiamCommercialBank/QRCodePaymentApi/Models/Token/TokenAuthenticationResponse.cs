﻿using System.ComponentModel;
using System.Text.Json.Serialization;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public class TokenAuthenticationResponse
    {
        [JsonIgnore]
        public string Name { get; set; }

        /// <summary>
        /// Generic response codes for http developer api 
        /// </summary>
        [Description("Generic response codes for http developer api")]
        [JsonPropertyName("status")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "status")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ScbBillPayment | PaymentTypes.ScbCreditCardFullAmount | PaymentTypes.ScbCreditCardInstallmentPlan | PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme | PaymentTypes.AlipayWeChatPay)]
        public ScbHttpResponseStatus Status { get; set; }


        /// <summary>
        /// Token data object contains access token and type
        /// </summary>
        [Description("Token data object contains access token and type")]
        [JsonPropertyName("data")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "data")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30)]
        public TokenData Data { get; set; }
    }
}
