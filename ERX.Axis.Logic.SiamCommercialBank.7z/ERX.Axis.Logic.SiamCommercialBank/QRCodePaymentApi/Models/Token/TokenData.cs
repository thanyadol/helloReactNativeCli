﻿using System.ComponentModel;
using System.Text.Json.Serialization;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public class TokenData
    {
        /// <summary>
        /// Access token used to access our system in the user's authority
        /// </summary>
        [Description("Access token used to access our system in the user's authority")]
        [JsonPropertyName("accessToken")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "accessToken")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30)]
        public string AccessToken { get; set; }


        /// <summary>
        /// Prefix of the token to be appended to the access token
        /// </summary>
        [Description("Prefix of the token to be appended to the access token")]
        [JsonPropertyName("tokenType")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "tokenType")] // to cosmos (egress)
        public string TokenType { get; set; }

        /// <summary>
        /// Amount of time until the current access token is expired (in seconds)
        /// </summary>
        [Description("Amount of time until the current access token is expired (in seconds)")]
        [JsonPropertyName("expiresIn")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "expiresIn")] // to cosmos (egress)
        public string ExpiresIn { get; set; }

        /// <summary>
        /// Timestamp (in seconds epoch) of the time the current access token will expire
        /// </summary>
        [Description("Timestamp (in seconds epoch) of the time the current access token will expire")]
        [JsonPropertyName("expiresAt")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "expiresAt")] // to cosmos (egress)
        public string ExpiresAt { get; set; }
    }
}
