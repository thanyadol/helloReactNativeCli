﻿using System.ComponentModel;
using System.Text.Json.Serialization;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public class TokenAuthenticationRequest
    {
        /// <summary>
        ///  The unique key of the application that is accessing data on the user's authority
        /// </summary>
        [Description("The unique key of the application that is accessing data on the user's authority")]
        [JsonPropertyName("applicationKey")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "applicationKey")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme )]
        public string ApplicationKey { get; set; }

        /// <summary>
        /// The secret key associated to the partner's application
        /// </summary>
        [Description("The secret key associated to the partner's application")]
        [JsonPropertyName("applicationSecret")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "applicationSecret")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string ApplicationSecret { get; set; }
    }
}
