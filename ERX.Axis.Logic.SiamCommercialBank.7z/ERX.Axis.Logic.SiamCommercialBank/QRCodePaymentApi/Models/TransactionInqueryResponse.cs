﻿using System.Text.Json.Serialization;
using System.ComponentModel;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public class TransactionInqueryResponse
    {
        /// <summary>
        /// Generic response codes for http developer api 
        /// </summary>
        [Description("Generic response codes for http developer api")]
        [JsonPropertyName("status")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "status")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ScbBillPayment | PaymentTypes.ScbCreditCardFullAmount | PaymentTypes.ScbCreditCardInstallmentPlan | PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme | PaymentTypes.AlipayWeChatPay)]

        public ScbHttpResponseStatus Status { get; set; }

        /// <summary>
        /// Main data response contains the transaction inquery propertiesSlip verification main data response contains the slip verification of a QR 30 type payment data.
        /// </summary>
        [Description("Main data response contains the transaction inquery properties")]
        [JsonPropertyName("data")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "data")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public TransactionInqueryData Data { get; set; }
    }
}
