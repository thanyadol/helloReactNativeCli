﻿using System.Text.Json.Serialization;
using System.ComponentModel;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public class SlipVerificationAccount
    {
        /// <summary>
        /// BANKAC
        /// </summary>
        [Description("BANKAC")]
        [JsonPropertyName("type")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "type")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ScbBillPayment | PaymentTypes.ScbCreditCardFullAmount | PaymentTypes.ScbCreditCardInstallmentPlan | PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme | PaymentTypes.AlipayWeChatPay)]
        public string Type { get; set; }

        /// <summary>
        /// Account Number
        /// </summary>
        [Description("Account Number")]
        [JsonPropertyName("value")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "value")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ScbBillPayment | PaymentTypes.ScbCreditCardFullAmount | PaymentTypes.ScbCreditCardInstallmentPlan | PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme | PaymentTypes.AlipayWeChatPay)]
        public string Value { get; set; }
    }
}
