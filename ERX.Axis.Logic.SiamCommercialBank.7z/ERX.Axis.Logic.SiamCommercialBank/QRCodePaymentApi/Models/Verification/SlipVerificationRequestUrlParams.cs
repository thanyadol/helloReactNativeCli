﻿using System.Text.Json.Serialization;
using System.ComponentModel;


namespace ERX.Axis.Logic.SiamCommercialBank
{
    public class SlipVerificationRequestUrlParams
    {
        /// <summary>
        /// Transaction Slip ID
        /// </summary>
        [Description("Transaction Slip ID")]
        [JsonPropertyName("transRef")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "transRef")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string TransactionRef { get; set; }


        /// <summary>
        /// Sending bank code getting from Bank of Thailand, Use 014 for SCB
        /// </summary>
        [Description("Sending bank code getting from Bank of Thailand, Use 014 for SCB")]
        [JsonPropertyName("sendingBank")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "sendingBank")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string SendingBank { get => "014"; }
    }
}
