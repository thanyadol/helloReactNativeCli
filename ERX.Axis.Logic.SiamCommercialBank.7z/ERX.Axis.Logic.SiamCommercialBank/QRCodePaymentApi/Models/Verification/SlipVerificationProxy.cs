﻿using System.Text.Json.Serialization;
using System.ComponentModel;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public class SlipVerificationProxy
    {
        /// <summary>
        /// BILLERID
        /// </summary>
        [Description("BILLERID")]
        [JsonPropertyName("type")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "type")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ScbBillPayment | PaymentTypes.ScbCreditCardFullAmount | PaymentTypes.ScbCreditCardInstallmentPlan | PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme | PaymentTypes.AlipayWeChatPay)]
        public string Type { get; set; }

        /// <summary>
        /// Biller ID
        /// </summary>
        [Description("Biller ID")]
        [JsonPropertyName("value")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "value")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ScbBillPayment | PaymentTypes.ScbCreditCardFullAmount | PaymentTypes.ScbCreditCardInstallmentPlan | PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme | PaymentTypes.AlipayWeChatPay)]
        public string Value { get; set; }
    }
}
