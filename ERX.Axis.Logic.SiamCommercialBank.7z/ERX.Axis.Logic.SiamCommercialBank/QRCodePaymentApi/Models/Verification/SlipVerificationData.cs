﻿using System.Text.Json.Serialization;
using System.ComponentModel;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public class SlipVerificationData
    {
        /// <summary>
        /// Transaction Slip ID
        /// </summary>
        [Description("Transaction Slip ID")]
        [JsonPropertyName("transRef")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "transRef")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string TransRef { get; set; }

        /// <summary>
        /// Sender Bank Code
        /// </summary>
        [Description("Sender Bank Code")]
        [JsonPropertyName("sendingBank")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "sendingBank")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string SendingBank { get; set; }


        /// <summary>
        /// Receiving  Bank Code
        /// </summary>
        [Description("Receiving  Bank Code")]
        [JsonPropertyName("receivingBank")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "receivingBank")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string ReceivingBank { get; set; }

        /// <summary>
        /// Transaction date
        /// </summary>
        [Description("Transaction date format --> ")]
        [JsonPropertyName("transDate")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "transDate")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string TransDate { get; set; }

        /// <summary>
        /// Transaction time
        /// </summary>
        [Description("Transaction time format --> ")]
        [JsonPropertyName("transTime")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "transTime")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string TransTime { get; set; }

        /// <summary>
        /// See SlipVerificationSender
        /// </summary>
        [Description("See SlipVerificationSender")]
        [JsonPropertyName("sender")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "sender")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public SlipVerificationSender Sender { get; set; }


        /// <summary>
        /// See SlipVerificationReciever
        /// </summary>
        [Description("See SlipVerificationReciever")]
        [JsonPropertyName("receiver")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "receiver")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public SlipVerificationReciever Receiver { get; set; }

        /// <summary>
        /// Transaction Amount
        /// </summary>
        [Description("Transaction Amount")]
        [JsonPropertyName("amount")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "amount")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string Amount { get; set; }


        /// <summary>
        /// Local Amount
        /// </summary>
        [Description("Local Amount")]
        [JsonPropertyName("paidLocalAmount")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "paidLocalAmount")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string PaidLocalAmount { get; set; }

        /// <summary>
        /// Local Currency
        /// </summary>
        [Description("Local Currency")]
        [JsonPropertyName("paidLocalCurrency")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "paidLocalCurrency")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string PaidLocalCurrency { get; set; }


        /// <summary>
        /// Country Code
        /// </summary>
        [Description("Country Code")]
        [JsonPropertyName("countryCode")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "countryCode")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string CountryCode { get; set; }
        /// <summary>
        /// Reference number required for the relevant payment methods.
        /// Length: up to 20
        /// Data Type: [AZ09] English capital letter and number only.
        /// </summary>
        [Description("Reference number required for the relevant payment methods.")]
        [JsonPropertyName("ref1")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "ref1")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30)]
        public string Ref1 { get; set; }

        /// <summary>
        /// Reference number required for the relevant payment methods.
        /// Required if: Supporting Reference field under merchant profile of application is set to Two references.
        /// Length: up to 20
        /// Data Type: [AZ09] English capital letter and number only.
        /// </summary>
        [Description("Reference number required for the relevant payment methods.")]
        [JsonPropertyName("ref2")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "ref2")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30)]
        public string Ref2 { get; set; }


        /// <summary>
        /// Reference number required for the relevant payment methods to identify endpoint for receiving payment confirmation.
        /// Format: Reference 3 Prefix + (value), example: SCB1234
        /// Note: Partners can get the Reference 3 Prefix and set the Payment Confirmation Endpoint on merchant profile of their application.
        /// Length: up to 20
        /// Data Type: [AZ09] English capital letter and number only.
        /// </summary>
        [Description("Reference number required for the relevant payment methods to identify endpoint for receiving payment confirmation")]
        [JsonPropertyName("ref3")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "ref3")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30)]
        public string Ref3 { get; set; }
    }
}
