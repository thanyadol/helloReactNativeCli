﻿using System.Text.Json.Serialization;
using System.ComponentModel;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public class SlipVerificationSender
    {
        /// <summary>
        /// Display Name of payer
        /// </summary>
        [Description("Display Name of payer")]
        [JsonPropertyName("displayName")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "displayName")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string DisplayName { get; set; }


        /// <summary>
        /// Name of payer
        /// </summary>
        [Description("Name of payer")]
        [JsonPropertyName("name")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "name")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string Name { get; set; }


        /// <summary>
        ///  please see SlipVerificationProxy
        /// </summary>
        [Description("see SlipVerificationProxy")]
        [JsonPropertyName("proxy")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "proxy")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public SlipVerificationProxy Proxy { get; set; }


        /// <summary>
        /// please see SlipVerificationAccount
        /// </summary>
        [Description("")]
        [JsonPropertyName("please see SlipVerificationAccount")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "account")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)] public SlipVerificationAccount Account { get; set; }
    }
}
