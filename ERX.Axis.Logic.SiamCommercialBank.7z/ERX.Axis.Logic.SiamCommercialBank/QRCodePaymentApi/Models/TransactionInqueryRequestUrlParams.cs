﻿using System.Text.Json.Serialization;
using System.ComponentModel;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public class TransactionInqueryRequestUrlParams
    {
        /// <summary>
        /// Required Event code of payment type
        /// Event code of payment type
        /// Possible value:
        /// 00300100 - Thai QR Code Tag 30 (C Scan B)
        /// 00300104 - My Prompt QR(B Scan C)
        /// </summary>
        [Description("Required Event code of payment type")]
        [JsonPropertyName("eventCode")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "eventCode")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string EventCode { get => "00300100"; }


        /// <summary>
        /// Date of transaction.
        /// Format: yyyy-MM-dd
        /// Example: 2019-10-28
        /// </summary>
        [Description("Date of transaction")]
        [JsonPropertyName("transactionDate")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "transactionDate")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string TransactionDate { get; set; }


        /// <summary>
        /// Conditional Biller ID from partner
        /// Required if: eventCode = 00300100
        /// </summary>
        [Description(" Conditional Biller ID from partner")]
        [JsonPropertyName("billerId")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "billerId")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string BillerId { get; set; }


        /// <summary>
        /// Conditional Reference Number 1 , up to 20 characters
        /// Required if: eventCode = 00300100
        /// </summary>
        [Description(" Conditional Biller ID from partner")]
        [JsonPropertyName("reference1")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "reference1")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string Reference1 { get; set; }


        /// <summary>
        /// Conditional Reference Number 2 , up to 20 characters
        /// Required if: eventCode = 00300100
        /// </summary>
        [Description(" Conditional Biller ID from partner")]
        [JsonPropertyName("reference2")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "reference2")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string Reference2 { get; set; }

        /// <summary>
        /// Transaction ID from a partner
        /// Required if: eventCode = 00300104
        /// </summary>
        [Description("Transaction ID from a partner")]
        [JsonPropertyName("partnerTransactionId")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "partnerTransactionId")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string PartnerTransactionId { get; set; }

        /// <summary>
        /// Transaction Amount
        /// Optional
        /// </summary>
        [Description("Transaction Amount")]
        [JsonPropertyName("amount")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "amount")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string Amount { get; set; }
    }
}
