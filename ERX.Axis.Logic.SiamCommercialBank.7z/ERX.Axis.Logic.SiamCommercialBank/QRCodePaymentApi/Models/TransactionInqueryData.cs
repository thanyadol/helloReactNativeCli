﻿using System.Text.Json.Serialization;
using System.ComponentModel;
using System;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public class TransactionInqueryData
    {
        /// <summary>
        /// Event code of payment type
        /// Possible value:
        /// 00300100 - Thai QR Code Tag 30 (C Scan B)
        /// 00300104 - My Prompt QR(B Scan C)
        /// </summary>
        [Description("Required Event code of payment type")]
        [JsonPropertyName("eventCode")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "eventCode")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string EventCode { get; set; }

        /// <summary>
       	/// Transaction Type.
        /// Possible value:
        /// - Domestic Transfers
        /// - International Transfers
        /// - ExpressPayment Transfers
        /// </summary>
        [Description(" Transaction Type")]
        [JsonPropertyName("transactionType")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "transactionType")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string TransactionType { get; set; }

        /// <summary>
        /// Reverse Flag for refund transaction only
        /// R indicate transaction is refunded
        /// </summary>
        [Description(" Reverse Flag for refund transaction only")]
        [JsonPropertyName("reverseFlag")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "reverseFlag")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string ReverseFlag { get; set; }


        /// <summary>
        /// Promptpay proxy of payee either 12, 13 or 15 digit depending on the type of proxy:
        ///    +66891228788 - MSISDN
        ///    1234567890123 - NATID
        ///    123456789012345 - BILLERID(13 digit TaxID + 2 digit suffix)
        ///    014123456789012 - EWALLETID
        /// </summary>
        [Description("Promptpay proxy of payee either 12, 13 or 15 digit depending on the type of proxy")]
        [JsonPropertyName("payeeProxyId")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "payeeProxyId")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string PayeeProxyId { get; set; }

        /// <summary>
        /// Define type of proxy.
        ///     MSISDN - Mobile number
        ///     NATID - Citizen ID, Tax ID, Government Customer ID
        ///     BILLERID - Biller ID for Promptpay Bill Pay method
        ///     EWALLETID - E-Wallet ID
        /// </summary>
        [Description("Define type of proxy.")]
        [JsonPropertyName("payeeProxyType")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "payeeProxyType")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string PayeeProxyType { get; set; }


        /// <summary>
        /// Account number linked with the proxy ID
        /// </summary>
        [Description("Account number linked with the proxy ID")]
        [JsonPropertyName("payeeAccountNumber")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "payeeAccountNumber")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string PayeeAccountNumber { get; set; }


        /// <summary>
        ///  Display Name registered with PromptPay (Any ID/ITMX)
        /// </summary>
        [Description("Display Name registered with PromptPay (Any ID/ITMX)")]
        [JsonPropertyName("payeeName")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "payeeName")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string PayeeName { get; set; }


        /// <summary>
        /// Optional but will be available in case that payer presents QR code to payee:
        ///    +66891228788 - MSISDN
        ///    1234567890123 - NATID
        ///    123456789012345 - BILLERID(13 digit TaxID + 2 digit suffix)
        ///    014123456789012 - EWALLETID
        /// </summary>
        [Description("Optional but will be available in case that payer presents QR code to payee")]
        [JsonPropertyName("payerProxyId")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "payerProxyId")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string PayerProxyId { get; set; }

        /// <summary>
        /// Optional but will be available in case that payer presents QR code to payee:
        ///     MSISDN - Mobile number
        ///     NATID - Citizen ID, Tax ID, Government Customer ID
        ///     BILLERID - Biller ID for Promptpay Bill Pay method
        ///     EWALLETID - E-Wallet ID
        /// </summary>
        [Description("Optional but will be available in case that payer presents QR code to payee")]
        [JsonPropertyName("payerProxyType")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "payerProxyType")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string PayerProxyType { get; set; }

        /// <summary>
        /// Payer's Account Number
        /// </summary>
        [Description("Payer's Account Number")]
        [JsonPropertyName("payerAccountNumber")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "payerAccountNumber")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string PayerAccountNumber { get; set; }

        /// <summary>
        /// Name of the Payer (Sender Name)
        /// </summary>
        [Description("Name of the Payer (Sender Name)")]
        [JsonPropertyName("payerName")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "payerName")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string PayerName { get; set; }



        /// <summary>
        /// 3-digits bank code of payer (SCB’s code is 014. Refer to appendix for complete bank code list)
        /// </summary>
        [Description("3-digits bank code of payer (SCB’s code is 014. Refer to appendix for complete bank code list)")]
        [JsonPropertyName("sendingBankCode")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "sendingBankCode")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string SendingBankCode { get; set; }


        /// <summary>
        /// 3-digits bank code of payer (SCB’s code is 014. Refer to appendix for complete bank code list)
        /// </summary>
        [Description("3-digits bank code of payer (SCB’s code is 014. Refer to appendix for complete bank code list)")]
        [JsonPropertyName("receivingBankCode")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "receivingBankCode")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string ReceivingBankCode { get; set; }


        /// <summary>
        /// Transaction Amount
        /// </summary>
        [Description("Transaction Amount")]
        [JsonPropertyName("amount")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "amount")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string Amount { get; set; }

        /// <summary>
        /// SCB Transaction ID
        /// </summary>
        [Description("SCB Transaction ID")]
        [JsonPropertyName("transactionId")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "transactionId")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string TransactionId { get; set; }


        /// <summary>
        ///  Slip number that appears on EASY application or Payment Reference from sender, up to 25 characters
        /// </summary>
        [Description("Slip number that appears on EASY application or Payment Reference from sender, up to 25 characters")]
        [JsonPropertyName("fastEasySlipNumber")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "fastEasySlipNumber")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string FastEasySlipNumber { get; set; }


        /// <summary>
        /// Date and time stamp (same as stamp on front-end application)
        /// Format: yyyy-MM-ddThh:mm:ss.sss±hh:mm
        /// 2017-03-13T09:00:00.000+07:00
        /// </summary>
        [Description("Date and time stamp (same as stamp on front-end application)")]
        [JsonPropertyName("transactionDateandTime")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "transactionDateandTime")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public DateTime TransactionDateandTime { get; set; }


        /// <summary>
        /// Reference 1 code from acquirer
        /// </summary>
        [Description("Reference 1 code from acquirer")]
        [JsonPropertyName("billPaymentRef1")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "billPaymentRef1")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string BillPaymentRef1 { get; set; }


        /// <summary>
        /// Reference 2 code from acquirer
        /// </summary>
        [Description("Reference 2 code from acquirer")]
        [JsonPropertyName("billPaymentRef2")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "billPaymentRef2")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string BillPaymentRef2 { get; set; }


        /// <summary>
        /// Reference 3 code from acquirer
        /// </summary>
        [Description("Reference 3 code from acquirer")]
        [JsonPropertyName("billPaymentRef3")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "billPaymentRef3")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string BillPaymentRef3 { get; set; }


        /// <summary>
        /// Code to define currency for transaction based on ISO 4217. Thai Baht is ‘764’
        /// </summary>
        [Description("Code to define currency for transaction based on ISO 4217. Thai Baht is ‘764’")]
        [JsonPropertyName("currencyCode")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "currencyCode")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string CurrencyCode { get; set; }


        /// <summary>
        /// Amount of money to be moved between the debtor and creditor, expressed in the currency of the debtor's account
        /// </summary>
        [Description("Amount of money to be moved between the debtor and creditor, expressed in the currency of the debtor's account")]
        [JsonPropertyName("equivalentAmount")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "equivalentAmount")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string EquivalentAmount { get; set; }


        /// <summary>
        /// Equivalent currency Code as per registered ISO 4217
        /// </summary>
        [Description("Equivalent currency Code as per registered ISO 4217")]
        [JsonPropertyName("equivalentCurrencyCode")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "equivalentCurrencyCode")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string EquivalentCurrencyCode { get; set; }


        /// <summary>
        /// Contains details of the exchange rate, used to convert from one currency to another
        /// </summary>
        [Description("Contains details of the exchange rate, used to convert from one currency to another")]
        [JsonPropertyName("exchangeRate")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "exchangeRate")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string ExchangeRate { get; set; }


        /// <summary>
        /// Transaction channel name
        /// </summary>
        [Description("Transaction channel name")]
        [JsonPropertyName("channelCode")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "channelCode")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string ChannelCode { get; set; }


        /// <summary>
        /// Transaction ID from a partner for My Prompt QR (B Scan C)
        /// </summary>
        [Description("Transaction ID from a partner for My Prompt QR (B Scan C)")]
        [JsonPropertyName("partnerTransactionId")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "partnerTransactionId")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string PartnerTransactionId { get; set; }


        /// <summary>
        /// Reserve for future use
        /// </summary>
        [Description("Reserve for future use")]
        [JsonPropertyName("tepaCode")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "tepaCode")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string TepaCode { get; set; }
    }
}
