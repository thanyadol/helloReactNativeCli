﻿using System.Text.Json.Serialization;
using System.ComponentModel;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public class ScbHttpResponseStatus
    {
        /// <summary>
        /// Status “1000” is Success
        /// </summary>
        [Description("Status “1000” is Success")]
        [JsonPropertyName("code")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "code")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30)]
        public string Code { get; set; }

        /// <summary>
        /// Description text to explain the code, e.g. Success
        /// </summary>
        [Description(" Description text to explain the code, e.g. Success")]
        [JsonPropertyName("description")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "description")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30)]
        public string Description { get; set; }

    }
}
