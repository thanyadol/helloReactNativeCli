﻿using System;
using System.ComponentModel;
using System.Text.Json.Serialization;


namespace ERX.Axis.Logic.SiamCommercialBank
{
    public class QRCodePaymentRequest : Entity<Guid>
    {
        public QRCodePaymentRequest()
        {
            this.ContainerName = "thailand-siam-commerical-qr-code-payment";
        }


        /// <summary>
        /// Customer Name from ONE CIRCLE System
        /// </summary>
        /*[Description("Customer Name from ONE CIRCLE System")]
        [JsonPropertyName("customerName")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "customerName")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string CustomerName { get; set; }


        /// <summary>
        /// Customer Bank Account
        /// </summary>
        [Description("Customer Bank Account")]
        [JsonPropertyName("customerBankAccount")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "customerBankAccount")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string CustomerBankAccount { get; set; }*/

        /// <summary>
        /// Amount of transaction with the length up to 13 characters including "." e.g. 100, 100.00
        /// </summary>
        [Description("Amount of transaction with the length up to 13 characters including . e.g. 100, 100.00")]
        [JsonPropertyName("amount")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "amount")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public decimal Amount { get; set; }

        [JsonIgnore]
        public string BillId { get; set; }

        [JsonIgnore]
        public string CustomerId { get; set; }

        [JsonIgnore]
        public string TicketId { get; set; }

        [JsonIgnore]
        public string Prefix { get; set; }


        [JsonIgnore]
        public string Token { get; set; }

        /// <summary>
        /// Type of QR Code to request for generate QR code.
        ///    • “PP”: QR 30
        ///    • “CS”: QR CS
        //     • “PPCS”: QR 30 and QR CS
        /// </summary>
        [Description("Type of QR Code to request for generate QR code")]
        [JsonPropertyName("qrType")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "qrType")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string QrType { get; set; }

        /// <summary>
        /// PromptPay Type for QR 30
        //  Value: BILLERID
        /// </summary>
        [Description("PromptPay Type for QR 30")]
        [JsonPropertyName("ppType")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "ppType")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30)]
        public static string PPType { get => "BILLERID"; }

        /// <summary>
        /// Biller ID
        /// Note: Partners can get on merchant profile of their application.
        /// Length: 15
        /// </summary>
        [Description("Biller ID")]
        [JsonPropertyName("ppId")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "ppId")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30)]
        public string PPId { get; set; }


        /// <summary>
        /// Reference number required for the relevant payment methods.
        /// Length: up to 20
        /// Data Type: [AZ09] English capital letter and number only.
        /// </summary>
        [Description("Reference number required for the relevant payment methods.")]
        [JsonPropertyName("ref1")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "ref1")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30)]
        public string Ref1 { get; set; }

        /// <summary>
        /// Reference number required for the relevant payment methods.
        /// Required if: Supporting Reference field under merchant profile of application is set to Two references.
        /// Length: up to 20
        /// Data Type: [AZ09] English capital letter and number only.
        /// </summary>
        [Description("Reference number required for the relevant payment methods.")]
        [JsonPropertyName("ref2")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "ref2")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30)]
        public string Ref2 { get; set; }


        /// <summary>
        /// Reference number required for the relevant payment methods to identify endpoint for receiving payment confirmation.
        /// Format: Reference 3 Prefix + (value), example: SCB1234
        /// Note: Partners can get the Reference 3 Prefix and set the Payment Confirmation Endpoint on merchant profile of their application.
        /// Length: up to 20
        /// Data Type: [AZ09] English capital letter and number only.
        /// </summary>
        [Description("Reference number required for the relevant payment methods to identify endpoint for receiving payment confirmation")]
        [JsonPropertyName("ref3")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "ref3")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30)]
        public string Ref3 { get; set; }

        /// <summary>
        /// Expiry date and time of QR Code 
        /// Format : yyyy-MM-dd HH:mm:ss
        /// </summary>
        [Description("Expiry date and time of QR Code")]
        [JsonPropertyName("expiryDate")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "expiryDate")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30)]
        public string ExpiryDate { get; set; }

        /// <summary>
        /// Number of times to allow user scanning for payment
        /// Data Type: [09] number only.
        /// </summary>
        [Description("Number of times to allow user scanning for payment")]
        [JsonPropertyName("numberOfTimes")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "numberOfTimes")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30)]
        public int NumberOfTimes { get; set; }
    }
}
