﻿
using System.Text.Json.Serialization;
using System.ComponentModel;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public class QRCodePaymentResponse
    {
        /// <summary>
        /// Generic response codes for http developer api 
        /// </summary>
        [Description("Generic response codes for http developer api")]
        [JsonPropertyName("status")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "status")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ScbBillPayment | PaymentTypes.ScbCreditCardFullAmount | PaymentTypes.ScbCreditCardInstallmentPlan | PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme | PaymentTypes.AlipayWeChatPay)]
        public ScbHttpResponseStatus Status { get; set; }

        /// <summary>
        /// Qr code data object contains base64 qr image nad rawdata
        /// </summary>
        [Description("Qr code data object contains base64 qr image nad rawdata")]
        [JsonPropertyName("data")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "data")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ScbBillPayment | PaymentTypes.ScbCreditCardFullAmount | PaymentTypes.ScbCreditCardInstallmentPlan | PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme | PaymentTypes.AlipayWeChatPay)]
        public QRCodeData Data { get; set; }
    }
}
