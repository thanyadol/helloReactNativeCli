﻿using System.Text.Json.Serialization;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public class PaymentConfirmationResponse
    {
        /// <summary>
        /// Fix : 00
        /// </summary>
        [JsonPropertyName("resCode")] // to http response (egress)
        public static string ResponseCode { get => "00"; }

        /// <summary>
        /// Fix : success
        /// </summary>
        [JsonPropertyName("resDesc")] // to http response (egress)
        public static string ResponseDescription { get => "success"; }

        /// <summary>
        /// Echo "transactionId" value from Payment Confirmation
        /// </summary>
        [JsonPropertyName("transactionId")] // to http response (egress)
        public string TransactionId { get; set; }

        /// <summary>
        /// Optional
        /// </summary>
        [JsonPropertyName("confirmId")] // to http response (egress)
        public string ConfirmationId { get; set; }
    }
}
