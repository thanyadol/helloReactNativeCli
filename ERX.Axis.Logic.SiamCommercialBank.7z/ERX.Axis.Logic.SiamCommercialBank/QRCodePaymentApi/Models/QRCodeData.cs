﻿using System.ComponentModel;
using System.Text.Json.Serialization;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public class QRCodeData
    {
        [JsonIgnore]
        public string AccessToken { get; set; }

        /// <summary>
        /// Base64 Image of QR
        /// </summary>
        [Description("Base64 Image of QR")]
        [JsonPropertyName("qrImage")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "qrImage")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string QrImage { get; set; }

        /// <summary>
        /// QR Data
        /// </summary>
        [Description("QR Data")]
        [JsonPropertyName("qrRawData")] // from http request (ingress)
        [Newtonsoft.Json.JsonProperty(PropertyName = "qrRawData")] // to cosmos (egress)
        [PaymentTypes(PaymentTypes.ThaiQRCodeTag30 | PaymentTypes.QRCardScheme)]
        public string QrRawData { get; set; }


        [JsonIgnore]
        public string TokenType { get; set; }

        [JsonIgnore]
        public string ExpiresIn { get; set; }

        [JsonIgnore]
        public string ExpiresAt { get; set; }


        [JsonIgnore]
        public string ExpiryDate { get; set; }

        [JsonIgnore]
        public int NumberOfTimes { get; set; }

    }

}
