﻿using System;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public class PaymentTypesAttribute : Attribute
    {
        public PaymentTypesAttribute(PaymentTypes flags)
        {
            this.Value = flags;
        }

        public PaymentTypes Value { get; }
    }
}
