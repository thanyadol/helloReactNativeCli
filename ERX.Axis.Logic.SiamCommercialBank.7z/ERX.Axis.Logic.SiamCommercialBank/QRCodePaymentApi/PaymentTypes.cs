﻿using System;
using System.ComponentModel;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    [Flags]
    public enum PaymentTypes
    {
        /// <summary>
        /// Thai QR Code Tag 30 <br />
        /// <br />
        /// This supports the use of a customer's savings account as source of funds for payment. 
        /// This type of QR payment is supported by most of the major Thai banks.
        /// </summary>
        [Description("Thai QR Code Tag 30")]
        ThaiQRCodeTag30 = 1,

        /// <summary>
        /// QR Card Scheme <br />
        /// <br />
        /// This supports the use of credit cards as a source of funds for payment.
        /// Currently, QR CS is supported by VISA and Mastercard.
        /// </summary>
        [Description("QR Card Scheme")]
        QRCardScheme = 2,

        /// <summary>
        /// SCB EASY App payment with Bill Payment (BP) type
        /// </summary>
        [Description("SCB EASY App payment with Bill Payment (BP) type")]
        ScbBillPayment = 4,

        /// <summary>
        /// SCB EASY App payment with Credit Card Full Amount (CCFA) type
        /// </summary>
        [Description("SCB EASY App payment with Credit Card Full Amount (CCFA) type")]
        ScbCreditCardFullAmount = 8,

        /// <summary>
        /// SCB EASY App payment with Credit Card Installment Payment Plan (CCIPP) type
        /// </summary>
        [Description("SCB EASY App payment with Credit Card Installment Payment Plan (CCIPP) type")]
        ScbCreditCardInstallmentPlan = 16,

        /// <summary>
        /// Alipay / WeChatPay
        /// </summary>
        [Description("Alipay / WeChatPay")]
        AlipayWeChatPay = 32
    }
}
