﻿using System;
using System.Text.Json.Serialization;
using System.ComponentModel;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    /// <summary>
    /// Type of QR Code to request for generate QR code.
    /// <summary>
    public enum QRCodeType
    {
        /// <summary>
        /// PP
        /// Thai QR Code Tag 30 (QR 30) - This is to support merchant-presented mode (C scan B) QR codes, where the customer scans the merchant’s QR code and pays using either the current or savings account as the source of funds. This type of QR payment is supported by most of the major Thai banks.
        /// </summary>
        [Description("Thai QR Code")]
        ThaiQRCode,

        /// <summary>
        /// CS
        /// QR Card Scheme (QR CS) - This is to support merchant-presented mode (C scan B) QR codes, where the customer scans the merchant’s QR code and pays using credit cards as the source of funds. Currently, QR CS is supported by VISA and Mastercard, making it compatible internationally.
        /// </summary>
        [Description("Qr Card Scheme")]
        QrCardScheme,

        /// <summary>
        /// PP and CS
        /// </summary>
        [Description("ThaiQRCode and QrCardScheme")]
        ThaiQRCodeAndQrCardScheme
    }
}
