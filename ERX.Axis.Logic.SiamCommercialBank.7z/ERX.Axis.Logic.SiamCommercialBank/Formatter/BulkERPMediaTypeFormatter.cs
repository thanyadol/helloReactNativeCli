﻿
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;

namespace  ERX.Axis.Logic.SiamCommercialBank
{
    public static class BulkERPMediaTypeFormatter
    {
        // Write the response
        public static Task<String> WriteResponseBodyAsync(DomesticPayment context)
        {
            StringBuilder csv = new StringBuilder();

            //header
            Type type = context.Header.GetType();

            //get custom json attributes
            var attributes = new List<string>();
            foreach (var propertyInfo in type.GetProperties())
            {
                var attribute = (ScbLayoutAttribute)propertyInfo.GetCustomAttribute(typeof(ScbLayoutAttribute));
                if (attribute == null) continue;

                string name = propertyInfo.Name;
                var value = propertyInfo.GetValue(context.Header, null).ToString();

                //replace null vaue with digit
                if (String.IsNullOrEmpty(value))
                {
                    value = new string(' ', attribute.Length);
                }
                else
                {
                    switch (attribute.Type)
                    {
                        case 'C':
                            value = value.PadRight(attribute.Length, ' ');
                            break;
                        case 'N':
                        case 'A':
                            value = value.PadLeft(attribute.Length, '0');
                            break;
                        case 'D':
                        case 'T':
                        default:
                            //no op
                            break;
                    }
                }

                attributes.Add(value);
            }

            csv.AppendLine(
                string.Join<string>(
                    "",
                    attributes.Select(c => c)
                )
            );

            //debit detail
            foreach (var obj in context.DebitDetails)
            {
                //get value and scb layout
                var vals = obj.GetType().GetProperties()
                    .Where(pp => pp.GetCustomAttribute(typeof(ScbLayoutAttribute)) != null)
                    .Select(
                        pi => new ValueLayout()
                        {
                            Attribute = (ScbLayoutAttribute)pi.GetCustomAttribute(typeof(ScbLayoutAttribute)),
                            Value = pi.GetValue(obj, null)?.ToString()
                        }
                    );

                List<string> values = new List<string>();
                foreach (var val in vals)
                {
                    var tmpval = val.Value;

                    if (!String.IsNullOrEmpty(val.Value))
                    {
                        //Check if the value contans a comma and place it in quotes if so
                        if (tmpval.Contains(","))
                            tmpval = string.Concat("\"", tmpval, "\"");

                        //Replace any \r or \n special characters from a new line with a space
                        tmpval = tmpval.Replace("\r", " ", StringComparison.InvariantCultureIgnoreCase);
                        tmpval = tmpval.Replace("\n", " ", StringComparison.InvariantCultureIgnoreCase);

                        switch (val.Attribute.Type)
                        {
                            case 'C':
                                tmpval = tmpval.PadRight(val.Attribute.Length, ' ');
                                break;
                            case 'N':
                            case 'A':
                                tmpval = tmpval.PadLeft(val.Attribute.Length, '0');
                                break;
                            case 'D':
                            case 'T':
                            default:
                                //no op
                                break;
                        }
                    }
                    else { tmpval = new string(' ', val.Attribute.Length); }

                    values.Add(tmpval);
                }

                csv.AppendLine(string.Join("", values));
            }

            //credit detail
            foreach (var obj in context.CreditDetails)
            {
                var vals = obj.GetType().GetProperties()
                    .Where(pp => pp.GetCustomAttribute(typeof(ScbLayoutAttribute)) != null)
                     .Select(
                        pi => new ValueLayout()
                        {
                            Attribute = (ScbLayoutAttribute)pi.GetCustomAttribute(typeof(ScbLayoutAttribute)),
                            Value = pi.GetValue(obj, null)?.ToString()

                        }
                    );

                List<string> values = new List<string>();
                foreach (var val in vals)
                {
                    var tmpval = val.Value;

                    if (!String.IsNullOrEmpty(val.Value))
                    {
                        //Check if the value contans a comma and place it in quotes if so
                        if (tmpval.Contains(","))
                            tmpval = string.Concat("\"", tmpval, "\"");

                        //Replace any \r or \n special characters from a new line with a space
                        tmpval = tmpval.Replace("\r", " ", StringComparison.InvariantCultureIgnoreCase);
                        tmpval = tmpval.Replace("\n", " ", StringComparison.InvariantCultureIgnoreCase);
                    }
                    else { tmpval = new string(' ', val.Attribute.Length); }

                    switch (val.Attribute.Type)
                    {
                        case 'C':
                            tmpval = tmpval.PadRight(val.Attribute.Length, ' ');
                            break;
                        case 'N':
                        case 'A':
                            tmpval = tmpval.PadLeft(val.Attribute.Length, '0');
                            break;
                        case 'D':
                        case 'T':
                        default:
                            //no op
                            break;
                    }

                    values.Add(tmpval);
                }

                csv.AppendLine(string.Join("", values));

                //payee
                //get and remove
                var payee = context.PayeeDetails.Where(c => c.ReferenceCreditSequenceNumber == obj.CreditSequenceNumber).FirstOrDefault();
                context.PayeeDetails = context.PayeeDetails.Where(c => c.ReferenceCreditSequenceNumber != obj.CreditSequenceNumber).ToList();

                vals = payee.GetType().GetProperties()
                    .Where(pp => pp.GetCustomAttribute(typeof(ScbLayoutAttribute)) != null)
                     .Select(
                        pi => new ValueLayout()
                        {
                            Attribute = (ScbLayoutAttribute)pi.GetCustomAttribute(typeof(ScbLayoutAttribute)),
                            Value = pi.GetValue(payee, null)?.ToString()

                        }
                    );

                values = new List<string>();
                foreach (var val in vals)
                {
                    var tmpval = val.Value;

                    if (!String.IsNullOrEmpty(val.Value))
                    {
                        //Check if the value contans a comma and place it in quotes if so
                        if (tmpval.Contains(","))
                            tmpval = string.Concat("\"", tmpval, "\"");

                        //Replace any \r or \n special characters from a new line with a space
                        tmpval = tmpval.Replace("\r", " ", StringComparison.InvariantCultureIgnoreCase);
                        tmpval = tmpval.Replace("\n", " ", StringComparison.InvariantCultureIgnoreCase);
                    }
                    else { tmpval = new string(' ', val.Attribute.Length); }

                    switch (val.Attribute.Type)
                    {
                        case 'C':
                            tmpval = tmpval.PadRight(val.Attribute.Length, ' ');
                            break;
                        case 'N':
                        case 'A':
                            tmpval = tmpval.PadLeft(val.Attribute.Length, '0');
                            break;
                        case 'D':
                        case 'T':
                        default:
                            //no op
                            break;
                    }

                    values.Add(tmpval);
                }

                csv.AppendLine(string.Join("", values));
            }

            //trailer
            Type _type = context.Trailer.GetType();

            //get custom json attributes
            var _attributes = new List<string>();
            foreach (var propertyInfo in _type.GetProperties())
            {
                var attribute = (ScbLayoutAttribute)propertyInfo.GetCustomAttribute(typeof(ScbLayoutAttribute));
                if (attribute == null) continue;

                string name = propertyInfo.Name;
                var value = propertyInfo.GetValue(context.Trailer, null).ToString();

                //replace null vaue with digit
                if (String.IsNullOrEmpty(value))
                {
                    value = new string(' ', attribute.Length);
                }
                else
                {
                    switch (attribute.Type)
                    {
                        case 'C':
                            value = value.PadRight(attribute.Length, ' ');
                            break;
                        case 'N':
                        case 'A':
                            value = value.PadLeft(attribute.Length, '0');
                            break;
                        case 'D':
                        case 'T':
                        default:
                            //no op
                            break;
                    }
                }

                _attributes.Add(value);
            }

            csv.AppendLine(
                string.Join<string>(
                    "",
                    _attributes.Select(c => c)
                )
            );

            return Task.FromResult(csv.ToString());
        }
    }

    public class ValueLayout
    {
        public ScbLayoutAttribute Attribute { get; set; }
        public string Value { get; set; }
    }
}