﻿using System;
using System.Configuration;
using System.Linq;
using System.Text;
using Microsoft.Azure.Cosmos.Fluent;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public static class IServiceCollectionExtension
    {

        public static IServiceCollection AddScbHttpDeveloperApi(this IServiceCollection services)
        {

            services
                .AddOptions<ScbHttpConfiguration>()
                .Configure<IConfiguration>((settings, configuration) =>
                {
                    configuration
                    .GetSection("ScbApi")
                    .Bind(settings);
                });

            //Token
            services.AddHttpClient<IHttpService<TokenAuthenticationRequest, TokenAuthenticationResponse>,
                                                HttpService<TokenAuthenticationRequest, TokenAuthenticationResponse>>()
                                                    .SetHandlerLifetime(TimeSpan.FromMinutes(5));

            //QRCode
            services.AddHttpClient<IHttpService<QRCodePaymentRequest, QRCodePaymentResponse>, HttpService<QRCodePaymentRequest, QRCodePaymentResponse>>()
                    .SetHandlerLifetime(TimeSpan.FromMinutes(5));

            //Transaction
            services.AddHttpClient<IHttpService<TransactionInqueryRequestUrlParams, TransactionInqueryResponse>, HttpService<TransactionInqueryRequestUrlParams, TransactionInqueryResponse>>()
                    .SetHandlerLifetime(TimeSpan.FromMinutes(5));

            //Payment
            services.AddHttpClient<IHttpService<SlipVerificationRequestUrlParams, SlipVerificationResponse>, HttpService<SlipVerificationRequestUrlParams, SlipVerificationResponse>>()
            .SetHandlerLifetime(TimeSpan.FromMinutes(5));

            //repo
            services.AddTransient<IRepository<Guid, QRCodePaymentRequest>, Repository<Guid, QRCodePaymentRequest>>();
            services.AddTransient<IScbHttpService, ScbHttpService>();

            return services;
        }

        public static IServiceCollection AddScbTransactionSync(this IServiceCollection services)
        {
            // Registering Configurations (IOptions pattern)
            services.AddOptions<CosmosConfiguration>()
                .Configure<IConfiguration>((settings, configuration) =>
                {
                    configuration
                    .GetSection("Cosmos")
                    .Bind(settings);
                });

            services.AddOptions<GpgDecryptConfiguration>()
                .Configure<IConfiguration>((settings, configuration) =>
                {
                    configuration
                    .GetSection("GpgDecrypt")
                    .Bind(settings);
                });

            services.AddOptions<SftpConfiguration>()
                .Configure<IConfiguration>((settings, configuration) =>
                {
                    configuration
                    .GetSection("Sftp")
                    .Bind(settings);
                });

            services.AddOptions<AzureBlobStorageConfiguration>()
                .Configure<IConfiguration>((settings, configuration) =>
                {
                    configuration
                    .GetSection("AzureStorage")
                    .Bind(settings);
                });

            services.AddOptions<DomesticPaymentConfiguration>()
            .Configure<IConfiguration>((settings, configuration) =>
            {
                configuration
                .GetSection("DomesticPayment")
                .Bind(settings);
            });

            var connectionString = "AccountEndpoint=https://erx-dev-core.documents.azure.com:443/;AccountKey=t6sLbXodZ3yLz6L82ALW6kfdEaEEO33PL9LmO85s8DKASocTKOtbpn3iQnGnOuULWchdftwQkZdqFNx4Wj0ZrA==;";
            var cosmosClient = new CosmosClientBuilder(connectionString)
                                     .WithConnectionModeDirect()
                                     .WithBulkExecution(true)
                                     .Build();

            services.AddSingleton(cosmosClient);

            services.AddHttpClient<IHttpService<Attachment, Attachment>, HttpService<Attachment, Attachment>>()
            .SetHandlerLifetime(TimeSpan.FromMinutes(5));

            services.AddTransient<IRepository<Guid, Attachment>, Repository<Guid, Attachment>>();
            services.AddTransient<IRepository<string, HistoricalBankStatement>, Repository<string, HistoricalBankStatement>>();
            services.AddTransient<IRepository<Guid, DomesticPayment>, Repository<Guid, DomesticPayment>>();
            services.AddTransient<IRepository<string, CrossBankBillPaymentDetail>, Repository<string, CrossBankBillPaymentDetail>>();
            services.AddTransient<IRepository<Guid, PaymentReturnResult>, Repository<Guid, PaymentReturnResult>>();

            services.AddTransient<ISftpClientService, SftpClientService>();
            services.AddTransient<IAzureBlobStorageService, AzureBlobStorageService>();

            services.AddTransient<IBase64CryptoService, Base64CryptoService>();
            services.AddTransient<ICrossBankPaymentService, CrossBankPaymentService>();
            services.AddTransient<IHistoricalBankStatementService, HistoricalBankStatementService>();

            services.AddTransient<IDomesticPaymentService, DomesticPaymentService>();
            services.AddTransient<IDomesticReturnService, DomesticReturnService>();

            // Registering services
            services.AddTransient<IScbTransactionService, ScbTransactionService>();

            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            return services;
        }

        public static IServiceCollection AddExchangeService(this IServiceCollection services)
        {

            services.AddTransient<IRepository<string, Investor>, Repository<string, Investor>>();
            services.AddTransient<IRepository<string, Transaction>, Repository<string, Transaction>>();
            services.AddTransient<IRepository<Guid, QRCodePaymentRequest>, Repository<Guid, QRCodePaymentRequest>>();
            services.AddTransient<IRepository<string, PaymentConfirmationRequestGateway>, Repository<string, PaymentConfirmationRequestGateway>>();

            services.AddTransient<IExchangeService, ExchangeService>();
            return services;
        }
    }

}
