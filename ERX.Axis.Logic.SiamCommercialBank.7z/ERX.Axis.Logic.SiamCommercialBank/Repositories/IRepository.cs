// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT license.using System

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ERX.Axis.Logic.SiamCommercialBank
{
    public interface IRepository<in TKey, TEntity> where TEntity : Entity<TKey>
    {
        Task<TEntity> GetByIdAsync(TKey id);
        Task<TEntity> CreateAsync(TEntity entity);
        Task<IEnumerable<TEntity>> BulkCreateAsync(IEnumerable<TEntity> entities);
        Task<TEntity> UpdateAsync(TKey id, TEntity entity);
        Task<IEnumerable<TEntity>> ListAsync(string query);
        Task<IQueryable<TEntity>> ListAsync();

    }
}
