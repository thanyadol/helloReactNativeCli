// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT license.using System

using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Configuration;
using System;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Threading.Tasks;

using System.Collections.Generic;
using Microsoft.Extensions.Options;

namespace ERX.Axis.Logic.SiamCommercialBank
{

    public class Repository<TKey, TEntity> : IRepository<TKey, TEntity> where TEntity : Entity<TKey>, new()
    {

        private readonly CosmosConfiguration _cosmosConfiguration;
        private readonly CosmosClient _cosmosClient;
        private Container _cosmosContainer;

        public Repository(CosmosClient cosmosClient,
                    IOptions<CosmosConfiguration> cosmosConfiguration)
        {
            _cosmosClient = cosmosClient;
            _cosmosConfiguration = cosmosConfiguration.Value;

            // var cosmosDatabase = _cosmosClient.GetDatabase(_cosmosConfiguration.DatabaseId);
            _cosmosContainer = this.GetCreateContainerIfNotExistsAsync(new TEntity()).Result;
        }

        public async Task<IEnumerable<TEntity>> BulkCreateAsync(IEnumerable<TEntity> entities)
        {
            //_cosmosContainer = await this.GetCreateContainerIfNotExistsAsync(entities.FirstOrDefault());

            // Assuming your have your data available to be inserted or read
            List<Task> concurrentTasks = new List<Task>();
            foreach (var entity in entities)
            {
                concurrentTasks.Add(_cosmosContainer.CreateItemAsync(entity, new PartitionKey(entity.Id.ToString())));
            }

            await Task.WhenAll(concurrentTasks);

            //await Task.WhenAll(concurrentTasks);
            // TODO : check task is success all

            return entities;
        }

        public async Task<TEntity> CreateAsync(TEntity entity)
        {
            // _cosmosContainer = await this.GetCreateContainerIfNotExistsAsync(entity);

            var itemResponse =
            await _cosmosContainer.CreateItemAsync(
            entity, new PartitionKey(entity.Id.ToString())); //id as partition key

            return itemResponse;
        }

        public async Task<TEntity> UpdateAsync(TKey id, TEntity entity)
        {

            var itemResponse =
                await _cosmosContainer.ReplaceItemAsync(
                    entity,
                    entity.Id.ToString(),
                    new PartitionKey(entity.Id.ToString()));

            return itemResponse;
        }

        public async Task<TEntity> GetByIdAsync(TKey id)
        {
            try
            {
                var itemResponse =
                    await _cosmosContainer.ReadItemAsync<TEntity>(
                        id.ToString(),
                        new PartitionKey(id.ToString()));

                //itemResponse.EnsureSuccessStatusCode();

                return itemResponse.Resource;
            }
            catch (CosmosException ex)
            {
                if (ex.StatusCode == HttpStatusCode.NotFound)
                {
                    return null;
                }

                throw new EntityNotFoundException();
            }
        }

        public async Task<IQueryable<TEntity>> ListAsync()
        {

            IQueryable<TEntity> entities =
                _cosmosContainer.GetItemLinqQueryable<TEntity>(allowSynchronousQueryExecution: true); //.Where(o => o.Created >= DateTime.UtcNow.AddDays(-3));

            return await Task.FromResult(entities).ConfigureAwait(false);

        }

        public async Task<IEnumerable<TEntity>> ListAsync(string query)
        {

            IQueryable<TEntity> entities =
                _cosmosContainer.GetItemLinqQueryable<TEntity>(allowSynchronousQueryExecution: true); //.Where(o => o.Created >= DateTime.UtcNow.AddDays(-3));

            var queryDefinition =
                new QueryDefinition(
                    query);

            var feedIterator =
                _cosmosContainer.GetItemQueryIterator<TEntity>(
                    queryDefinition);

            var entityList =
                new List<TEntity>();

            while (feedIterator.HasMoreResults)
            {
                entityList.AddRange(
                    await feedIterator.ReadNextAsync());
            };

            return entityList;
        }

        public async Task<Container> GetCreateContainerIfNotExistsAsync(TEntity entity)
        {
            //var type = typeof(TEntity);
            if (_cosmosContainer != null)
            {
                return _cosmosContainer;
            }

            var containerName = entity.ContainerName;
            var PartitionKey = entity.PartitionKey;


            //var partitionKey = this.ResolvePartitionKey(entity.Id);
            //Guid guid = Guid.NewGuid();
            // string partitionKeyValue = HashHelper.GetPartitionKey(BitConverter.ToInt32(guid.ToByteArray(), 0));
            var cosmosDatabase = _cosmosClient.GetDatabase(_cosmosConfiguration.DatabaseId);

            var cosmosContainer = await cosmosDatabase.CreateContainerIfNotExistsAsync(containerName, $"/{PartitionKey}").ConfigureAwait(false);
            _cosmosContainer = cosmosContainer.Container;
            return _cosmosContainer;
        }

        public PartitionKey ResolvePartitionKey(TKey id) => new PartitionKey(id.ToString());
    }
}